package com.ptm.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.security.Key;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

@Component
public class JwtProvider {
    @Value("${app.jwt.secret}")
    private String jwtSecret;

    @Value("${app.jwt.expiry}")
    private long expiry;

    public void setJwtSecret(String jwtSecret) {
        this.jwtSecret = jwtSecret;
    }

    public void setExpiry(long expiry) {
        this.expiry = expiry;
    }

    public String generateToken(Authentication authentication)
    {
        String email = authentication.getName();
        Date currentDate =new Date();
        Date expiryDate = new Date(currentDate.getTime()+expiry);
        return Jwts.builder()
                .subject(email)
                .issuedAt(currentDate)
                .expiration(expiryDate)
                .signWith(Key())
                .compact();

    }
    private Key Key()
    {
        return Keys.hmacShaKeyFor(Decoders.BASE64.decode(jwtSecret));
    }

    public String getEmailFromToken(String token)
    {
        return Jwts.parser()
                .verifyWith((SecretKey) Key())
                .build()
                .parseSignedClaims(token)
                .getPayload().getSubject();
    }
    public boolean validateToken(String token)
    {
        try {
            Jwts.parser()
                    .verifyWith((SecretKey) Key())
                    .build()
                    .parse(token);
            return  true;
        }
        catch(MalformedJwtException ex)
        {
            throw new JwtException(ex.getMessage());
        }
        catch(ExpiredJwtException ex)
        {
            throw new JwtException((ex.getMessage()));

        }
        catch (UnsupportedJwtException ex)
        {
            throw new JwtException(ex.getMessage());
        }
        catch (IllegalArgumentException ex)
        {
            throw new JwtException(ex.getMessage());
        }

    }
    public LocalDateTime extractExpiration(String jwtToken) {
        Date expiration = Jwts.parser()
                .setSigningKey(Key())
                .build()
                .parseClaimsJws(jwtToken)
                .getBody()
                .getExpiration();
        return expiration.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime();
    }
}
