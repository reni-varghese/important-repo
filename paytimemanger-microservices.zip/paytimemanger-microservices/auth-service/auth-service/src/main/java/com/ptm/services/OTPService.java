package com.ptm.services;

import com.ptm.exceptions.InvalidOTPException;

public interface OTPService {
    String generateOtp(String empEmail);
    boolean validateOtp(String empEmail, String otp,String newPassword) throws InvalidOTPException;
    void updatePassword(String empEmail, String newPassword);
}

