package com.ptm.services;

import com.ptm.repositories.OTPRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

@Component
@Slf4j
public class OtpCleanupTask {

    private final OTPRepository otpRepository;

    public OtpCleanupTask(OTPRepository otpRepository) {
        this.otpRepository = otpRepository;
    }

    @Scheduled(fixedRate = 900000) // Runs every 60 seconds
    public void deleteExpiredOtps() {
        LocalDateTime expiryTime = LocalDateTime.now().minus(5, ChronoUnit.MINUTES);
        otpRepository.deleteExpiredOtps(expiryTime);
        log.info("Expired OTPs cleaned up at: {}", new java.util.Date());
    }
}
