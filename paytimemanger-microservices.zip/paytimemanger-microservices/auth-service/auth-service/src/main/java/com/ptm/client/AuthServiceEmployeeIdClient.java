package com.ptm.client;

import com.ptm.dtos.EmployeeIdResponse;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestParam;


@FeignClient(name = "employee-service")
public interface AuthServiceEmployeeIdClient {

    /**
     * Retrieves the employee ID associated with the provided email address.
     *
     * This method utilizes a Feign client to communicate with the "employee-service"
     * and fetch the employee ID based on the given email.
     *
     * @param empEmail The email address of the employee for which to retrieve the ID.
     * @return An {@link EmployeeIdResponse} object containing the employee ID, or appropriate error information.
     * Returns null if the employee email does not exist.
     *
     * @throws org.springframework.web.client.RestClientException if there is an issue communicating with the employee service.
     * @throws Exception if any other unexpected exception occurs.
     */
    @GetMapping("/api/employees/getEmpId")
    EmployeeIdResponse getEmpIdByEmail(@RequestParam String empEmail);


}