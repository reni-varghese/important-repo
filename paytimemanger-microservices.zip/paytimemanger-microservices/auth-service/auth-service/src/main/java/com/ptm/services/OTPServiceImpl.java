package com.ptm.services;

import com.ptm.client.AuthServiceEmployeeIdClient;
import com.ptm.dtos.EmployeeIdResponse;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.models.Employee;
import com.ptm.models.OTP;
import com.ptm.repositories.EmployeeRepository;
import com.ptm.repositories.OTPRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Random;

@Service
@Slf4j
@RequiredArgsConstructor
public class OTPServiceImpl implements OTPService {
    private final OTPRepository otpRepository;
    private final EmployeeRepository employeeRepository;
    private final EmailService emailService;
    private final PasswordEncoder passwordEncoder;
    private final AuthServiceEmployeeIdClient authServiceEmployeeIdClient;
    Random random = new Random();



    @Override
    public String generateOtp(String empEmail) {
        EmployeeIdResponse employeeIdResponse = authServiceEmployeeIdClient.getEmpIdByEmail(empEmail);
        log.info("Generating OTP for employee Name: {}", employeeIdResponse.getEmpId());

        String otp = String.format("%06d", this.random.nextInt(1000000));
        LocalDateTime now = LocalDateTime.now();

        OTP otpEntity = new OTP();
        otpEntity.setEmpId(employeeIdResponse.getEmpId());
        otpEntity.setOtp(otp);
        otpEntity.setDateCreated(now);



        try {
            emailService.sendOtpEmail(empEmail, otp);
            log.info("OTP sent successfully to email: {}", empEmail);
        } catch (Exception e) {
            log.error("Error sending OTP email to: {}", empEmail, e);
        }
        otpRepository.save(otpEntity);

        return otp;
    }

    @Override
    public boolean validateOtp(String empEmail, String otp, String newPassword) {

        log.info("Validating OTP for employee Email: {}", empEmail);
        LocalDateTime validFrom = LocalDateTime.now().minus(5, ChronoUnit.MINUTES);
        log.info("Validating OTP for validFrom: {}", validFrom);
        int empID=authServiceEmployeeIdClient.getEmpIdByEmail(empEmail).getEmpId();
        List<OTP> validOtps = otpRepository.findValidOtpsByEmpMail(empID, validFrom);
        log.info("fetching all otp with before expiration time 1");
        for (OTP otpEntity : validOtps) {
            log.info("fetching all otp with before expiration time 2");
            if (otpEntity.getOtp().equals(otp)) {
                otpRepository.deleteById(otpEntity.getOtpId());
                updatePassword(empEmail, passwordEncoder.encode(newPassword));
                log.info("OTP validated successfully for employee Email: {}", empEmail);
                return true;
            }
        }
        log.warn("Invalid OTP for employee Email: {}", empEmail);
        return false;
    }

    @Override
    public void updatePassword(String empEmail, String newPassword) {
        Employee employee = employeeRepository.findByEmpEmail(empEmail).orElseThrow(() -> new EmployeeNotFoundException("Employee not found"));
        employee.setPassword(newPassword);
        employeeRepository.save(employee);
        log.info("Password updated successfully for employee Email: {}", empEmail);
    }
}
