package com.ptm.exceptions;

public class InvalidOTPException extends RuntimeException {
    public InvalidOTPException(String msg) {
        super(msg);
    }
}
