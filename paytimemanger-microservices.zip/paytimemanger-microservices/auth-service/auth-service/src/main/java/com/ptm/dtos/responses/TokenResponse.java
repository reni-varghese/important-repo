package com.ptm.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.Set;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class TokenResponse {
    private String message;
    private int statusCode;
    private Timestamp timestamp;
    private String token;
    private int empId;
    private String empAccess;
    private String type = "Bearer";



}
