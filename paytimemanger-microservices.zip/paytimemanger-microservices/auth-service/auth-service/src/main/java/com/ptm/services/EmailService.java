package com.ptm.services;


import org.springframework.mail.MailException;

public interface EmailService {
    void sendOtpEmail(String to, String otp) throws MailException;

}
