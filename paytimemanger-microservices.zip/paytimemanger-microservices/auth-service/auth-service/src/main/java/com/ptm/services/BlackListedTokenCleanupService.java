package com.ptm.services;

import com.ptm.repositories.BlackListTokenRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

/**
 * Service to clean up expired blacklisted JWT tokens.
 * This service schedules a task to periodically remove expired tokens from the blacklist repository.
 */
@Service
@Slf4j
public class BlackListedTokenCleanupService {

    private final BlackListTokenRepository blackListTokenRepository;

    /**
     * Constructs a new BlackListedTokenCleanupService.
     *
     * @param blackListTokenRepository The repository for blacklisted tokens.
     */
    public BlackListedTokenCleanupService(BlackListTokenRepository blackListTokenRepository) {
        this.blackListTokenRepository = blackListTokenRepository;
    }

    /**
     * Scheduled task to clean up expired tokens from the blacklist.
     * This method is executed every 10 minutes (600000 milliseconds) to delete expired tokens.
     */
    @Scheduled(fixedRate = 600000)
    public void cleanUpExpiredTokens() {
        log.info("Cleaning up expired tokens.");
        blackListTokenRepository.deleteExpiredTokens();
        log.info("Expired tokens cleaned up at: {}", new java.util.Date());
    }
}