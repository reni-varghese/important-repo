package com.ptm.services;

import com.ptm.models.Employee;
import com.ptm.repositories.EmployeeRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
@Slf4j
public class CustomUserDetailsService implements UserDetailsService {

    private final EmployeeRepository employeeRepository;

    public CustomUserDetailsService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        log.info("Loading user by email: {}", email);
        Employee employee = employeeRepository.findByEmpEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User Not Found"));

        Set<GrantedAuthority> authorities = new HashSet<>();

        if (employee.isEmpIsAdmin()) {
            authorities.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
            log.info("Assigned ROLE_ADMIN to user: {}", email);
        }

        if (employee.isEmpIsPayroll()) {
            authorities.add(new SimpleGrantedAuthority("ROLE_PAYROLL_MANAGER"));
            log.info("Assigned ROLE_PAYROLL_MANAGER to user: {}", email);
        }

        if ((!employee.isEmpIsAdmin()) && (!employee.isEmpIsPayroll())) {
            authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
            log.info("Assigned ROLE_USER to user: {}", email);
        }

        log.info("User {} loaded successfully with roles: {}", email, authorities);
        return new org.springframework.security.core.userdetails.User(employee.getEmpEmail(), employee.getPassword(), authorities);
    }
}
