package com.ptm.controllers;

import com.ptm.client.AuthServiceEmployeeIdClient;
import com.ptm.dtos.*;
import com.ptm.dtos.responses.*;
import com.ptm.exceptions.InvalidOTPException;
import com.ptm.exceptions.TokenNotFoundException;
import com.ptm.models.Employee;
import com.ptm.repositories.EmployeeRepository;
import com.ptm.security.JwtProvider;
import com.ptm.services.AuthService;
import com.ptm.services.BlackListTokenService;

import com.ptm.services.OTPService;
import io.jsonwebtoken.JwtException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Slf4j

/**
 * Controller for handling authentication-related requests.
 */
public class AuthController {

    private final OTPService otpService;
    private final AuthServiceEmployeeIdClient authServiceEmployeeIdClient;
    private final AuthService authServiceImpl;
    private final JwtProvider jwtProvider;
    private final BlackListTokenService blackListTokenServiceImpl;
    private final PasswordEncoder passwordEncoder;

    /**
     * Authenticates a user and returns a JWT token along with user details.
     *
     * This endpoint receives a {@link LoginDto} containing user credentials (email and password),
     * authenticates the user using the provided credentials, and returns a {@link TokenResponse}
     * containing a JWT token, user ID, access level, and a success message.
     *
     * @param loginDto The {@link LoginDto} object containing the user's login credentials.
     * @return A {@link ResponseEntity} containing a {@link TokenResponse} with the JWT token and user details,
     * or an appropriate error response if authentication fails.
     */
    @PostMapping("/login")

    public ResponseEntity<TokenResponse> login(@RequestBody LoginDto loginDto) {
        log.info("Login request received for user: {}", loginDto.getEmail());

        LoginResponseDto loginResponseDto = authServiceImpl.login(loginDto);

        TokenResponse tokenResponse = new TokenResponse();
        tokenResponse.setMessage("Employee Authenticated Successfully");
        tokenResponse.setStatusCode(HttpStatus.OK.value());
        tokenResponse.setTimestamp(new Timestamp(System.currentTimeMillis()));
        tokenResponse.setToken(loginResponseDto.getToken());
        tokenResponse.setEmpId(loginResponseDto.getEmpId());
        tokenResponse.setEmpAccess(loginResponseDto.getEmpAccess());

        log.info("User {} authenticated successfully.", loginDto.getEmail());

        return new ResponseEntity<>(tokenResponse, HttpStatus.OK);
    }

    /**
     * Resets the user's password using a provided reset token and new password.
     *
     * This endpoint receives a {@link ResetPassDto} containing the new password, and a JWT token
     * in the "Authorization" header. It validates the token, extracts the user's email, and
     * then calls the authentication service to reset the password.
     *
     * @param resetPassDto The {@link ResetPassDto} object containing the new password.
     * @param token        The JWT token in the "Authorization" header.
     * @return A {@link ResponseEntity} containing an {@link AuthResponseDto} with a success or error message,
     * and an appropriate HTTP status code.
     * - Returns OK (200) with a success message if the password reset is successful.
     * - Returns UNAUTHORIZED (401) if the token is invalid or not found.
     * - Returns INTERNAL_SERVER_ERROR (500) if an unexpected error occurs.
     */
    @PutMapping("/reset-password")
    public ResponseEntity<AuthResponseDto> passwordReset(@RequestBody ResetPassDto resetPassDto, @RequestHeader("Authorization") String token) {
        log.info("Password reset request received.");

        String email;
        String error = "Token Not Found or incorrect";
        AuthResponseDto responseDto = new AuthResponseDto();
        responseDto.setTimestamp(new Timestamp(System.currentTimeMillis()));

        if (StringUtils.hasText(token) && token.startsWith("Bearer ")) {
            email = jwtProvider.getEmailFromToken(token.substring(7));
            log.info("Token validated. Email extracted: {}", email);
        } else {
            responseDto.setMessage(error);
            responseDto.setStatusCode(HttpStatus.UNAUTHORIZED.value());
            log.warn(error);
            return new ResponseEntity<>(responseDto, HttpStatus.UNAUTHORIZED);
        }

        try {
            String response = authServiceImpl.resetPassword(resetPassDto, email);
            responseDto.setMessage(response);
            responseDto.setStatusCode(HttpStatus.OK.value());
            log.info("Password reset successful for email: {}", email);
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        } catch (TokenNotFoundException e) {
            responseDto.setMessage("Token Not Found or Incorrect");
            responseDto.setStatusCode(HttpStatus.UNAUTHORIZED.value());
            log.error("Token not found or incorrect.", e);
            return new ResponseEntity<>(responseDto, HttpStatus.UNAUTHORIZED);
        } catch (Exception e) {
            responseDto.setMessage("Internal Server Error");
            responseDto.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
            log.error("Internal server error occurred during password reset.", e);
            return new ResponseEntity<>(responseDto, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Logs out a user by blacklisting the provided JWT token.
     *
     * This endpoint receives a JWT token in the "Authorization" header, extracts the token,
     * adds it to the blacklist, and returns a success message.
     *
     * @param token The JWT token in the "Authorization" header.
     * @return A {@link ResponseEntity} containing an {@link AuthResponseDto} with a success or error message,
     * and an appropriate HTTP status code.
     * - Returns OK (200) with a success message if the logout is successful.
     * - Returns UNAUTHORIZED (401) if the token is invalid or not found.
     */
    @PostMapping("/logout")
    public ResponseEntity<AuthResponseDto> logout(@RequestHeader("Authorization") String token) {
        log.info("Logout request received.");

        AuthResponseDto responseDto = new AuthResponseDto();
        responseDto.setTimestamp(new Timestamp(System.currentTimeMillis()));

        if (StringUtils.hasText(token) && token.startsWith("Bearer ")) {
            String jwtToken = token.substring(7);
            LocalDateTime expirationTime = jwtProvider.extractExpiration(jwtToken);

            BlackListTokenDto tokenBlackListDto = new BlackListTokenDto(jwtToken, expirationTime);
            blackListTokenServiceImpl.addBlackListedToken(tokenBlackListDto);

            responseDto.setMessage("Logout Successful");
            responseDto.setStatusCode(HttpStatus.OK.value());
            log.info("Logout successful for token: {}", jwtToken);
            return new ResponseEntity<>(responseDto, HttpStatus.OK);
        } else {
            responseDto.setMessage("Token Not Found or Incorrect");
            responseDto.setStatusCode(HttpStatus.UNAUTHORIZED.value());
            log.warn("Token not found or incorrect.");
            return new ResponseEntity<>(responseDto, HttpStatus.UNAUTHORIZED);
        }


    }

    /***
     *
     * Validates a JWT token.
     *
     * This endpoint receives a JWT token as a path variable, validates it
     * and checks if it's blacklisted.
     *
     * @param token The JWT token to validate.
     * @return A {@link ResponseEntity} containing a {@link ValidTokenResponse} with a boolean indicating
     * if the token is valid, or an {@link ErrorResponse} if the token is invalid.
     * - Returns OK (200) with a ValidTokenResponse(true) if the token is valid.
     * - Returns BAD_REQUEST (400) with an ErrorResponse if the token is invalid.
     */

    @GetMapping("/validate/{token}")
    public ResponseEntity<?> validateToken(@PathVariable String token) {
        try {
            boolean valid = jwtProvider.validateToken(token) && !blackListTokenServiceImpl.isTokenBlacklisted(token);
            return ResponseEntity.ok(new ValidTokenResponse(valid));
        } catch (JwtException ex) {
            ErrorResponse errorResponse = new ErrorResponse(
                    LocalDateTime.now(),
                    HttpStatus.BAD_REQUEST.value(),
                    "Invalid Token",
                    ex.getMessage(),
                    "/validate/" + token
            );
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
        }
    }

    /**
     * Sends a One-Time Password (OTP) to the user's email for password reset.
     *
     * This endpoint receives an {@link EmployeePasswordResetDTO} containing the user's email,
     * generates an OTP, and sends it to the user's email.
     *
     * @param employeePasswordResetDTO The {@link EmployeePasswordResetDTO} object containing the user's email.
     * @return A {@link ResponseEntity} containing a {@link CustomResponse} with a success message.
     * - Returns OK (200) with a success message if the OTP is sent successfully.
     */
    @PostMapping("/send-otp")
    public ResponseEntity<CustomResponse> sendOtp(@RequestBody EmployeePasswordResetDTO employeePasswordResetDTO) {
        log.info("Sending OTP request for email: {}", employeePasswordResetDTO.getEmail());



        otpService.generateOtp(employeePasswordResetDTO.getEmail());

        CustomResponse response = new CustomResponse(
                HttpStatus.OK.value(),
                "OTP sent successfully",
                LocalDateTime.now()
        );

        log.info("OTP sent successfully for employee ID: {}", authServiceEmployeeIdClient.getEmpIdByEmail(employeePasswordResetDTO.getEmail()));

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    /**
     * Verifies the provided OTP and resets the user's password.
     *
     * This endpoint receives an {@link OTPDTO} containing the user's email, OTP, and new password,
     * validates the OTP, and resets the password if the OTP is valid.
     *
     * @param otpDTO The {@link OTPDTO} object containing the user's email, OTP, and new password.
     * @return A {@link ResponseEntity} containing a {@link CustomResponse} with a success or error message.
     * - Returns OK (200) with a success message if the OTP is verified successfully.
     * - Returns BAD_REQUEST (400) with an error message if the OTP is invalid.
     * @throws InvalidOTPException If the provided OTP is invalid.
     */
    @PostMapping("/verify-otp")
    public ResponseEntity<CustomResponse> verifyOtp(@RequestBody OTPDTO otpDTO) throws InvalidOTPException {
        log.info("Verifying OTP for employee ID: {}", otpDTO.getEmpEmail());

        boolean isValid = otpService.validateOtp(otpDTO.getEmpEmail(), otpDTO.getOtp(), otpDTO.getNewPassword());

        CustomResponse response = new CustomResponse(
                isValid ? HttpStatus.OK.value() : HttpStatus.BAD_REQUEST.value(),
                isValid ? "OTP verified successfully" : "Invalid OTP",
                LocalDateTime.now()
        );

        log.info(isValid ? "OTP verified successfully for employee ID: {}" : "Invalid OTP for employee ID: {}", otpDTO.getEmpEmail());

        return new ResponseEntity<>(response, isValid ? HttpStatus.OK : HttpStatus.BAD_REQUEST);
    }
    @GetMapping
    public ResponseEntity<String> get()
    {
        String str="hi";
        return new ResponseEntity<>(str,HttpStatus.OK);
    }

    /**
     * Encodes the provided password using BCrypt.
     *
     * This endpoint receives a password as a path variable, encodes it using BCrypt,
     * and returns the encoded password as a string.
     *
     * @param password The password to encode.
     * @return The encoded password as a string.
     */
    @GetMapping("/encode/{password}")
    public String encodePassword(@PathVariable String password) {
        return passwordEncoder.encode(password);
    }
}
