package com.ptm.dtos.responses;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
/**
 * Data Transfer Object (DTO) representing a custom response.
 * This DTO encapsulates the status code, message, and timestamp of a custom operation.
 */
@Getter
@Setter
public class CustomResponse {
    private int statusCode;
    private String message;
    private LocalDateTime timestamp;


    public CustomResponse() {
    }

    public CustomResponse(int statusCode, String message, LocalDateTime timestamp) {
        this.statusCode = statusCode;
        this.message = message;
        this.timestamp = timestamp;
    }
}