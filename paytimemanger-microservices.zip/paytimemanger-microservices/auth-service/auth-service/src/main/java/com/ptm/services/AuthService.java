package com.ptm.services;

import com.ptm.dtos.LoginDto;
import com.ptm.dtos.ResetPassDto;
import com.ptm.dtos.responses.LoginResponseDto;

public interface AuthService {

    LoginResponseDto login(LoginDto loginDto);
    String resetPassword(ResetPassDto resetPassDto, String username);

}
