package com.ptm.dtos;

import lombok.Data;

@Data
public class EmployeeIdResponse {
    private int empId;
}
