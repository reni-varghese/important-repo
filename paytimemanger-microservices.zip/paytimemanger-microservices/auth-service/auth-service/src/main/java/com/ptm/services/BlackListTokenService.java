package com.ptm.services;


import com.ptm.dtos.BlackListTokenDto;

public interface BlackListTokenService {
    public void addBlackListedToken(BlackListTokenDto blackListTokenDto);
    public boolean isTokenBlacklisted(String token);


}
