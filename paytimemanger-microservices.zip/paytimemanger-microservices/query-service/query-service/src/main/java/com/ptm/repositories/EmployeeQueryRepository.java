package com.ptm.repositories;

import com.ptm.models.EmployeeQuery;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface EmployeeQueryRepository extends JpaRepository<EmployeeQuery, Integer> {

    List<EmployeeQuery> findAllByEmpId(int empId);

}
