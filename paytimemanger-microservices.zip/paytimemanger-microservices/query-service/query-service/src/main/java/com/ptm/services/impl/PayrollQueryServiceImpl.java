package com.ptm.services.impl;

import com.ptm.client.EmpClient;
import com.ptm.dto.responses.EmployeeNameDTO;
import com.ptm.dto.responses.PayrollQueryDTO;
import com.ptm.exceptions.QueryNotFoundException;
import com.ptm.models.Employee;
import com.ptm.models.EmployeeQuery;
import com.ptm.repositories.PayrollQueryRepository;
import com.ptm.services.PayrollQueryService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor
public class PayrollQueryServiceImpl implements PayrollQueryService {

    private final EmpClient employeeClient;
    private final PayrollQueryRepository payrollQueryRepository;



    @Override
    public List<PayrollQueryDTO> retrieveQueries() {
        log.info("Retrieving all payroll queries.");
        List<EmployeeQuery> queries = payrollQueryRepository.findAll();

        List<PayrollQueryDTO> queryDTOs = queries.stream().map(query -> {
            ResponseEntity<EmployeeNameDTO> response = employeeClient.getEmployeeName(query.getEmpId());
            String empName = response.getBody().getEmpName();
            PayrollQueryDTO dto = new PayrollQueryDTO();
            dto.setQueryId(query.getQueryId());
            dto.setEmpId(query.getEmpId());
            dto.setEmpName(empName);
            dto.setCategory(query.getCategory());
            dto.setDescription(query.getDescription());
            dto.setDateOfClosed(query.getDateOfClosed());
            dto.setDateOfCreated(query.getDateOfCreated());
            dto.setFeedback(query.getFeedback());
            dto.setStatus(query.getStatus());
            return dto;
        }).collect(Collectors.toList());
        log.info("Payroll queries retrieved: {}", queries);
        return queryDTOs;
    }

    @Override
    public PayrollQueryDTO getById(int queryId) {
        log.info("Fetching payroll query by ID: {}", queryId);
        EmployeeQuery query = payrollQueryRepository.findById(queryId)
                .orElseThrow(() -> new QueryNotFoundException("Query with id " + queryId + " does not exist."));
        PayrollQueryDTO dto = new PayrollQueryDTO();
        dto.setQueryId(query.getQueryId());
        dto.setEmpId(query.getEmpId());
        dto.setCategory(query.getCategory());
        dto.setDescription(query.getDescription());
        dto.setDateOfClosed(query.getDateOfClosed());
        dto.setDateOfCreated(query.getDateOfCreated());
        dto.setFeedback(query.getFeedback());
        dto.setStatus(query.getStatus());
        log.info("Payroll query ID: {} fetched successfully.", queryId);
        return dto;
    }

    @Override
    public void updatePayrollQuery(int queryId, PayrollQueryDTO payrollQueryDTO) {
        log.info("Updating payroll query ID: {}", queryId);
        EmployeeQuery existingQuery = payrollQueryRepository.findById(queryId)
                .orElseThrow(() -> new QueryNotFoundException("Query with id " + queryId + " does not exist."));
        if (payrollQueryDTO.getFeedback() != null && existingQuery.getFeedback() == null) {
            existingQuery.setFeedback(payrollQueryDTO.getFeedback());
            existingQuery.setDateOfClosed(new Date());
            existingQuery.setStatus("Resolved");
            log.info("Payroll query ID: {} resolved successfully.", queryId);
        }
        payrollQueryRepository.save(existingQuery);
        log.info("Payroll query ID: {} updated successfully.", queryId);
    }
}
