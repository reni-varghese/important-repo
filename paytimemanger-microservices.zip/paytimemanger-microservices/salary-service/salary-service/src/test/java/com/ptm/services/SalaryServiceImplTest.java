package com.ptm.services;

import com.ptm.client.EmpSalaryNameClient;
import com.ptm.dto.EmployeeNameDTO;
import com.ptm.dto.responses.SalaryDTO;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.models.Salary;
import com.ptm.repositories.SalaryRepository;
import com.ptm.services.impl.SalaryServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class SalaryServiceImplTest {

    @Mock
    private SalaryRepository salaryRepository;

    @Mock
    private EmpSalaryNameClient employeeClient;

    @InjectMocks
    private SalaryServiceImpl salaryService;

    private Salary salary;
    private SalaryDTO salaryDTO;

    @BeforeEach
    public void setUp() {
        salary = new Salary();
        salary.setSalaryId(1);
        salary.setEmpId(1);
        salary.setMonthYear(LocalDate.of(2023, 1, 1));
        salary.setBasicPay(50000.0);
        salary.setClaims(2000.0);
        salary.setDeductions(5000.0);
        salary.setNetPay(47000.0);
        salary.setPayrollProcessedDate(LocalDate.of(2023, 1, 31));

        salaryDTO = new SalaryDTO(
                1, 1, LocalDate.of(2023, 1, 1), 50000.0, 2000.0, 5000.0, 47000.0, "John Doe", LocalDate.of(2023, 1, 31)
        );
    }

    @Test
    public void testGetYearlySumOfSalaries() {
        List<Object[]> results = new ArrayList<>();
        results.add(new Object[]{2023, 600000.0});
        when(salaryRepository.findYearlySumOfSalaries()).thenReturn(results);

        Map<Integer, Double> yearlySums = salaryService.getYearlySumOfSalaries();

        assertEquals(1, yearlySums.size());
        assertEquals(600000.0, yearlySums.get(2023));
    }

    @Test
    public void testGetSalariesByEmpID_EmployeeNotFound() {
        when(salaryRepository.findSalaryByEmpId(1)).thenReturn(Collections.emptyList());

        assertThrows(EmployeeNotFoundException.class, () -> salaryService.getSalariesByEmpID(1));
    }

    @Test
    public void testGetSalariesByEmpID_Success() {
        when(salaryRepository.findSalaryByEmpId(1)).thenReturn(List.of(salary));

        List<Salary> result = salaryService.getSalariesByEmpID(1);

        assertEquals(1, result.size());
        assertEquals(salary.getSalaryId(), result.get(0).getSalaryId());
    }

    @Test
    public void testGetAllSalaryEmployeeDetails() {
        List<Salary> queryResults = new ArrayList<>();
        queryResults.add(salary);
        when(salaryRepository.findAll()).thenReturn(queryResults);

        EmployeeNameDTO employeeNameDTO = new EmployeeNameDTO();
        employeeNameDTO.setEmpName("John Doe");
        ResponseEntity<EmployeeNameDTO> responseEntity = new ResponseEntity<>(employeeNameDTO, HttpStatus.OK);
        when(employeeClient.getEmployeeName(1)).thenReturn(responseEntity);

        List<SalaryDTO> result = salaryService.getAllSalaryEmployeeDetails();

        assertEquals(1, result.size());
        assertEquals(salaryDTO.getSalaryId(), result.get(0).getSalaryId());
        assertEquals(salaryDTO.getEmpName(), result.get(0).getEmpName());
    }
}