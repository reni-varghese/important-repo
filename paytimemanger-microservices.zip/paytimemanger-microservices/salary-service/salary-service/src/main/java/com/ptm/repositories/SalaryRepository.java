package com.ptm.repositories;

import com.ptm.models.Salary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SalaryRepository extends JpaRepository<Salary, Integer> {
    @Query("SELECT YEAR(s.monthYear) as year, SUM(s.netPay) as yearlySum FROM Salary s GROUP BY YEAR(s.monthYear)")
    List<Object[]> findYearlySumOfSalaries();

    //employee_earnings-overview
    List<Salary> findSalaryByEmpId(int empID);
    @Query("SELECT s FROM Salary s WHERE s.empId IN :employeeIds")
    List<Salary> findByEmployeeIds(@Param("employeeIds") List<Integer> employeeIds);
    @Query("SELECT s FROM Salary s WHERE s.empId IN (SELECT e.id FROM Employee e WHERE e.empPayrollManager  = :empId)")
    List<Salary> findSalariesByManagerId(@Param("empId") int empId);

@Query("SELECT s FROM Salary s WHERE YEAR(s.monthYear) = :year")
  List<Salary> findByYear(@Param("year") String year);

}
