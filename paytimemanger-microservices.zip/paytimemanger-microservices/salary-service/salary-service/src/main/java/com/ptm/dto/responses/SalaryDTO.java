package com.ptm.dto.responses;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;


@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
public class SalaryDTO {
    private int salaryId;
    private int empId;
    private LocalDate monthYear;
    private double basicpay;
    private double claims;
    private double deductions;
    private double netpay;
    private String empName;
    private LocalDate payrollProcessedDate;
}
