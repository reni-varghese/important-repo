package com.ptm.models;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@Table(name = "salary")
public class Salary {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SalaryID", nullable = false)
    private int salaryId;

    @Column(name = "Emp_ID", nullable = false)
    private int empId;

    @Column(name = "Month_Year", nullable = false)
    private LocalDate monthYear;

    @Column(name = "BasicPay")
    private double basicPay;

    @Column(name = "Claims")
    private double claims;

    @Column(name = "Deductions")
    private double deductions;

    @Column(name = "NetPay")
    private double netPay;

    @Column(name="PayrollProcessedDate")
    private LocalDate payrollProcessedDate;
}
