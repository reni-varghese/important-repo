package com.ptm.repositories;

import com.ptm.models.CashClaimsAndAllowance;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface CashClaimsAndAllowanceRepository extends JpaRepository<CashClaimsAndAllowance,Integer> {
    @Query("SELECT c, e.empName FROM CashClaimsAndAllowance c JOIN Employee e ON c.empId = e.empId " + "WHERE c.empId = :empId AND c.dateOfClaim BETWEEN :startDate AND :endDate")
    List<Object[]> findAllByEmpIdAndDateOfClaimBetween( @Param("empId") int empId, @Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    List<CashClaimsAndAllowance> findByEmpId(int empId);
}

