package com.ptm.models;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.time.LocalDate;


@Entity
@Data
@NoArgsConstructor
@Table(name = "weekly_timesheet")
public class WeeklyTimeSheet {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "weekly_timesheet_id", nullable = false)
    private int weeklyTimesheetId;

    @Column(name = "Emp_ID", nullable = false)
    private int empId;

    @Column(name = "week_start", nullable = false)
    private LocalDate weekStart;

    @Column(name = "week_end", nullable = false)
    private LocalDate weekEnd;

    @Column(name = "total_hours")
    private double totalHours;

    @Column(name = "overtime_hours")
    private double overtimeHours;

    @Column(name = "Status", nullable = false)
    private String status;

    @Column(name = "feedback")
    private String feedback;

    @Column(name = "Is_Resubmitted", nullable = false)
    private boolean isResubmitted;

    @Column(name = "action_date")
    private LocalDate actionDate;
}
