package com.ptm.scheduler;
import com.ptm.services.impl.SalaryCalculationServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.time.DayOfWeek;

@Component
public class SalaryCalculationScheduler {

    @Autowired
    private SalaryCalculationServiceImpl salaryCalculationService;

    @Scheduled(cron = "0 0 0 L * ?")
    public void scheduleSalaryCalculation() {
        LocalDate lastWorkingDay = getLastWorkingDayOfMonth();
        YearMonth monthYear = YearMonth.from(lastWorkingDay);
        salaryCalculationService.calculateAndStoreSalary(monthYear);
    }

    private LocalDate getLastWorkingDayOfMonth() {
        LocalDate lastDay = LocalDate.now().with(TemporalAdjusters.lastDayOfMonth());
        if (lastDay.getDayOfWeek() == DayOfWeek.SATURDAY) {
            lastDay = lastDay.minusDays(1);
        } else if (lastDay.getDayOfWeek() == DayOfWeek.SUNDAY) {
            lastDay = lastDay.minusDays(2);
        }
        return lastDay;
    }
}
