package com.ptm.services;

import com.ptm.dto.EmployeeDTO;
import com.ptm.dto.responses.CustomResponse;

import java.util.List;

public interface EmployeeService {
    CustomResponse addEmployee(EmployeeDTO employeeDTO);
    EmployeeDTO getEmployeeById(int id);
    List<EmployeeDTO> getAll();


}
