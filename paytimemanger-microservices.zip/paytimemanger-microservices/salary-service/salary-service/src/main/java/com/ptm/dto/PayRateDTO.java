package com.ptm.dto;

public class PayRateDTO {
    private int pay_rateid;
    private String empRole;
    private double basicPay;
    private double overtimePay;

    private double pf;
    private double hra;
//    private double lta;
    private double mobileReimbursement;
    private double foodReimbursement;
    private double specialAllowance;
    private double cashAllowance;

    public int getPay_rateid() {
        return pay_rateid;
    }

    public void setPay_rateid(int pay_rateid) {
        this.pay_rateid = pay_rateid;
    }

    public String getEmpRole() {
        return empRole;
    }

    public void setEmpRole(String empRole) {
        this.empRole = empRole;
    }

    public double getBasicPay() {
        return basicPay;
    }

    public void setBasicPay(double basicPay) {
        this.basicPay = basicPay;
    }

    public double getOvertimePay() {
        return overtimePay;
    }

    public void setOvertimePay(double overtimePay) {
        this.overtimePay = overtimePay;
    }



    public double getPf() {
        return pf;
    }

    public void setPf(double pf) {
        this.pf = pf;
    }

    public double getHra() {
        return hra;
    }

    public void setHra(double hra) {
        this.hra = hra;
    }

//    public double getLta() {
//        return lta;
//    }
//
//    public void setLta(double lta) {
//        this.lta = lta;
//    }

    public double getMobileReimbursement() {
        return mobileReimbursement;
    }

    public void setMobileReimbursement(double mobileReimbursement) {
        this.mobileReimbursement = mobileReimbursement;
    }

    public double getFoodReimbursement() {
        return foodReimbursement;
    }

    public void setFoodReimbursement(double foodReimbursement) {
        this.foodReimbursement = foodReimbursement;
    }

    public double getSpecialAllowance() {
        return specialAllowance;
    }

    public void setSpecialAllowance(double specialAllowance) {
        this.specialAllowance = specialAllowance;
    }

    public double getCashAllowance() {
        return cashAllowance;
    }

    public void setCashAllowance(double cashAllowance) {
        this.cashAllowance = cashAllowance;
    }
}
