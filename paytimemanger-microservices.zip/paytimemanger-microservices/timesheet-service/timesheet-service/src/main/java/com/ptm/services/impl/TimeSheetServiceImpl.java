package com.ptm.services.impl;

import com.ptm.dto.TimesheetDto;
import com.ptm.dto.responses.SuccessCreation;
import com.ptm.exceptions.ResourceNotFoundException;
import com.ptm.models.TimeSheet;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.exceptions.InvalidInputException;
import com.ptm.repositories.TimeSheetRepository;
import com.ptm.services.TimeSheetService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@Slf4j
public class TimeSheetServiceImpl implements TimeSheetService {
    private final TimeSheetRepository timeSheetRepository;

    public TimeSheetServiceImpl(TimeSheetRepository timeSheetRepository) {
        this.timeSheetRepository = timeSheetRepository;
    }

    @Override
    public boolean existsByEmpId(int empId) {
        log.info("Checking if timesheet exists for employee ID: {}", empId);
        return timeSheetRepository.existsByEmpId(empId);
    }

    @Override
    public boolean existsByDate(LocalDate date) {
        log.info("Checking if timesheet exists for date: {}", date);
        return timeSheetRepository.existsByDate(date);
    }

    @Override
    public TimeSheet existsByDateAndEmpId(LocalDate date, int empId) {
        log.info("Checking if timesheet exists for employee ID: {} and date: {}", empId, date);
        return timeSheetRepository.existsByDateAndEmpId(date, empId);
    }

    @Override
    public List<TimesheetDto> getAll() {
        log.info("Fetching all timesheets.");
        return timeSheetRepository.findAll().stream().map(this::convertToDTO).toList();
    }

    @Override
    public List<TimesheetDto> getById(int empId) {
        log.info("Fetching timesheets for employee ID: {}", empId);
        if (!timeSheetRepository.existsByEmpId(empId)) {
            log.error("Employee with ID: {} does not exist", empId);
            throw new EmployeeNotFoundException("Employee with Id " + empId + " does not exist");
        }
        return timeSheetRepository.getByEmpId(empId).stream().map(this::convertToDTO).toList();
    }

    @Override
    public List<TimesheetDto> getByEmpIdAndDate(int empId, LocalDate from, LocalDate to) {
        log.info("Fetching timesheets for employee ID: {} between {} and {}", empId, from, to);
        if (to.isBefore(from)) {
            log.error("Invalid date range: from {} to {}", from, to);
            throw new InvalidInputException("Invalid Input, please enter correct dates");
        }
        List<TimesheetDto> timesheetList = timeSheetRepository.getByEmpIdAndDateBetween(empId, from, to).stream().map(this::convertToDTO).toList();
        if (timesheetList.isEmpty()) {
            log.error("Timesheet details for employee ID: {} do not exist", empId);
            throw new EmployeeNotFoundException("Timesheet details do not exist");
        }
        return timesheetList;
    }

    @Override
    public TimeSheet findByEmpIdAndDate(int empId, LocalDate date) {
        log.info("Finding timesheet for employee ID: {} on date: {}", empId, date);
        return timeSheetRepository.getByEmpIdAndDate(empId, date);
    }

//    @Override
//    public List<TimesheetDto> getDataByEmpIdAndDate(int empId, LocalDate date){
//
//    }

    @Override
    public SuccessCreation add(TimesheetDto timesheetDto) {
        log.info("Adding timesheet for employee ID: {} on date: {}", timesheetDto.getEmpId(), timesheetDto.getDate());
        validateTimesheetDto(timesheetDto);

        if (timeSheetRepository.existsByDateAndEmpId(timesheetDto.getDate(), timesheetDto.getEmpId()) != null) {
            log.error("Timesheet for employee ID: {} on date: {} already exists", timesheetDto.getEmpId(), timesheetDto.getDate());
            throw new InvalidInputException("Invalid Request, Timesheet for this ID already exists");
        }
        TimeSheet timeSheet = convertToEntity(timesheetDto);
        timeSheetRepository.save(timeSheet);

        log.info("Timesheet added successfully for employee ID: {} on date: {}", timesheetDto.getEmpId(), timesheetDto.getDate());
        return new SuccessCreation("Timesheet added successfully", HttpStatus.CREATED.value());
    }

    private void validateTimesheetDto(TimesheetDto timesheetDto) {
        if (timesheetDto.getEmpId() == 0) {
            throw new InvalidInputException("Invalid Request, Enter correct Employee ID");
        }
        if (timesheetDto.getDate() == null) {
            throw new InvalidInputException("Invalid Request, Enter correct Date");
        }
        if (Objects.isNull(timesheetDto.getClockIn())) {
            throw new InvalidInputException("Invalid Request, Enter correct Clock In Time");
        }
        if (Objects.isNull(timesheetDto.getClockOut())) {
            throw new InvalidInputException("Invalid Request, Enter correct Clock Out Time");
        }
    }

    private TimesheetDto convertToDTO(TimeSheet timesheet) {
        TimesheetDto dto = new TimesheetDto();
        dto.setEmpId(timesheet.getEmpId());
        dto.setDate(timesheet.getDate());
        dto.setClockIn(timesheet.getClockIn());
        dto.setClockOut(timesheet.getClockOut());
        dto.setOverTimeHours(timesheet.getOverTimeHours());
        return dto;
    }

    private TimeSheet convertToEntity(TimesheetDto dto) {
        TimeSheet timesheet = new TimeSheet();
        timesheet.setEmpId(dto.getEmpId());
        timesheet.setDate(dto.getDate());
        timesheet.setClockIn(dto.getClockIn());
        timesheet.setClockOut(dto.getClockOut());
        timesheet.setOverTimeHours(dto.getOverTimeHours());
        return timesheet;
    }
}
