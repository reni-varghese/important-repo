package com.ptm.models;

import jakarta.persistence.*;

import java.sql.Time;
import java.time.LocalDate;

@Entity
@Table(name="timesheet")
public class TimeSheet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Timesheet_ID;
    @Column(name="Emp_Id")
    private int empId;
    @Column(name="Date")
    private LocalDate date;
    @Column(name="Clock_In")
    private Time ClockIn;
    @Column(name="Clock_Out")
    private Time clockOut;
    //@Column(name = "TopUp_Hours")
    @Column(name="Total_Hours")
    private Double totalHours;
    @Column(name="Overtime_Hours")
    private Double overTimeHours;

    public Double getTotalHours() {
        return totalHours;
    }

    public void setTotalHours(Double totalHours) {
        this.totalHours = totalHours;
    }

    public Double getOverTimeHours() {
        return overTimeHours;
    }

    public void setOverTimeHours(Double overTimeHours) {
        this.overTimeHours = overTimeHours;
    }

    public int getTimesheet_ID() {
        return Timesheet_ID;
    }

    public void setTimesheet_ID(int timesheet_ID) {
        Timesheet_ID = timesheet_ID;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Time getClockIn() {
        return ClockIn;
    }

    public void setClockIn(Time clockIn) {
        ClockIn = clockIn;
    }

    public Time getClockOut() {
        return clockOut;
    }

    public void setClockOut(Time clockOut) {
        this.clockOut = clockOut;
    }



}
