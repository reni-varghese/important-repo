package com.ptm.dto.requests;

import java.sql.Time;

public class UpdateTimesheetDto {
//    private Double hoursWorked;
    private Double overTimeHours;
//    private Double topUpHours;
    private Time clockIn;
    private Time clockOut;

    public Time getClockIn() {
        return clockIn;
    }

    public void setClockIn(Time clockIn) {
        this.clockIn = clockIn;
    }

    public Time getClockOut() {
        return clockOut;
    }

    public void setClockOut(Time clockOut) {
        this.clockOut = clockOut;
    }

//    public Double getTopUpHours() {
//        return topUpHours;
//    }
//
//    public void setTopUpHours(Double topUpHours) {
//        this.topUpHours = topUpHours;
//    }
//
//
//
//    public Double getHoursWorked() {
//        return hoursWorked;
//    }
//
//    public void setHoursWorked(Double hoursWorked) {
//        this.hoursWorked = hoursWorked;
//    }

    public Double getOverTimeHours() {
        return overTimeHours;
    }

    public void setOverTimeHours(Double overTimeHours) {
        this.overTimeHours = overTimeHours;
    }


// Getters and Setters

}
