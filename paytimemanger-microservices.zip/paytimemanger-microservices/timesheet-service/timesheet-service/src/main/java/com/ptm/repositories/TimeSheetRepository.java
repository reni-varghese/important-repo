package com.ptm.repositories;

import com.ptm.dto.TimesheetDto;
import com.ptm.models.TimeSheet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface TimeSheetRepository extends JpaRepository<TimeSheet,Integer> {
    List<TimeSheet> getByEmpId(int empId);
    List<TimeSheet> getByEmpIdAndDateBetween(int empId, LocalDate from, LocalDate to);
    boolean existsByDate(LocalDate date);
    boolean existsByEmpId(int empId);
    TimeSheet getByEmpIdAndDate(int empId, LocalDate date);

    @Query("select t From TimeSheet t where t.date=:date AND t.empId =:empId")
    TimeSheet existsByDateAndEmpId(@Param("date") LocalDate date, @Param("empId") int empId);

}
