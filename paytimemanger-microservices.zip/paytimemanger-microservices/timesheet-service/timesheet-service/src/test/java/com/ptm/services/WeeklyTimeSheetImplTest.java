package com.ptm.services;

import com.ptm.dto.TimesheetDto;
import com.ptm.dto.requests.UpdateTimesheetDto;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.exceptions.ResourceNotFoundException;
import com.ptm.models.TimeSheet;
import com.ptm.models.WeeklyTimeSheet;
import com.ptm.repositories.TimeSheetRepository;
import com.ptm.repositories.WeeklyTimeSheetRepository;
import com.ptm.services.impl.WeeklyTimeSheetImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Time;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class WeeklyTimeSheetImplTest {

    @Mock
    private TimeSheetService timeSheetService;

    @Mock
    private WeeklyTimeSheetRepository weeklyTimeSheetRepository;

    @Mock
    private TimeSheetRepository timeSheetRepository;

    @InjectMocks
    private WeeklyTimeSheetImpl weeklyTimeSheetService;

    private TimesheetDto timesheetDto;
    private TimeSheet timeSheet;
    private WeeklyTimeSheet weeklyTimeSheet;

    @BeforeEach
    void setUp() {
        timesheetDto = new TimesheetDto();
        timesheetDto.setEmpId(1);
        timesheetDto.setDate(LocalDate.now());
        timesheetDto.setClockIn(Time.valueOf("09:00:00"));
        timesheetDto.setClockOut(Time.valueOf("17:00:00"));
        timesheetDto.setOverTimeHours(2.0);

        timeSheet = new TimeSheet();
        timeSheet.setEmpId(1);
        timeSheet.setDate(LocalDate.now());
        timeSheet.setClockIn(Time.valueOf("09:00:00"));
        timeSheet.setClockOut(Time.valueOf("17:00:00"));
        timeSheet.setOverTimeHours(2.0);
        timeSheet.setTotalHours(8.0); // Ensure this is set

        weeklyTimeSheet = new WeeklyTimeSheet();
        weeklyTimeSheet.setEmpId(1);
        weeklyTimeSheet.setWeekStart(LocalDate.now().with(DayOfWeek.MONDAY));
        weeklyTimeSheet.setWeekEnd(LocalDate.now().with(DayOfWeek.SUNDAY));
        weeklyTimeSheet.setTotalHours(40);
        weeklyTimeSheet.setOvertimeHours(5);
        weeklyTimeSheet.setStatus("Pending");
    }
    @Test
    void testGetAll() {
        when(weeklyTimeSheetRepository.findAll()).thenReturn(List.of(weeklyTimeSheet));

        List<WeeklyTimeSheet> result = weeklyTimeSheetService.getAll();

        assertEquals(1, result.size());
        assertEquals(weeklyTimeSheet.getEmpId(), result.get(0).getEmpId());
    }

    @Test
    void testGetTimeSheetsFromMondayToCurrent_EmployeeNotFound() {
        when(timeSheetService.existsByEmpId(1)).thenReturn(false);

        assertThrows(EmployeeNotFoundException.class, () -> weeklyTimeSheetService.getTimeSheetsFromMondayToCurrent(1, LocalDate.now()));
    }

    @Test
    void testGetTimeSheetsFromMondayToCurrent() {
        when(timeSheetService.existsByEmpId(1)).thenReturn(true);
        when(weeklyTimeSheetRepository.existsByEmpId(1)).thenReturn(true);
        when(timeSheetService.getByEmpIdAndDate(anyInt(), any(LocalDate.class), any(LocalDate.class))).thenReturn(List.of(timesheetDto));

        List<TimeSheet> result = weeklyTimeSheetService.getTimeSheetsFromMondayToCurrent(1, LocalDate.now());

        assertEquals(1, result.size());
        assertEquals(timeSheet.getEmpId(), result.get(0).getEmpId());
    }

    @Test
    void testGetPendingWeeklyTimesheets_InvalidStatus() {
        assertThrows(ResourceNotFoundException.class, () -> weeklyTimeSheetService.getPendingWeeklyTimesheets("InvalidStatus"));
    }

    @Test
    void  testGetPendingWeeklyTimesheets() {
        when(weeklyTimeSheetRepository.getByStatus("Pending")).thenReturn(List.of(weeklyTimeSheet));

        List<WeeklyTimeSheet> result = weeklyTimeSheetService.getPendingWeeklyTimesheets("Pending");

        assertEquals(1, result.size());
        assertEquals(weeklyTimeSheet.getEmpId(), result.get(0).getEmpId());
    }

    @Test
    void testExistsByEmpId() {
        when(weeklyTimeSheetRepository.existsByEmpId(1)).thenReturn(true);

        assertTrue(weeklyTimeSheetService.existsByEmpId(1));
    }

    @Test
     void testSubmitWeeklyTimeSheet_EmployeeNotFound() {
        when(timeSheetRepository.existsByEmpId(1)).thenReturn(false);

        assertThrows(EmployeeNotFoundException.class, () -> weeklyTimeSheetService.submitWeeklyTimeSheet(1, LocalDate.now()));
    }

    @Test
     void testSubmitWeeklyTimeSheet_TimesheetsNotFound() {
        when(timeSheetRepository.existsByEmpId(1)).thenReturn(true);
        when(timeSheetRepository.getByEmpIdAndDateBetween(anyInt(), any(LocalDate.class), any(LocalDate.class))).thenReturn(Collections.emptyList());

        ResourceNotFoundException exception = assertThrows(ResourceNotFoundException.class, () -> weeklyTimeSheetService.submitWeeklyTimeSheet(1, LocalDate.now()));
        assertEquals("Timesheets from: " + LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)) + " to " + LocalDate.now().with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY)) + " do not exist", exception.getMessage());
    }
    @Test
    void testSubmitWeeklyTimeSheet_Success() {
        when(timeSheetRepository.existsByEmpId(1)).thenReturn(true);
        when(timeSheetRepository.getByEmpIdAndDateBetween(anyInt(), any(LocalDate.class), any(LocalDate.class))).thenReturn(List.of(timeSheet));
        when(weeklyTimeSheetRepository.save(any(WeeklyTimeSheet.class))).thenReturn(weeklyTimeSheet);

        WeeklyTimeSheet result = weeklyTimeSheetService.submitWeeklyTimeSheet(1, LocalDate.now());

        assertEquals(weeklyTimeSheet.getEmpId(), result.getEmpId());
        assertEquals(weeklyTimeSheet.getTotalHours(), result.getTotalHours());
    }



    @Test
     void testOnlyUpdateTimesheet_Success() {
        when(timeSheetService.findByEmpIdAndDate(anyInt(), any(LocalDate.class))).thenReturn(timeSheet);
        when(timeSheetRepository.save(any(TimeSheet.class))).thenReturn(timeSheet);

        UpdateTimesheetDto updateTimesheetDto = new UpdateTimesheetDto();
        updateTimesheetDto.setOverTimeHours(2.00);

        updateTimesheetDto.setOverTimeHours(1.00);
        updateTimesheetDto.setClockIn(Time.valueOf("9:00:00"));
        updateTimesheetDto.setClockOut(Time.valueOf("17:00:00"));

        TimeSheet result = weeklyTimeSheetService.onlyUpdateTimesheet(1, LocalDate.now(), updateTimesheetDto);

        assertEquals(timeSheet.getEmpId(), result.getEmpId());
        assertEquals(timeSheet.getTotalHours(), result.getTotalHours());
    }


}