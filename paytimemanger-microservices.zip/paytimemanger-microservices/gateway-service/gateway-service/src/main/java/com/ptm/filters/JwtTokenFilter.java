package com.ptm.filters;

import com.ptm.client.AuthClient;
import com.ptm.dto.ValidTokenResponse;
import com.ptm.services.TokenService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClient;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
@Order(1)
public class JwtTokenFilter implements GlobalFilter {
    //private final TokenService tokenService;
    private final RestClient restClient;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

        String path = exchange.getRequest().getURI().getPath();
        if(path.startsWith("/api/auth/login") )
        {
            return  chain.filter((exchange));
        }
        if(path.startsWith("/api/auth/send-otp") )
        {
            return  chain.filter((exchange));
        }
        if(path.startsWith("/api/auth/verify-otp") )
        {
            return  chain.filter((exchange));
        }
        if(path.startsWith("/api/employees/"))
        {
            return chain.filter(exchange);
        }
        String token = exchange.getRequest().getHeaders().getFirst("Authorization");
        if(!StringUtils.hasText(token) || !token.startsWith("Bearer "))
        {
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }
        String jwtToken = token.substring(7);

        //ValidTokenResponse response= authClient.validateToken(token).getBody();
        ValidTokenResponse response = restClient.get().uri("http://localhost:9091/api/auth/validate/"+jwtToken).retrieve().body(ValidTokenResponse.class);
        if(!response.isValid())
        {
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }
        return chain.filter(exchange);
    }
}
