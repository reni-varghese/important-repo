package com.ptm.services;

import com.ptm.dto.EmployeeDTO;
import com.ptm.dto.EmployeeRoleDTO;

import java.util.List;


public interface RoleAssignService {

    void promoteToPayrollManager(int empId);
    List<EmployeeDTO> getAllPayrollManagers();
    void demoteFromPayrollManager(int empId);
    void assignPayrollManager(int empId, int payrollManagerId);

    List<EmployeeDTO> empNotPayroll();
    List<EmployeeDTO> empWithoutPayroll();
    int getCountAssignedEmployees(int payrollManagerId);


}
