package com.ptm.services;

import com.ptm.dto.*;
import com.ptm.exceptions.CustomResponse;
import com.ptm.models.Employee;

import java.util.List;

public interface EmployeeService {
    CustomResponse addEmployee(EmployeeDTO employeeDTO);
    EmployeeDTO getEmployeeById(int id);
    List<EmployeeDTO> getAll();
    EmployeeNameDTO getEmployeeNameByEmpId(int empId);
    List<Employee> findByEmpRoleNot();
    EmployeeIdResponse getEmpIdByEmpEmail(String empEmail);
    List<EmployeeDTO> getActiveEmp();
    void markEmpInactive(int empId);
    List<EmployeeDTO> getInactiveEmp();
    void markEmpActive(int empId);
    NetSalarySumDTO getNetSalarySumForPayrollManager(int payrollManagerId);
    Employee updateBankDetails(int empId, BankUpdateDTO bankUpdateDTO);
    Employee updateEmployee(int empId, EmployeeUpdateDTO employeeUpdateDTO);

}
