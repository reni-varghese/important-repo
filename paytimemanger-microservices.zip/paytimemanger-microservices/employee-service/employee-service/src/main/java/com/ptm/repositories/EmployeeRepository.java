package com.ptm.repositories;

import com.ptm.models.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

    @Query("SELECT e FROM Employee e WHERE e.empEmail = :empEmail")
    Optional<Employee> findByEmpEmail(@Param("empEmail") String empEmail);


    boolean existsByEmpId(int empId);
    boolean existsByEmpEmail(String email);
    @Query("SELECT e FROM Employee e WHERE e.empRole <> 'Admin'")
    List<Employee> findByEmpRoleNot();
    @Query("SELECT e FROM Employee e WHERE e.empPayrollManager = :payrollManagerId")
    List<Employee> findByEmpPayrollManager(@Param("payrollManagerId") int payrollManagerId);
}
