package com.ptm.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import lombok.*;

import java.sql.Date;


@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class EmployeeUpdateDTO {
    @Pattern(regexp = "^[A-Za-z ]+$", message = "Name must contain only letters and spaces")
    private String empName;

    @Email(message = "Email should be valid")
    private String empEmail;

    @Past(message = "Date of Birth must be in the past")
    private Date empDob;

    @Pattern(regexp = "(A\\+|A\\-|B\\+|B\\-|AB\\+|AB\\-|O\\+|O\\-)", message = "Blood group must be one of A+, A-, B+, B-, AB+, AB-, O+, O-")
    private String empBloodGroup;

    @Pattern(regexp = "(Male|Female|Other)", message = "Gender must be Male, Female, or Other")
    private String empGender;

    @Pattern(regexp = "(Single|Married|Divorced|Widowed)", message = "Marital status must be Single, Married, Divorced, or Widowed")
    private String empMaritalStatus;

    @Pattern(regexp = "^[0-9]{12}$", message = "National ID must be 12 digits")
    private String empNationalId;

    @Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits")
    private String empPhoneNo;

}