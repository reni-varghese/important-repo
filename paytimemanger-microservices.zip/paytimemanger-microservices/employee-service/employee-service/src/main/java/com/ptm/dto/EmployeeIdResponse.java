package com.ptm.dto;


import lombok.Data;

@Data
public class EmployeeIdResponse {
    private int empId;
}


