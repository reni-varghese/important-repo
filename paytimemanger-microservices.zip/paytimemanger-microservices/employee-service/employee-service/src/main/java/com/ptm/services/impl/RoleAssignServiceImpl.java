package com.ptm.services.impl;

import com.ptm.dto.EmployeeDTO;
import com.ptm.dto.EmployeeRoleDTO;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.models.Employee;
import com.ptm.repositories.EmployeeRepository;
import com.ptm.repositories.RoleAssignRepository;
import com.ptm.services.RoleAssignService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
@Slf4j
public class RoleAssignServiceImpl implements RoleAssignService {

    private final RoleAssignRepository roleAssignRepository;
    private final EmployeeRepository employeeRepository;

    private EmployeeRoleDTO convertToDTO(Employee employee) {
        EmployeeRoleDTO dto = new EmployeeRoleDTO();
        dto.setEmpId(employee.getEmpId());
        dto.setEmpName(employee.getEmpName());
        dto.setEmpRole(employee.getEmpRole());
        dto.setEmpIsPayroll(employee.isEmpIsPayroll());
        dto.setEmpPayrollManager(employee.getEmpPayrollManager());
        return dto;
    }

    @Override
    public void promoteToPayrollManager(int empId) {
        log.info("Promoting employee with ID: {} to Payroll Manager.", empId);
        Optional<Employee> employee = roleAssignRepository.findById(empId);
        if (employee.isPresent()) {
            Employee e = employee.get();
            e.setEmpRole("Payroll Manager");
            e.setEmpIsPayroll(true);
            roleAssignRepository.save(e);
            log.info("Employee with ID: {} promoted to Payroll Manager successfully.", empId);
        } else {
            log.error("Employee not found with ID: {}", empId);
            throw new EmployeeNotFoundException("Employee not found with id " + empId);
        }
    }

    @Override
    public List<EmployeeDTO> getAllPayrollManagers() {
        log.info("Fetching all Payroll Managers.");
        List<EmployeeDTO> payrollManagers = roleAssignRepository.findAll().stream()
                .filter(Employee::isEmpIsPayroll)
                .filter(Employee::isEmpActive)
                .map(this::convertToEmpDTO)
                .toList();
        log.info("All Payroll Managers fetched successfully.");
        return payrollManagers;
    }

    @Override
    public void demoteFromPayrollManager(int empId) {
        log.info("Demoting employee with ID: {} from Payroll Manager.", empId);
        Optional<Employee> employee = roleAssignRepository.findById(empId);
        if (employee.isPresent()) {
            Employee e = employee.get();
            e.setEmpIsPayroll(false);
            roleAssignRepository.save(e);

            List<Employee> managedEmployees = employeeRepository.findAll().stream()
                    .filter(employee1 -> employee1.getEmpPayrollManager() != null && employee1.getEmpPayrollManager() == empId)
                    .collect(Collectors.toList());

            for (Employee managedEmployee : managedEmployees) {
                managedEmployee.setEmpPayrollManager(null);
                employeeRepository.save(managedEmployee);
            }

            log.info("Employee with ID: {} demoted from Payroll Manager successfully.", empId);
        } else {
            log.error("Employee not found with ID: {}", empId);
            throw new EmployeeNotFoundException("Employee not found with id " + empId);
        }
    }

    @Override
    public void assignPayrollManager(int empId, int payrollManagerId) {
        log.info("Assigning Payroll Manager ID: {} to employee ID: {}.", payrollManagerId, empId);
        Optional<Employee> employee = roleAssignRepository.findById(empId);
        Optional<Employee> payrollManager = roleAssignRepository.findById(payrollManagerId);
        if (employee.isPresent() && payrollManager.isPresent()) {
            employee.get().setEmpPayrollManager(payrollManagerId);
            roleAssignRepository.save(employee.get());
            log.info("Payroll Manager ID: {} assigned to employee ID: {} successfully.", payrollManagerId, empId);
        } else {
            log.error("Employee or Payroll Manager not found. Employee ID: {}, Payroll Manager ID: {}", empId, payrollManagerId);
            throw new EmployeeNotFoundException("Employee or Payroll Manager not found");
        }
    }
    @Override
    public List<EmployeeDTO> empNotPayroll()
    {
        log.info("fetching all employees which are not payroll");
        return employeeRepository.findAll().stream().filter(employee -> !employee.isEmpIsPayroll()).map(this::convertToEmpDTO).toList();
    }
    @Override
    public List<EmployeeDTO> empWithoutPayroll()
    {
        log.info("fetching all employees without payroll");
        return employeeRepository.findAll().stream().filter(employee -> employee.getEmpPayrollManager()==null).map(this::convertToEmpDTO).toList();

    }
    @Override
    public int getCountAssignedEmployees(int payrollManagerId) {
        log.info("Getting count of employees assigned to Payroll Manager ID: {}.", payrollManagerId);
        return (int) roleAssignRepository.findAll().stream()
                .filter(employee -> employee.getEmpPayrollManager() != null && payrollManagerId == employee.getEmpPayrollManager())
                .count();
    }


    private EmployeeDTO convertToEmpDTO(Employee employee) {
        EmployeeDTO employeeDTO = new EmployeeDTO();
        employeeDTO.setEmpId(employee.getEmpId());
        employeeDTO.setEmpName(employee.getEmpName());
        employeeDTO.setEmpEmail(employee.getEmpEmail());
        employeeDTO.setEmpDob(employee.getEmpDob());
        employeeDTO.setEmpBloodGroup(employee.getEmpBloodGroup());
        employeeDTO.setEmpGender(employee.getEmpGender());
        employeeDTO.setEmpMaritalStatus(employee.getEmpMaritalStatus());
        employeeDTO.setEmpNationalId(employee.getEmpNationalId());
        employeeDTO.setEmpPhoneNo(employee.getEmpPhoneNo());
        employeeDTO.setEmpRole(employee.getEmpRole());
        employeeDTO.setEmpActive(employee.isEmpActive());
        employeeDTO.setEmpIsPayroll(employee.isEmpIsPayroll());
        employeeDTO.setEmpPayrollManager(employee.getEmpPayrollManager());
        employeeDTO.setBankName(employee.getBankName());
        employeeDTO.setAccountHolderName(employee.getAccountHolderName());
        employeeDTO.setAccountNumber(employee.getAccountNumber());
        employeeDTO.setIfscCode(employee.getIfscCode());
        employeeDTO.setBranch(employee.getBranch());
        return employeeDTO;
    }

}

