package com.ptm.services.impl;

import com.ptm.client.PasswordEncoderClient;
import com.ptm.client.SalaryClient;
import com.ptm.dto.*;
import com.ptm.exceptions.CustomResponse;
import com.ptm.exceptions.EmployeeAlreadyExistsException;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.models.Employee;
import com.ptm.repositories.EmployeeRepository;
import com.ptm.services.EmailService;
import com.ptm.services.EmployeeService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.EnumMap;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
@Slf4j

public class EmployeeServiceImpl implements EmployeeService {

//   private final PasswordEncoder passwordEncoder;
    private final EmployeeRepository employeeRepository;
    private final EmailService emailService;
    private final PasswordEncoderClient passwordEncoderClient;
    private final SalaryClient salaryClient;
    private final RoleAssignServiceImpl roleAssignService;


    @Override
    public EmployeeNameDTO getEmployeeNameByEmpId(int empId){
        log.info("Fetching employee Name by ID: {}", empId);
        Employee employee = employeeRepository.findById(empId)
                .orElseThrow(() -> new EmployeeNotFoundException("Employee with id " + empId + " not found"));
        return convertToEmployeeNameDTO(employee);

    }

    @Override
    public CustomResponse addEmployee(EmployeeDTO employeeDTO) {


        int empId = generateUniqueEmpId();
        employeeDTO.setEmpId(empId);

        String plainPassword = userPassword(employeeDTO.getEmpId()); // Generate password once
        employeeDTO.setPassword(plainPassword); // Set the password in the DTO

        log.info("Password before encryption: {}", plainPassword);

        try {
            emailService.sendEmployeeDetailsEmail(employeeDTO);
        } catch (Exception ex) {
            log.error("Unable to send email to {}", employeeDTO.getEmpEmail(), ex);
            throw new EmployeeNotFoundException("Unable to send an email");
        }

        String encryptedPassword = passwordEncoderClient.encodePassword(plainPassword); // Encrypt the stored password
        employeeDTO.setPassword(encryptedPassword);

        log.info("Password after encryption: {}", encryptedPassword);

        Employee employee = convertToEntity(employeeDTO);
        Employee savedEmployee = employeeRepository.save(employee);

        log.info("Employee Password after encryption (saved): {}", savedEmployee.getPassword());

        CustomResponse response = new CustomResponse();
        response.setTimestamp(LocalDateTime.now());
        response.setStatusCode(HttpStatus.OK.value());
        response.setMessage("Employee with ID " + savedEmployee.getEmpId() + " is added successfully");

        log.info("Employee with ID {} is added successfully", savedEmployee.getEmpId());

        return response;

    }

    private int generateUniqueEmpId() {
        Random random = new Random();
        int empId;
        do {
            empId = 2370000 + random.nextInt(10000); // Generates a random 4-digit number
        } while (employeeRepository.existsById(empId)); // Check if the ID already exists, needs String conversion

        return empId;
    }

    @Override
    public EmployeeDTO getEmployeeById(int id) {
        log.info("Fetching employee by ID: {}", id);
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new EmployeeNotFoundException("Employee with id " + id + " not found"));
        return convertToDTO(employee);
    }

    @Override
    public List<EmployeeDTO> getAll() {
        log.info("Fetching all employees");
        return employeeRepository.findAll().stream()
                .map(this::convertToDTO)
                .filter(employeeDTO -> employeeDTO.isEmpActive())
                .toList();
    }
    @Override
    public List<EmployeeDTO> getActiveEmp()
    {
        log.info("Fetching all active employees");
        return employeeRepository.findAll().stream().filter(Employee::isEmpActive).map(this::convertToDTO)
                .toList();
    }
    @Override
    public void markEmpInactive(int empId)
    {
        log.info("Marking Employee Inactive");
        Employee employee = employeeRepository.findById(empId).orElseThrow(()-> new EmployeeNotFoundException("employee with ID "+empId+" not found."));

        if(employee.isEmpIsPayroll())
        {
            roleAssignService.demoteFromPayrollManager(empId);
        }

        employee.setEmpActive(false);
        employeeRepository.save(employee);

    }
    @Override
    public List<EmployeeDTO> getInactiveEmp()
    {
        log.info("Fetching all inactive employees");
        return employeeRepository.findAll().stream().filter(employee -> !employee.isEmpActive()).map(this::convertToDTO).toList();
    }
    @Override
    public void  markEmpActive(int empId)
    {
        log.info("Marking employee active");
        Employee employee = employeeRepository.findById(empId).orElseThrow(()-> new EmployeeNotFoundException("Employee with the id "+empId+"does not exist"));
        employee.setEmpActive(true);
        employeeRepository.save(employee);
    }


    public String userPassword(int empId) {
        return "Pass" + empId;
    }
    @Override
    public NetSalarySumDTO getNetSalarySumForPayrollManager(int payrollManagerId) {
        List<Employee> employees = employeeRepository.findByEmpPayrollManager(payrollManagerId);
        List<Integer> empIds = employees.stream().map(Employee::getEmpId).collect(Collectors.toList());
        NetSalarySumDTO netSalarySumDTO = salaryClient.getNetSalarySum(empIds);
        return netSalarySumDTO;
    }
    @Override
    public Employee updateBankDetails(int empId, BankUpdateDTO bankUpdateDTO) {
        Employee employee = employeeRepository.findById(empId).orElseThrow(() -> new EmployeeNotFoundException("Employee not found"));
        if (bankUpdateDTO.getBankName() != null) {
            employee.setBankName(bankUpdateDTO.getBankName());
        }
        if (bankUpdateDTO.getAccountHolderName() != null) {
            employee.setAccountHolderName(bankUpdateDTO.getAccountHolderName());
        }
        if (bankUpdateDTO.getAccountNumber() != null) {
            employee.setAccountNumber(bankUpdateDTO.getAccountNumber());
        }
        if (bankUpdateDTO.getIfscCode() != null) {
            employee.setIfscCode(bankUpdateDTO.getIfscCode());
        }
        if (bankUpdateDTO.getBranch() != null) {
            employee.setBranch(bankUpdateDTO.getBranch());
        }
        return employeeRepository.save(employee);
    }
    @Override
    public Employee updateEmployee(int empId, EmployeeUpdateDTO employeeUpdateDTO) {
        Employee employee = employeeRepository.findById(empId).orElseThrow(() -> new EmployeeNotFoundException("Employee not found"));

        log.info("Starting to Update emp details for emp id: {} in service layer", empId);
        if (employeeUpdateDTO.getEmpName() != null) {
            employee.setEmpName(employeeUpdateDTO.getEmpName());
        }
        if (employeeUpdateDTO.getEmpEmail() != null) {
            employee.setEmpEmail(employeeUpdateDTO.getEmpEmail());
        }
        if (employeeUpdateDTO.getEmpDob() != null) {
            employee.setEmpDob(employeeUpdateDTO.getEmpDob());
        }
        if (employeeUpdateDTO.getEmpBloodGroup() != null) {
            employee.setEmpBloodGroup(employeeUpdateDTO.getEmpBloodGroup());
        }
        if (employeeUpdateDTO.getEmpGender() != null) {
            employee.setEmpGender(employeeUpdateDTO.getEmpGender());
        }
        if (employeeUpdateDTO.getEmpMaritalStatus() != null) {
            employee.setEmpMaritalStatus(employeeUpdateDTO.getEmpMaritalStatus());
        }
        if (employeeUpdateDTO.getEmpNationalId() != null) {
            employee.setEmpNationalId(employeeUpdateDTO.getEmpNationalId());
        }
        if (employeeUpdateDTO.getEmpPhoneNo() != null) {
            employee.setEmpPhoneNo(employeeUpdateDTO.getEmpPhoneNo());
        }

        log.info("Employee details successfully updated for emp id: {} in service layer", empId);
        return employeeRepository.save(employee);
    }

    private Employee convertToEntity(EmployeeDTO employeeDTO) {
        Employee employee = new Employee();
        employee.setEmpId(employeeDTO.getEmpId());
        employee.setEmpName(employeeDTO.getEmpName());
        employee.setEmpEmail(employeeDTO.getEmpEmail());
        employee.setEmpDob(employeeDTO.getEmpDob());
        employee.setEmpBloodGroup(employeeDTO.getEmpBloodGroup());
        employee.setEmpGender(employeeDTO.getEmpGender());
        employee.setEmpMaritalStatus(employeeDTO.getEmpMaritalStatus());
        employee.setEmpNationalId(employeeDTO.getEmpNationalId());
        employee.setEmpPhoneNo(employeeDTO.getEmpPhoneNo());
        employee.setEmpRole(employeeDTO.getEmpRole());
        employee.setEmpActive(employeeDTO.isEmpActive());
        employee.setEmpIsPayroll(employeeDTO.isEmpIsPayroll());
        employee.setEmpPayrollManager(employeeDTO.getEmpPayrollManager());
        employee.setBankName(employeeDTO.getBankName());
        employee.setAccountHolderName(employeeDTO.getAccountHolderName());
        employee.setAccountNumber(employeeDTO.getAccountNumber());
        employee.setIfscCode(employeeDTO.getIfscCode());
        employee.setBranch(employeeDTO.getBranch());
        employee.setEmpCreatedAt(Timestamp.valueOf(LocalDateTime.now()));
        employee.setEmpUpdatedAt(Timestamp.valueOf(LocalDateTime.now()));
        employee.setPassword(employeeDTO.getPassword());
        employee.setEmpIsAdmin(employee.isEmpIsAdmin());
        return employee;
    }

    private EmployeeDTO convertToDTO(Employee employee) {
        EmployeeDTO employeeDTO = new EmployeeDTO();
        employeeDTO.setEmpId(employee.getEmpId());
        employeeDTO.setEmpName(employee.getEmpName());
        employeeDTO.setEmpEmail(employee.getEmpEmail());
        employeeDTO.setEmpDob(employee.getEmpDob());
        employeeDTO.setEmpBloodGroup(employee.getEmpBloodGroup());
        employeeDTO.setEmpGender(employee.getEmpGender());
        employeeDTO.setEmpMaritalStatus(employee.getEmpMaritalStatus());
        employeeDTO.setEmpNationalId(employee.getEmpNationalId());
        employeeDTO.setEmpPhoneNo(employee.getEmpPhoneNo());
        employeeDTO.setEmpRole(employee.getEmpRole());
        employeeDTO.setEmpActive(employee.isEmpActive());
        employeeDTO.setEmpIsPayroll(employee.isEmpIsPayroll());
        employeeDTO.setEmpPayrollManager(employee.getEmpPayrollManager());
        employeeDTO.setBankName(employee.getBankName());
        employeeDTO.setAccountHolderName(employee.getAccountHolderName());
        employeeDTO.setAccountNumber(employee.getAccountNumber());
        employeeDTO.setIfscCode(employee.getIfscCode());
        employeeDTO.setBranch(employee.getBranch());
        return employeeDTO;
    }

    private EmployeeNameDTO convertToEmployeeNameDTO(Employee employee){
        EmployeeNameDTO employeeNameDTO = new EmployeeNameDTO();
        employeeNameDTO.setEmpName(employee.getEmpName());
        return  employeeNameDTO;
    }
    @Override
    public List<Employee> findByEmpRoleNot() {
        return employeeRepository.findByEmpRoleNot();
    }

    @Override
    public EmployeeIdResponse getEmpIdByEmpEmail(String empEmail) {
        log.info("emp email from employee service before {}", empEmail);


        Employee emp = employeeRepository.findByEmpEmail(empEmail)
                .orElseThrow(() -> new EmployeeNotFoundException("Employee not found with the provided email ID"));
        EmployeeIdResponse employeeIdResponse = new EmployeeIdResponse();
        employeeIdResponse.setEmpId(emp.getEmpId());
        log.info("emp email from employee after service {}", empEmail);
        return employeeIdResponse;
    }


}

