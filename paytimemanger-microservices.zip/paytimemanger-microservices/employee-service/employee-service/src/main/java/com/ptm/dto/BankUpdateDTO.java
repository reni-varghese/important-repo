package com.ptm.dto;

import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BankUpdateDTO {
    @Pattern(regexp = "^[A-Za-z ]+$", message = "Bank name must contain only letters and spaces")
    private String bankName;

    @Pattern(regexp = "^[A-Za-z ]+$", message = "Account holder name must contain only letters and spaces")
    private String accountHolderName;

    @Pattern(regexp = "^[0-9]{9,20}$", message = "Account number must be between 9 and 20 digits")
    private String accountNumber;

    private String ifscCode;
    private String branch;
}