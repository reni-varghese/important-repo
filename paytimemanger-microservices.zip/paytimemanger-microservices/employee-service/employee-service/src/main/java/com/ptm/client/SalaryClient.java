package com.ptm.client;

import com.ptm.dto.NetSalarySumDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(name = "salary-service")
public interface SalaryClient {
    @GetMapping("/api/salary/net-salary-sum")
    public NetSalarySumDTO getNetSalarySum(@RequestParam("employeeIds") List<Integer> employeeIds);
}