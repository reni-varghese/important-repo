package com.ptm.controllers;

import com.ptm.dto.EmployeeDTO;
import com.ptm.dto.EmployeeRoleDTO;
import com.ptm.exceptions.CustomResponse;
import com.ptm.services.EmployeeService;
import com.ptm.services.RoleAssignService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EmployeeControllerTest {

    @Mock
    private EmployeeService employeeService;

    @Mock
    private RoleAssignService roleAssignService;

    @InjectMocks
    private EmployeeController employeeController;

    private EmployeeDTO employeeDTO;
    private CustomResponse customResponse;
    private EmployeeRoleDTO employeeRoleDTO;

    @BeforeEach
    void setUp() {
        employeeDTO = new EmployeeDTO();
        employeeDTO.setEmpId(1);
        employeeDTO.setEmpName("John Doe");
        employeeDTO.setEmpEmail("john.doe@example.com");
        employeeDTO.setEmpDob(Date.valueOf("1990-01-01"));
        employeeDTO.setEmpBloodGroup("O+");
        employeeDTO.setEmpGender("Male");
        employeeDTO.setEmpMaritalStatus("Single");
        employeeDTO.setEmpNationalId("123456789");
        employeeDTO.setEmpPhoneNo("1234567890");
        employeeDTO.setEmpRole("EMPLOYEE");
        employeeDTO.setEmpActive(true);
        employeeDTO.setEmpIsPayroll(false);
        employeeDTO.setEmpPayrollManager(null);
        employeeDTO.setBankName("Example Bank");
        employeeDTO.setAccountHolderName("John Doe");
        employeeDTO.setAccountNumber("1234567890");
        employeeDTO.setIfscCode("EXMP1234");
        employeeDTO.setBranch("Main Branch");
        employeeDTO.setPassword("password");

        customResponse = new CustomResponse(HttpStatus.OK.value(), "Operation successful", LocalDateTime.now());
        employeeRoleDTO = new EmployeeRoleDTO();
    }

    @Test
    void testAddEmployee() {
        // Arrange
        CustomResponse customResponse = new CustomResponse(HttpStatus.OK.value(), "Employee added successfully", LocalDateTime.now());
        when(employeeService.addEmployee(employeeDTO)).thenReturn(customResponse);

        // Act
        ResponseEntity<CustomResponse> response = employeeController.addEmployee(employeeDTO);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Employee added successfully", response.getBody().getMessage());
        verify(employeeService, times(1)).addEmployee(employeeDTO);
    }

    @Test
    void testGetAllEmployee() {
        // Arrange
        List<EmployeeDTO> employeeList = Arrays.asList(employeeDTO);
        when(employeeService.getAll()).thenReturn(employeeList);

        // Act
        ResponseEntity<List<EmployeeDTO>> response = employeeController.getAllEmployee();

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        verify(employeeService, times(1)).getAll();
    }

    @Test
    void testGetEmployeeById() {
        // Arrange
        int empId = 1;
        when(employeeService.getEmployeeById(empId)).thenReturn(employeeDTO);

        // Act
        ResponseEntity<EmployeeDTO> response = employeeController.getEmployeeById(empId);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(empId, response.getBody().getEmpId());
        verify(employeeService, times(1)).getEmployeeById(empId);
    }

    @Test
    void testPromoteToPayrollManager() {
        doNothing().when(roleAssignService).promoteToPayrollManager(1);

        ResponseEntity<CustomResponse> response = employeeController.promoteToPayrollManager(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Employee promoted to payroll manager successfully", response.getBody().getMessage());
        verify(roleAssignService, times(1)).promoteToPayrollManager(1);
    }

    @Test
    void testPromoteToPayrollManager_Exception() {
        doThrow(new RuntimeException("Error")).when(roleAssignService).promoteToPayrollManager(1);

        ResponseEntity<CustomResponse> response = employeeController.promoteToPayrollManager(1);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Error promoting employee to payroll manager", response.getBody().getMessage());
        verify(roleAssignService, times(1)).promoteToPayrollManager(1);
    }

//    @Test
//    void testGetAllPayrollManagers() {
//        List<EmployeeRoleDTO> payrollManagers = Arrays.asList(employeeRoleDTO);
//        when(roleAssignService.getAllPayrollManagers()).thenReturn(payrollManagers);
//
//        List<EmployeeDTO> response = employeeController.getAllPayrollManagers();
//
//        assertEquals(payrollManagers, response);
//        verify(roleAssignService, times(1)).getAllPayrollManagers();
//    }

    @Test
    void testDemoteFromPayrollManager() {
        doNothing().when(roleAssignService).demoteFromPayrollManager(1);

        ResponseEntity<CustomResponse> response = employeeController.demoteFromPayrollManager(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Employee demoted from payroll manager successfully", response.getBody().getMessage());
        verify(roleAssignService, times(1)).demoteFromPayrollManager(1);
    }

    @Test
    void testDemoteFromPayrollManager_Exception() {
        doThrow(new RuntimeException("Error")).when(roleAssignService).demoteFromPayrollManager(1);

        ResponseEntity<CustomResponse> response = employeeController.demoteFromPayrollManager(1);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Error demoting employee from payroll manager", response.getBody().getMessage());
        verify(roleAssignService, times(1)).demoteFromPayrollManager(1);
    }

    @Test
    void testAssignPayrollManager() {
        doNothing().when(roleAssignService).assignPayrollManager(1, 2);

        ResponseEntity<CustomResponse> response = employeeController.assignPayrollManager(1, 2);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Payroll manager assigned to employee successfully", response.getBody().getMessage());
        verify(roleAssignService, times(1)).assignPayrollManager(1, 2);
    }

    @Test
    void testAssignPayrollManager_Exception() {
        doThrow(new RuntimeException("Error")).when(roleAssignService).assignPayrollManager(1, 2);

        ResponseEntity<CustomResponse> response = employeeController.assignPayrollManager(1, 2);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Error assigning payroll manager to employee", response.getBody().getMessage());
        verify(roleAssignService, times(1)).assignPayrollManager(1, 2);
    }
}