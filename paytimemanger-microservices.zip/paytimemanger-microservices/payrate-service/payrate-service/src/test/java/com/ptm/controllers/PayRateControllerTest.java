package com.ptm.controllers;

import com.ptm.dto.PayRateDTO;
import com.ptm.exceptions.CustomResponse;
import com.ptm.services.PayRatesService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PayRateControllerTest {

    @Mock
    private PayRatesService payRatesService;

    @InjectMocks
    private PayRateController payRateController;

    private PayRateDTO payRateDTO;
    private CustomResponse customResponse;

    @BeforeEach
    void setUp() {
        payRateDTO = new PayRateDTO();
        customResponse = new CustomResponse(HttpStatus.OK.value(), "Pay rate added successfully!", null);
    }

    @Test
    void testAddPayRate() {
        when(payRatesService.addPayRate(payRateDTO)).thenReturn(customResponse);

        ResponseEntity<CustomResponse> response = payRateController.addPayRate(payRateDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Pay rate added successfully!", response.getBody().getMessage());
        verify(payRatesService, times(1)).addPayRate(payRateDTO);
    }

    @Test
    void testGetAllPayRate() {
        List<PayRateDTO> payRates = Arrays.asList(payRateDTO);
        when(payRatesService.getAllPayRate()).thenReturn(payRates);

        ResponseEntity<List<PayRateDTO>> response = payRateController.getAllPayRate();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(payRates, response.getBody());
        verify(payRatesService, times(1)).getAllPayRate();
    }

    @Test
    void testGetPayRateById() {
        when(payRatesService.getPayRateById(1)).thenReturn(payRateDTO);

        ResponseEntity<PayRateDTO> response = payRateController.getPayRateById(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(payRateDTO, response.getBody());
        verify(payRatesService, times(1)).getPayRateById(1);
    }

    @Test
    void testPartialUpdatePayRate() {
        Map<String, Object> updates = Map.of("rate", 50);
        when(payRatesService.partialUpdatePayRate(1, updates)).thenReturn(payRateDTO);

        ResponseEntity<PayRateDTO> response = payRateController.partialUpdatePayRate(1, updates);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(payRateDTO, response.getBody());
        verify(payRatesService, times(1)).partialUpdatePayRate(1, updates);
    }
}