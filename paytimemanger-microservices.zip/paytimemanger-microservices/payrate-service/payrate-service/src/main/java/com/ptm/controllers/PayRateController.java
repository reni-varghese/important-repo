package com.ptm.controllers;

import com.ptm.dto.PayRateDTO;
import com.ptm.exceptions.CustomResponse;
import com.ptm.models.PayRate;
import com.ptm.services.PayRatesService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/payrate")
@RequiredArgsConstructor
@Slf4j
public class PayRateController {

    private final PayRatesService payRatesService;

    @GetMapping("/salary-payrate")
    public Optional<PayRate> findByEmpRole(@RequestParam String empRole) {
        return payRatesService.findByEmpRole(empRole);
    }
    @PostMapping
    public ResponseEntity<CustomResponse> addPayRate(@RequestBody PayRateDTO payRateDTO) {
        log.info("Adding new pay rate: {}", payRateDTO);
        CustomResponse response = payRatesService.addPayRate(payRateDTO);
        log.info("Pay rate added successfully.");
        return ResponseEntity.ok(response);
    }

    @GetMapping
    public ResponseEntity<List<PayRateDTO>> getAllPayRate() {
        log.info("Fetching all pay rates.");
        return ResponseEntity.ok(payRatesService.getAllPayRate());
    }

    @GetMapping("/{id}")
    public ResponseEntity<PayRateDTO> getPayRateById(@PathVariable int id) {
        log.info("Fetching pay rate with ID: {}", id);
        return new ResponseEntity<>(payRatesService.getPayRateById(id), HttpStatus.OK);
    }

    @PatchMapping("/{id}")
    public ResponseEntity<PayRateDTO> partialUpdatePayRate(@PathVariable int id, @RequestBody Map<String, Object> updates) {
        log.info("Partially updating pay rate with ID: {} with updates: {}", id, updates);
        PayRateDTO updatedPayRate = payRatesService.partialUpdatePayRate(id, updates);
        log.info("Pay rate with ID: {} updated successfully.", id);
        return new ResponseEntity<>(updatedPayRate, HttpStatus.OK);
    }
}
