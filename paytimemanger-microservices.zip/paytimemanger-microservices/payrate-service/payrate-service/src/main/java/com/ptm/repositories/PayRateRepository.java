package com.ptm.repositories;

import com.ptm.models.PayRate;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PayRateRepository extends JpaRepository<PayRate, Integer> {
    Optional<PayRate> findByEmpRole(String empRole);
}
