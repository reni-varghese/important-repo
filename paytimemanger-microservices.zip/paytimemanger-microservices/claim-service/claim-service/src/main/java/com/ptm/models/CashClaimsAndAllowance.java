package com.ptm.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;

@Entity
@Table(name = "cash_allowance_claims")
@Getter
@Setter
@ToString
public class CashClaimsAndAllowance {

    @Column(name = "EMP_ID")
    private int empId;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CLAIM_ID")
    private int Claim_id;

    @Column(name = "DATE_OF_CLAIM")
    private LocalDate dateOfClaim;

    @Column(name = "DESCRIPTION")
    private String description;

    @Lob
    @Column(name = "ATTACHMENT")
    private byte[] attachment;

    @Column(name = "AMOUNT")
    private double amount;

    @Column(name = "REMARK")
    private String remark;

    @Column(name = "DATE_OF_ACTION")
    private LocalDate dateOfAction;

    @Column(name = "ALLOWANCE_TYPE")
    private String allowanceType;

    @Column(name = "ACTION")
    private String action;

    @Transient
    private String empName;
}
