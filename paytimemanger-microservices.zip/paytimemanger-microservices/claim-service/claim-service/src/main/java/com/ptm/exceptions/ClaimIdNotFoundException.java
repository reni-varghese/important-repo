package com.ptm.exceptions;

public class ClaimIdNotFoundException extends RuntimeException {
    public ClaimIdNotFoundException(String msg) {
        super(msg);
    }
}
