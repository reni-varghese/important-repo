package com.cts.service;

import com.cts.entity.Employee;
import com.cts.exception.EmployeeNotFoundException;
import com.cts.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class EmployeeServiceImpl implements EmployeeService {


    private final EmployeeRepository employeeRepository;

    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public List<Employee> findAll() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee findById(int id) {
        return employeeRepository.findById(id)
                .orElseThrow(()->new EmployeeNotFoundException("Employee not found with id: " + id));
    }

    @Override
    public Employee save(Employee employee) {
        return employeeRepository.save(employee);
    }

    @Override
    public Employee update(int id, Employee employee) {
        Employee existingEmployee = employeeRepository.findById(id)
                .orElseThrow(() -> new EmployeeNotFoundException("Employee not found with id: " + id));
       if(employee.getName()!=null) {
            existingEmployee.setName(employee.getName());
        }
        if(employee.getGender()!=null) {
            existingEmployee.setGender(employee.getGender());
       }
        if(employee.getAge()!=0) {
            existingEmployee.setAge(employee.getAge());
        }
        if(employee.getSalary()!=0) {
            existingEmployee.setSalary(employee.getSalary());
        }
        return employeeRepository.save(existingEmployee);
    }

    @Override
    public void delete(int id) {
        if(!employeeRepository.existsById(id)) {
            throw new EmployeeNotFoundException("Employee not found with id: " + id);
        }
        employeeRepository.deleteById(id);
    }
}
