package com.cts.exception;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;

public class EmployeeAppException extends RuntimeException {

    private HttpStatus status;
    private String message;

    public EmployeeAppException(HttpStatus status, String message) {
        super(message);
        this.status = status;

    }
}
