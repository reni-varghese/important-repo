package com.cts.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name="users")
public class User {
    @Id
    private int id;
    private String name;
    private String username;
    private String password;
    private String email;
    @ManyToMany(fetch = FetchType.EAGER)

    private List<Role> roles;
}
