package com.cts.controller;

import com.cts.entity.Employee;
import com.cts.service.EmployeeService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@SpringBootTest
@AutoConfigureMockMvc
class EmployeeControllerTest {

    Employee emp1;
    Employee emp2;
    List<Employee> empList;
    @Autowired
    MockMvc mockMvc;
    @MockitoBean
    EmployeeService employeeService;
    @Autowired
    ObjectMapper mapper;


    @BeforeEach
    public void init(){
        emp1=new Employee(1,"Kiran","Male",23,67000);
        emp2=new Employee(2,"Sara","Female",21,78000);
        empList= List.of(emp1,emp2);
    }


    @Test
    @WithMockUser
    void getAllEmployees() throws Exception {

        when(employeeService.findAll()).thenReturn(empList);

        mockMvc.perform(get("/api/employees"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(2))
                .andExpect(jsonPath("$[0].name").value("Kiran"));


        verify(employeeService,times(1)).findAll();
    }

    @Test
    @WithMockUser
    void getEmployeeById() throws Exception {

        when(employeeService.findById(anyInt())).thenReturn(emp1);
        mockMvc.perform(get("/api/employees/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Kiran"));

        verify(employeeService,times(1)).findById(anyInt());
    }

    @Test
    @WithMockUser(roles="ADMIN")
    void createEmployee() throws Exception {

        var jsonEmployee=mapper.writeValueAsString(emp1);
        when(employeeService.save(any(Employee.class))).thenReturn(emp1);

        mockMvc.perform(post("/api/employees")
                .contentType(MediaType.APPLICATION_JSON)
                .content(jsonEmployee))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("Kiran"));

        verify(employeeService,times(1)).save(any(Employee.class));

    }

    @Test
    @WithMockUser(roles="ADMIN")
    void updateEmployee() throws Exception {

        when(employeeService.update(anyInt(), any(Employee.class))).thenReturn(emp2);
        var jsonEmployee=mapper.writeValueAsString(emp2);
        mockMvc.perform(put("/api/employees/1")
                .content(jsonEmployee).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Sara"));

        verify(employeeService,times(1)).update(anyInt(), any(Employee.class));

    }

    @Test
    @WithMockUser(roles="ADMIN")
    void deleteEmployee() throws Exception {

        doNothing().when(employeeService).delete(anyInt());

        mockMvc.perform(delete("/api/employees/1"))
                .andExpect(status().isNoContent());

        verify(employeeService,times(1)).delete(anyInt());
    }
}