import { Component, OnInit, EventEmitter, Output, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { SidebarConfig } from '../../configs/sidebar.config';
import { AuthService } from '../../../components/auth/auth.service';
import { INavbarData } from './helper';
import { animate, keyframes, style, transition, trigger } from '@angular/animations';
import { fadeInOut } from './helper';
import { Observable } from 'rxjs';
import { select, Store } from '@ngrx/store';
import { selectEmpAccess } from '../../store/auth.selectors';
// import { ConfirmationService } from 'primeng/api';

interface SideNavToggle {
  screenWidth: number;
  collapsed: boolean;
}

@Component({
  selector: 'app-sidebar',
  standalone: false,
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
  animations: [fadeInOut, trigger('rotate', [transition(':enter', [animate('1000ms', keyframes([style({ transform: 'rotate(0deg)', offset: '0' }), style({ transform: 'rotate(2turn)', offset: '1' }) ]))])])],
  // providers: [ConfirmationService]
  // providers: [ConfirmationService]
})
export class SidebarComponent implements OnInit {
  @Output() onToggleSideNav: EventEmitter<SideNavToggle> = new EventEmitter();
  collapsed = false;
  screenWidth = 0;
  navData: any[] = [];
  multiple: boolean = false;
  userBoxExpanded = false;
  currentDashboard: string = '';
  userAvatarIcon: string = 'pi pi-user';

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    this.screenWidth = window.innerWidth;
    if (this.screenWidth <= 768) {
      this.collapsed = false;
      this.onToggleSideNav.emit({ collapsed: this.collapsed, screenWidth: this.screenWidth });
    }
  }
  empAccess$: Observable<string | null>;
  constructor(public router: Router, private authService: AuthService, private store: Store) {
    this.empAccess$ = this.store.pipe(select(selectEmpAccess));
  }

  ngOnInit(): void {
    this.screenWidth = window.innerWidth;
    this.updateSidebar();
    this.router.events.subscribe(() => this.updateSidebar());
    this.updateDashboardInfo();
  }

  updateDashboardInfo(): void {
    const currentUrl = this.router.url;
    if (currentUrl.includes('/admin')) {
      this.currentDashboard = 'ADMIN';
      this.userAvatarIcon = 'pi pi-user-edit';
    } else if (currentUrl.includes('/employee')) {
      this.currentDashboard = 'EMPLOYEE';
      this.userAvatarIcon = 'pi pi-users';
    } else if (currentUrl.includes('/payroll')) {
      this.currentDashboard = 'PAYROLL';
      this.userAvatarIcon = 'pi pi-money-bill';
    } else {
      this.currentDashboard = 'UNKNOWN';
      this.userAvatarIcon = 'pi pi-question-circle';
    }
  }

  toggleCollapse(): void {
    this.collapsed = !this.collapsed;
    this.onToggleSideNav.emit({ collapsed: this.collapsed, screenWidth: this.screenWidth });
    if (this.userBoxExpanded) {
      this.userBoxExpanded = !this.userBoxExpanded;
    }
  }

  closeSidenav(): void {
    this.collapsed = false;
    this.onToggleSideNav.emit({ collapsed: this.collapsed, screenWidth: this.screenWidth });
  }

  handleClick(item: INavbarData): void {
    this.shrinkItems(item);
    item.expanded = !item.expanded;
  }

  getActiveClass(data: INavbarData): string {
    return this.router.url.includes(data.path) ? 'active' : '';
  }

  updateSidebar() {
    if (this.router.url.includes('/admin')) {
      this.navData = SidebarConfig.admin;
    } else if (this.router.url.includes('/employee')) {
      this.navData = SidebarConfig.employee;
    } else if (this.router.url.includes('/payroll')) {
      this.navData = SidebarConfig.payroll;
    }
    this.updateDashboardInfo();
  }

  shrinkItems(item: INavbarData): void {
    if (!this.multiple) {
      for (let modelItem of this.navData) {
        if (item !== modelItem && modelItem.expanded) {
          modelItem.expanded = false;
        }
      }
    }
  }

  toggleUserBox(): void {
    this.userBoxExpanded = !this.userBoxExpanded;
  }

  logout(): void {
    localStorage.setItem('hasReloaded', 'false');
    // this.confirmationService.confirm({
    //   message: 'Are you sure you want to logout?',
    //   header: 'Logout Confirmation',
    //   icon: 'pi pi-exclamation-triangle',
    //   accept: () => {
    //     this.authService.logout();
    //     // this.router.navigate(['/login']);

    //   },
    //   reject: () => {
    //     // Do nothing on reject
    //   }
    // });
    this.authService.logout();
  }

  changeDashboard(): void {
    const currentUrl = this.router.url;
    if (currentUrl.includes('/admin')) {
      this.router.navigate(['/employee/dashboard']);
    } else if (currentUrl.includes('/employee')) {
      this.router.navigate(['/payroll/dashboard']);
    } else if (currentUrl.includes('/payroll')) {
      this.router.navigate(['/employee/dashboard']);
    }
  }

  showChangeDashboard(): boolean {
    let access: string | null = null;
    this.empAccess$.subscribe(val => access = val);
    console.log("log: ", access);
    return access !== 'user'; // Returns true if access is NOT 'employee'
  }

  getChangeDashboardLabel(): string {
    const currentUrl = this.router.url;
    let access: string | null = null;
    this.empAccess$.subscribe(val => access = val);

    if (access === 'payroll') {
      if (currentUrl.includes('/employee')) {
        return 'Payroll Dashboard';
      } else if (currentUrl.includes('/payroll')) {
        return 'Employee Dashboard';
      }
    } else if (access === 'admin') {
      if (currentUrl.includes('/employee')) {
        return 'Admin Dashboard';
      } else if (currentUrl.includes('/admin')) {
        return 'Employee Dashboard';
      }
    }

    return ''; // Default case or error handling
  }
}   