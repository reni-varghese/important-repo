import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { RouterModule } from '@angular/router';

import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmationService } from 'primeng/api';
import { SafePipe } from './pipes/safe-pipe/safe.pipe';
import { StoreModule } from '@ngrx/store';
import { authReducer } from './store/auth.reducer';
import { NotfoundComponent } from './components/notfound/notfound.component';
import { SublevelMenuComponent } from './components/sidebar/sublevel-menu/sublevel-menu.component';


@NgModule({
  declarations: [
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    SafePipe,
    NotfoundComponent,
    SublevelMenuComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    ConfirmDialogModule,
    StoreModule.forFeature('auth', authReducer),
  ],
  providers: [ConfirmationService],
  exports: [
    SidebarComponent,
    HeaderComponent,
    SafePipe
  ]
})
export class SharedModule { }