import { createReducer, on } from '@ngrx/store';
import { loginSuccess, logout } from './auth.actions';

export interface AuthState {
  empAccess: string | null;
}

export const initialState: AuthState = {
  empAccess: null,
};

export const authReducer = createReducer(
  initialState,
  on(loginSuccess, (state, { empAccess }) => ({ ...state, empAccess })),
  on(logout, (state) => ({ ...state, empAccess: null }))
);