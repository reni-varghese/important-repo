export const SidebarConfig = {
  admin: [
    { path: '/admin/dashboard', label: 'Dashboard', icon: 'pi pi-home' },
    {
      path: '/admin/create-employee',
      label: 'Add Employee',
      icon: 'pi pi-user-plus',
      items: [
        {
          path: '/admin/create-employee/all-employee',
          label: 'All Employee',
          icon: 'pi pi-table',
        },
        {
          path: '/admin/create-employee/add-employee',
          label: 'Add Employee',
          icon: 'pi pi-user-plus',
        },
        {
          path: '/admin/create-employee/remove-employee',
          label: 'Remove Employee',
          icon: 'pi pi-user-minus',
        },
        {
          path: '/admin/create-employee/restore-employee',
          label: 'Restore Employee',
          icon: 'pi pi-refresh',
        },
      ],
    },
    {
      path: '/admin/role-assign',
      label: 'Role Assignment',
      icon: 'pi pi-users',
      items: [
      
        {
          path: '/admin/role-assign/assign',
          label: 'Assign Role',
          icon: 'pi pi-user-plus',
        },
        {
          path: '/admin/role-assign/promote',
          label: 'Promote Employee',
          icon: 'pi pi-arrow-up',
        },
        {
          path: '/admin/role-assign/demote',
          label: 'Demote Employee',
          icon: 'pi pi-arrow-down',
        },
      ],
    },
    { path: '/admin/timesheet', label: 'Timesheet Summary', icon: 'pi pi-calendar' },
    { path: '/admin/cash-claims', label: 'Cash Claims', icon: 'pi pi-wallet' },
    { path: '/admin/payrate', label: 'Pay Rates', icon: 'pi pi-money-bill' },
  ],
  employee: [
    { path: '/employee/dashboard', label: 'Dashboard', icon: 'pi pi-home' },
    { path: '/employee/add-timesheet', label: 'Work Hours Entry', icon: 'pi pi-clock' },
    { path: '/employee/timesheet-summary-emp', label: 'Timesheet Summary', icon: 'pi pi-table' },
    { path: '/employee/cash-claims', label: 'Cash Claims', icon: 'pi pi-wallet' },
    { path: '/employee/salary-overview', label: 'Earnings Overview', icon: 'pi pi-credit-card' },
    { path: '/employee/add-query', label: 'Query', icon: 'pi pi-question' },
  ],
  payroll: [
    { path: '/payroll/dashboard', label: 'Profile', icon: 'pi pi-user' },
    { path: '/payroll/timesheet-approve', label: 'Timesheet Approval', icon: 'pi pi-check-circle' },
    { path: '/payroll/cash-claims-approve', label: 'Cash Claims', icon: 'pi pi-wallet' },
    { path: '/payroll/payroll-history', label: 'Payroll History', icon: 'pi pi-calendar' },
    { path: '/payroll/legal-laws', label: 'Legal Laws and Policies Guide', icon: 'pi pi-book' },
    { path: '/payroll/query-reply', label: 'Query Management', icon: 'pi pi-comments' },
  ],
};