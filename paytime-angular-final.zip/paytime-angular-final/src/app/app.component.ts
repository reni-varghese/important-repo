import { Component, OnInit, HostListener } from '@angular/core';
import { SidebarComponent } from '../app/shared/components/sidebar/sidebar.component';
import { SharedModule } from './shared/shared.module';
import { Router, NavigationEnd } from '@angular/router';
import { animate, style, transition, trigger } from '@angular/animations';
import { SessionTimeoutService } from './services/session-timeout.service';

interface SideNavToggle {
  screenWidth: number;
  collapsed: boolean;
}

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('350ms', style({ opacity: 1 }))
      ])
    ])
  ]
})
export class AppComponent implements OnInit {
  title = 'my-ptm-fe';
  isSideNavCollapsed = false;
  screenWidth = 0;
  showSidebar: boolean = true;

  constructor(private router: Router, private sessionTimeoutService: SessionTimeoutService) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.showSidebar = !event.url.includes('login') && !event.url.includes('forgot-password') && !event.url.includes('notfound');
      
      }
    });
  }

  ngOnInit() {
    this.sessionTimeoutService.startSessionTimer();
  }

  @HostListener('document:mousemove')
  @HostListener('document:keydown')
  resetSessionTimer() {
    this.sessionTimeoutService.startSessionTimer();
  }

  displayNone() {
    const currentRoute = this.router.url;
    return currentRoute !== '/auth/login' && currentRoute !== '/auth/forgot-password' && currentRoute !== '/notfound' ? '' : 'hide';
  }

  getBodyClass1() {
    const currentRoute = this.router.url;
    let styleClass = '';
    if (this.isSideNavCollapsed && this.screenWidth > 768) {
      styleClass = 'body-trimmed';
    } else if (this.isSideNavCollapsed && this.screenWidth <= 768 && this.screenWidth > 0) {
      styleClass = 'body-md-screen';
    }
    return currentRoute !== '/auth/login' && currentRoute !== '/auth/forgot-password' && currentRoute !== '/notfound' ? styleClass : 'bg-class';
  }

  getCardClass() {
    const currentRoute = this.router.url;
    return currentRoute !== '/auth/login' && currentRoute !== '/auth/forgot-password' && currentRoute !== '/notfound' ? 'card' : '';
  }

  onToggleSideNav(data: SideNavToggle): void {
    this.screenWidth = data.screenWidth;
    this.isSideNavCollapsed = data.collapsed;
  }

  getBodyClass(): string {
    let styleClass = '';
    if (this.isSideNavCollapsed && this.screenWidth > 768) {
      styleClass = 'body-trimmed';
    } else if (this.isSideNavCollapsed && this.screenWidth <= 768 && this.screenWidth > 0) {
      styleClass = 'body-md-screen';
    }
    return styleClass;
  }
}