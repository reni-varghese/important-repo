import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from './core/auth.guard';
import { NotfoundComponent } from './shared/components/notfound/notfound.component'; // Corrected import

const routes: Routes = [
  { path: '', redirectTo: 'auth/login', pathMatch: 'full' },
  { path: 'admin', loadChildren: () => import('./components/admin/admin.module').then(m => m.AdminModule), canActivate: [AuthGuard], data: { expectedRole: 'admin' } },
  { path: 'employee', loadChildren: () => import('./components/employee/employee.module').then(m => m.EmployeeModule), canActivate: [AuthGuard], data: { expectedRole: 'user' } },
  { path: 'payroll', loadChildren: () => import('./components/payroll/payroll.module').then(m => m.PayrollModule), canActivate: [AuthGuard], data: { expectedRole: 'payroll' } },
  { path: 'auth', loadChildren: () => import('./components/auth/auth.module').then(m => m.AuthModule) },
  { path: '**', redirectTo:'notfound' },
  {path:'notfound',component: NotfoundComponent} 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }