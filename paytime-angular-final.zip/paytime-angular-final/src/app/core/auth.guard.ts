import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { AuthService } from '../components/auth/auth.service';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { DialogService } from '../components/auth/dialog.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router, private dialogService: DialogService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | boolean {
    if (this.authService.isLoggedIn()) {
      const expectedRole = route.data['expectedRole'];
      return this.authService.getUserRole().pipe(
        map(currentRole => {
          if (expectedRole) {
            if (Array.isArray(expectedRole)) {
              if (!expectedRole.includes(currentRole)) {
                console.log("Unauthorized access - role mismatch (array)");
                this.dialogService.showUnauthorizedDialog();
                return false;
              }
            } else if (currentRole !== expectedRole) {
              // Specific role-based restrictions
              if (currentRole === 'admin' && expectedRole === 'payroll') {
                console.log("Unauthorized access - admin cannot access payroll");
                this.dialogService.showUnauthorizedDialog();
                return false;
              } else if (currentRole === 'payroll' && expectedRole === 'admin') {
                console.log("Unauthorized access - payroll cannot access admin");
                this.dialogService.showUnauthorizedDialog();
                return false;
              } else if (currentRole === 'user' && expectedRole !== 'user') {
                  console.log("Unauthorized access - user can only access user dashboard");
                  this.dialogService.showUnauthorizedDialog();
                  return false;
              }
              else if ((currentRole === 'admin' || currentRole === 'payroll') && expectedRole === 'user'){
                  return true;
              }
              else{
                console.log("Unauthorized access - role mismatch");
                this.dialogService.showUnauthorizedDialog();
                return false;
              }
            }
          }
          return true;
        }),
        catchError(() => {
          console.log("Error fetching user role");
          this.dialogService.showUnauthorizedDialog();
          return of(false);
        })
      );
    } else {
      console.log("Unauthorized access - not logged in");
      this.dialogService.showUnauthorizedDialog();
      return false;
    }
  }
}