import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
   const token = sessionStorage.getItem('token');
    console.log('Interceptor called'); // Log to ensure interceptor is called
    console.log('Token:', token); // Log the token

    // Check if the request URL includes 'login' or 'forgot-password'
    if (token && !request.url.includes('login') && !request.url.includes('forgot-password')) {
      // Clone the request and add the authorization header
      request = request.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
    }

    return next.handle(request);
  }
}