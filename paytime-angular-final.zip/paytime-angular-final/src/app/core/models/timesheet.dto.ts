export interface TimesheetDto {
    empId: number;
    date: string; // Assuming date is in ISO string format
    clockIn: string; // Assuming time is in string format (e.g., "HH:mm:ss")
    clockOut: string; // Assuming time is in string format (e.g., "HH:mm:ss")
    overTimeHours: number;
  }