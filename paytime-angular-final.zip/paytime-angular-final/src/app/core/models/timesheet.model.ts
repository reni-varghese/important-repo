export class Timesheet {
    empId: number;
    date: Date;
    
    clockIn: string; // Using string to handle time in 'HH:mm' format
    clockOut: string;
    overTimeHours: number; 
  }