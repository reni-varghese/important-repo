export interface Timesheet {

        weeklyTimesheetId: number;
        empId: number;
        weekStart: string; // Using string to represent date in ISO format
        weekEnd: string;   // Using string to represent date in ISO format
        totalHours: number;
        overtimeHours: number;
        status: string;
        feedback?: string; // Optional field
        isResubmitted: boolean;
        actionDate?: string; // Optional field, using string to represent date in ISO format

}
