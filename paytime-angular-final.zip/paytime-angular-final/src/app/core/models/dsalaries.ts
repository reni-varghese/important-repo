export class Salaries{
    salaryId: number;
    empId: number;
    monthYear: string; // Use string to represent date in ISO format (e.g., "2025-02")
    basicpay: number;
    claims: number;
    deductions: number;
    netpay: number;
    empName: string;
    payrollProcessedDate: string;
}