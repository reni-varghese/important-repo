export interface Dcashclaims {
  claimId: number;
  empId: number;
  empName: string;
  dateOfClaim: Date;
  description: string;
  attachment: Uint8Array;
  amount: number;
  remark: string;
  dateOfAction: Date;
  allowanceType: string;
}
