export interface UpdateTimesheet {
  clockIn: string;
  clockOut: string;
  overTimeHours: string;
}
