import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Query } from './query';

@Injectable({
  providedIn: 'root'
})
export class QueryService {

  private apiUrl = 'http://localhost:8081/api/query/payroll';
  private updateFeedbackUrl = 'http://localhost:8081/api/query/payroll'; // Add the URL for updating feedback

  constructor(private http: HttpClient) {}

  getAllSalaryEmployeeDetails(): Observable<Query[]> {
    
    return this.http.get<Query[]>(`${this.apiUrl}`);
  }

  updateFeedback(queryId: number, feedback: string): Observable<any> {
  
    const body = { queryId, feedback };
    return this.http.patch<any>(`${this.updateFeedbackUrl}/${queryId}`, body);
  }
}