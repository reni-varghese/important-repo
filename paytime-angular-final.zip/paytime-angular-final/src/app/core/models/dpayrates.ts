export class PayRate {
    pay_rateid: number;
    empRole: string;
    basicPay: number;
    overtimePay: number;
    pf: number;
    hra: number;
    // lta: number;
    mobileReimbursement: number;
    foodReimbursement: number;
    specialAllowance: number;
    cashAllowance: number;
}    