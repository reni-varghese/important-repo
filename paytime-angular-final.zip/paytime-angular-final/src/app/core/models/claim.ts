    export interface Claim {

        employeeId: number;
        empName: string;
        claimId: number;
        allowanceType: string;
        description: string;
        dateOfClaim: string;
        attachment: string;
        amount: number;
        remark: string;
        dateOfAction: string;
        action :string;
        
    }
