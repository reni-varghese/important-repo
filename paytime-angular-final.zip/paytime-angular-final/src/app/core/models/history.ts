export interface history {
    salaryId: number;
  empId: number;
  empName: string; 
  monthYear: string;
  basicpay: number;
  claims: number;
  deductions: number;
  netpay: number;
  payrollProcessedDate: string;
}