import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { history } from './history';

@Injectable({
  providedIn: 'root'
})
export class PayrollService {
  private apiUrl = 'http://localhost:8081/api/salary/payroll-details';

  constructor(private http: HttpClient) {}

  getAllSalaryEmployeeDetails(): Observable<history[]> {
    
    return this.http.get<history[]>(`${this.apiUrl}`);
  }

  getSalariesByEmpId(empID: number): Observable<history[]> {
   
    return this.http.get<history[]>(`${this.apiUrl}/employee/${empID}`);
  }
}