import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Claim } from './claim';
import { Timesheet } from './timesheet';

@Injectable({
  providedIn: 'root'
})
export class ClaimsServiceService {
  private apiUrl = 'http://localhost:8081/api/claims';
  private timesheetApiUrl = 'http://localhost:8081/weekly-summary';

  constructor(private http: HttpClient) {}

  getClaims(): Observable<Claim[]> {
    return this.http.get<Claim[]>(this.apiUrl);
  }

  updateRemark(id: number, updates: { [key: string]: any }): Observable<void> {
    console.log(`PATCH request to ${this.apiUrl}/remark/${id} with updates:`, updates);
    return this.http.patch<void>(`${this.apiUrl}/remark/${id}`, updates);
  }

  getTimesheets(): Observable<Timesheet[]> {
    return this.http.get<Timesheet[]>(this.timesheetApiUrl);
  }

  updateTimesheet(id: number, updates: { [key: string]: any }): Observable<void> {
    console.log(`PATCH request to ${this.timesheetApiUrl}/partial-update/${id} with updates:`, updates);
    return this.http.patch<void>(`${this.timesheetApiUrl}/partial-update/${id}`, updates);
  }

  getAttachment(id: number): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/attachment/${id}`, { responseType: 'blob' });
  }

  saveClaim(claim: any, file: File): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('claim', new Blob([JSON.stringify(claim)], { type: 'application/json' }));
    if (file) {
        formData.append('file', file, file.name); // Add the filename here
    }

    return this.http.post(this.apiUrl, formData);
}
getTimesheetsByEmpId(empId: number): Observable<Timesheet[]> {
  return this.http.get<Timesheet[]>(`${this.timesheetApiUrl}/id/${empId}`);
}

}