export interface WeeklyTimeSheet {
    weeklyTimesheetId: number;
    empId: number;
    weekStart: string; // Use string to represent date in 'yyyy-MM-dd' format
    weekEnd: string; // Use string to represent date in 'yyyy-MM-dd' format
    totalHours: number;
    overtimeHours: number;
    status: string;
    feedback?: string; // Optional field
    isResubmitted: boolean;
    actionDate: string; // Use string to represent date in 'yyyy-MM-dd' format
  }