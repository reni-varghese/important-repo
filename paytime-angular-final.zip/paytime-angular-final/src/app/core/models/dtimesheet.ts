export interface Dtimesheet {
    empId: number;
    date: string; // Use string to represent date in ISO format (e.g., "2025-02-19")
    clockIn: string; // Use string to represent time (e.g., "08:00:00")
    clockOut: string; // Use string to represent time (e.g., "17:00:00")
    topUpHours: number;
}
