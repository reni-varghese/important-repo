export interface NetSalarySumDTO {
    netSalarySum: number;
  }