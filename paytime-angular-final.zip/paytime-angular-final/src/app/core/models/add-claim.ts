export interface Claim {

    empId: number;
   
    claimId: number;
    allowanceType: string;
    description: string;
    dateOfClaim: string;
    attachment: string;
    amount: number;
    remark: string;
    dateOfAction: string;
    action :string;
    
}
