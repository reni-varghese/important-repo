export interface Query {
    queryId: number;
  category: string;
  dateOfCreated: string;
  dateOfClosed: string;
  description: string;
  empId: number;
  feedback: string;
  status: string;
  empName: string;
}
