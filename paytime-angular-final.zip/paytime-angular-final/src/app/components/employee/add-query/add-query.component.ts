import { Component, OnInit } from '@angular/core';
import { QueryLogService } from '../../../services/employee/query-log.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { QueryLog } from '../../../services/employee/query-log';
import { CreateQueryService } from '../../../services/employee/create-query.service';
import { ConfirmationService, MessageService } from 'primeng/api';

@Component({
  selector: 'app-add-query',
  templateUrl: './add-query.component.html',
  styleUrl: './add-query.component.css',
  providers: [ConfirmationService, MessageService],
  standalone: false
})
export class AddQueryComponent implements OnInit {
  queryLog: any[] = [];
  frozenCols: any[] = [];
  unfrozenCols: any[] = [];
  queryData: FormGroup;
    isDarkTheme: boolean = false;
    isEditMode: boolean = false;
    isDialogVisible: boolean = false;
    empId: string | null = sessionStorage.getItem("empId");

  constructor(private queryLogService: QueryLogService,
    private fb: FormBuilder,
    private createQueryService: CreateQueryService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService) {}

  ngOnInit() {
    this.frozenCols = [{ field: 'queryId', header: 'Query ID' }];

    this.unfrozenCols = [
      { field: 'category', header: 'Category' },
      { field: 'dateOfCreated', header: 'Date Of Creation' },
      { field: 'dateOfClosed', header: 'Resolved Date' },
      { field: 'description', header: 'Description' },
      { field: 'status', header: 'Status' },
      { field: 'feedback', header: 'Feedback' },
    ];

    this.queryLogService.getQueryLog().subscribe((res) => {
      this.queryLog = res;
      console.log(this.queryLog);
    });

    this.queryData = this.fb.group({
      queryDesc: ['', Validators.required],
      queryCategory: ['', Validators.required],
    });
  }
  onEdit(): void {
    this.isEditMode = true; // You can keep this if you use it elsewhere
    this.isDialogVisible = true; // Show the dialog

  }

  onDialogHide(): void {
    this.isDialogVisible = false; // Hide the dialog
    this.isEditMode = false; // Optionally reset edit mode flag
  }

  onSubmit(): void {
    console.log("enter");
      if (this.queryData.valid) {

        this.confirmationService.confirm({
          message: 'Do you want to submit this claim?',
          accept: () => {
            console.log("if state");
        const queryDetails: QueryLog = {
          empId: this.empId,
          description: this.queryData.value.queryDesc,
          category: this.queryData.value.queryCategory,
        };
        console.log("Details: ", queryDetails);

        this.createQueryService.addQuery(queryDetails).subscribe(response => {
          console.log('Query Created successfully with query id: ',response.queryId);
          console.log(response);
          this.queryData.reset();
          this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Query submitted successfully' });
          this.isDialogVisible = false; // Hide dialog on success
          this.isEditMode = false; // Reset edit mode
          // Optionally refresh employee data here to reflect changes
          this.queryLogService.getQueryLog().subscribe((data) => {
            this.queryLog = data;
            // Re-patch form if needed or just update displayed employee object
          });
        }, error => {
          console.error('Error updating employee details', error);
          // Handle error display to user (e.g., using a toast or message service)
        });
          },
          reject: () =>{
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Query submission cancelled' });
          }
        });
      }
    }
}
 