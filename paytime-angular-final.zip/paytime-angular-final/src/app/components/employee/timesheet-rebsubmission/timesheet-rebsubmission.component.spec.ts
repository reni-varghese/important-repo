import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TimesheetRebsubmissionComponent } from './timesheet-rebsubmission.component';

describe('TimesheetRebsubmissionComponent', () => {
  let component: TimesheetRebsubmissionComponent;
  let fixture: ComponentFixture<TimesheetRebsubmissionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TimesheetRebsubmissionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TimesheetRebsubmissionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
