import { Component } from '@angular/core';
import { TimesheetDto } from '../../../core/models/timesheet.dto';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TimesheetService } from '../../../services/timesheet-service.service';
import { Router } from '@angular/router';
import { SharedDateService } from '../../../services/employee/shared-date.service';
import { ConfirmationService, MessageService } from 'primeng/api';
 
@Component({
  selector: 'app-timesheet-rebsubmission',
  templateUrl: './timesheet-rebsubmission.component.html',
  styleUrl: './timesheet-rebsubmission.component.css',
  providers: [ConfirmationService, MessageService],
  standalone: false
})
export class TimesheetRebsubmissionComponent {
  navigateBack() {
      this.router.navigate(['/employee/timesheet-summary-emp']);
    }
 
    timesheetData: TimesheetDto[] = [];
    displayDialog: boolean = false;
    selectedRow: TimesheetDto | null = null;
    editForm: FormGroup;
    empId: string;
    fromDate: Date;
    toDate: Date;
 
    constructor(
      private timesheetService: TimesheetService,
      private router: Router,
      private fb: FormBuilder,
      private sharedDateService: SharedDateService,
      private confirmationService: ConfirmationService,
      private messageService: MessageService
    ) {
      this.editForm = this.fb.group({
        date: ['', Validators.required],
        clockIn: ['', Validators.required],
        clockOut: ['', Validators.required],
        overTimeHours: [{ value: 0, disabled: false }, Validators.required], // Initialize to 0, readonly
      });
    }
 
    ngOnInit() {
      this.empId = sessionStorage.getItem('empId');
      this.fromDate = this.sharedDateService.getWeekStart();
      this.toDate = this.sharedDateService.getWeekEnd();
 
      if (this.empId !== null) {
        this.timesheetService
          .getTimesheetData(this.empId, this.fromDate, this.toDate)
          .subscribe((res: TimesheetDto[]) => {
            this.timesheetData = res;
            console.log(this.timesheetData);
          });
      }
    }
 
    showDialog(row: TimesheetDto) {
      this.selectedRow = row;
      this.editForm.patchValue({
        date: row.date,
        clockIn: row.clockIn.substring(0, 5),
        clockOut: row.clockOut.substring(0, 5),
        overTimeHours: row.overTimeHours,
      });
      this.calculateTopUpHours();
      this.displayDialog = true;
    }
 
    submitRow() {
      if (this.editForm.valid && this.selectedRow) {
       
        this.confirmationService.confirm({
          message: '',
          accept: () =>{
            const updatedRow = {
              ...this.selectedRow,
              ...this.editForm.value,
            };
            console.log("FORM:");
            console.log(this.editForm.value);
            console.log('Updated Row:', updatedRow);
            this.displayDialog = false;
   
            this.timesheetService.updateWeeklyTimesheetByDate(updatedRow).subscribe(
              (addedTimesheet) => {
                console.log('Timesheet updated:', addedTimesheet);
                // Handle successful addition (e.g., refresh data)
                this.timesheetService
                .getTimesheetData(this.empId, this.fromDate, this.toDate)
                .subscribe((res: TimesheetDto[]) => {
                  this.timesheetData = res;
                  console.log(this.timesheetData);
                  this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Weekly Timesheet updated successfully' });
                 
                });
              },
              (error) => {
                console.error('Error updating timesheet:', error);
              }
            );
          },
          reject: () =>{
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Updating weekly timesheet cancelled' });
          }
         
        });
 
      }
    }
 
    cancelEdit() {
      this.displayDialog = false;
      this.editForm.reset();
    }
 
    calculateTopUpHours() {
      const clockIn = this.editForm.get('clockIn')?.value;
      const clockOut = this.editForm.get('clockOut')?.value;
 
      if (clockIn && clockOut) {
          const clockInTime = this.timeStringToMinutes(clockIn);
          const clockOutTime = this.timeStringToMinutes(clockOut);
          let diff = clockOutTime - clockInTime;
          if (diff < 0) {
              diff += 24 * 60;
          }
          const diffHours = diff / 60;
          const overTimeHours = diffHours > 10 ? (diffHours-10) : 0;
          this.editForm.patchValue({ overTimeHours: overTimeHours });
      } else {
          this.editForm.patchValue({ overTimeHours: 0 });
      }
  }
 
  timeStringToMinutes(time: string): number {
      const [hours, minutes] = time.split(':').map(Number);
      return hours * 60 + minutes;
  }
}
 