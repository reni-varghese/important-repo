import { Component, OnInit } from '@angular/core';
import { SalaryOverviewService } from '../../../services/employee/salary-overview.service';
import {jsPDF } from 'jspdf';
import 'jspdf-autotable';

@Component({
  selector: 'app-salary-overview',
  standalone: false,
  templateUrl: './salary-overview.component.html',
  styleUrl: './salary-overview.component.css'
})
export class SalaryOverviewComponent implements OnInit {
  data: any[] = [];
  frozenCols: any[] = [];
  unfrozenCols: any[] = [];
  loading: boolean = false;
  constructor(private salaryTableService: SalaryOverviewService) {}

  ngOnInit() {
    this.frozenCols = [
      { field: 'salaryId', header: 'Salary ID' }
    ];

    this.unfrozenCols = [
      { field: 'monthYear', header: 'Month' },
      { field: 'basicPay', header: 'Basic Pay' },
      { field: 'claims', header: 'Claims' },
      { field: 'deductions', header: 'Deductions' },
      { field: 'netPay', header: 'Net Pay' },
      { field: 'payrollProcessedDate', header: 'Processed' }
    ];

    this.salaryTableService.getData().subscribe((res) => {
      
      this.data = res;
      
      console.log(this.data);
      

    });
  }

  generatePDF(row: any) {

    const employeeId = sessionStorage.getItem('employeeId'); // Retrieve Employee ID from session storage

    const doc = new jsPDF();

    // Add a title
    doc.setFontSize(18);
    doc.setTextColor(40);

    doc.text('PayTime Manager', 105, 10, { align: 'center' });

    doc.setFontSize(12);
    doc.text('This document contains the salary details for the specified month.', 105, 20, { align: 'center' });
    doc.setFontSize(12);
    // Add a line below the title
    doc.setLineWidth(0.5);
    doc.line(10, 15, 200, 15);

    // Add table
    (doc as any).autoTable({
      startY: 40,
      head: [['Field', 'Value']],
      body: [
        ['Employee ID', sessionStorage.getItem("empId")],
        ['Salary ID', row.salaryId],
        ['Month', row.monthYear],
        ['Basic Pay', row.basicPay],
        ['Claims', row.claims],
        ['Deductions', row.deductions],
        ['Net Pay', row.netPay],
        ['Processed Date', row.payrollProcessedDate]
      ],
      theme: 'grid',
      headStyles: { fillColor: [41, 128, 185] },
      bodyStyles: { fillColor: [255, 255, 255] },
      alternateRowStyles: { fillColor: [240, 240, 240] },
      styles: { fontSize: 12 }
    });

    // Save the PDF
  //   doc.save(`Salary_${row.salaryId}.pdf`);
  // }
  // Open the PDF in a new tab
  const pdfOutput = doc.output('blob');
  const pdfUrl = URL.createObjectURL(pdfOutput);
  window.open(pdfUrl, '_blank');

  }
}