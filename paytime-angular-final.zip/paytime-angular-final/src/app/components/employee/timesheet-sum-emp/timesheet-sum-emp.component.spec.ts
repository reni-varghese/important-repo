import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TimesheetSumEmpComponent } from './timesheet-sum-emp.component';

describe('TimesheetSumEmpComponent', () => {
  let component: TimesheetSumEmpComponent;
  let fixture: ComponentFixture<TimesheetSumEmpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TimesheetSumEmpComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TimesheetSumEmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
