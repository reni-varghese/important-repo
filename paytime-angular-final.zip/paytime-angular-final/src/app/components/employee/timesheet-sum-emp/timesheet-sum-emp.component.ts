import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TimesheetService } from '../../../services/timesheet-service.service';
import { TimesheetDto } from '../../../core/models/timesheet.dto';
import { Timesheet } from '../../../core/models/timesheet';
import { ClaimsServiceService } from '../../../core/models/claims-service.service';
import { Router } from '@angular/router';
import { SharedDateService } from '../../../services/employee/shared-date.service';

@Component({
  selector: 'app-timesheet',
  templateUrl: './timesheet-sum-emp.component.html',
  styleUrls: ['./timesheet-sum-emp.component.css'],
  standalone: false,
})
export class TimesheetSumEmpComponent implements OnInit {
  timesheetTable: Timesheet[] = [];
  empId: string;

  @ViewChild('dt5') dt5: any;

  constructor(
    private fb: FormBuilder,
    private timesheetService: TimesheetService,
    private claimsService: ClaimsServiceService,
    private router: Router,
    private sharedDate: SharedDateService
  ) {
    this.empId = sessionStorage.getItem('empId');
  }

  ngOnInit(): void {
    this.fetchTimesheetsSummary();
  }

  fetchTimesheetsSummary(): void {
    const empIdString = sessionStorage.getItem('empId');
    const empId = parseInt(empIdString, 10);

    this.claimsService.getTimesheetsByEmpId(empId).subscribe({
      next: (data: Timesheet[]) => {
        this.timesheetTable = data;
        console.log(this.timesheetTable);
      },
      error: (error) => {
        console.error('Error fetching timesheets:', error);
      },
    });
  }

  navigateToTimesheetDetails(timesheet: Timesheet): void {
    const fromString = timesheet.weekStart;
    const toString = timesheet.weekEnd;
    const startDate = new Date(fromString);
    const endDate = new Date(toString);

    this.sharedDate.setWeekDates(startDate, endDate);

    this.router.navigate(['/employee/timesheet-rebsubmission']);
  }

  getSeverity(
    status: string
  ): 'success' | 'secondary' | 'info' | 'warn' | 'danger' | 'contrast' {
    switch (status) {
      case 'Approved':
        return 'success';
      case 'Pending':
        return 'warn';
      case 'Rejected':
        return 'danger';
      default:
        return 'info';
    }
  }
}