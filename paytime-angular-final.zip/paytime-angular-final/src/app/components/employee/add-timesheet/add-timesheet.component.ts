import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { TimesheetService } from '../../../services/timesheet-service.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import  {WeeklyTimeSheet} from '../../../core/models/WeeklyTimeSheet.model'

@Component({
  selector: 'app-add-timesheet',
  templateUrl: './add-timesheet.component.html',
  styleUrls: ['./add-timesheet.component.css'],
  providers: [MessageService,DatePipe],
  standalone: false
})
export class AddTimesheetComponent implements OnInit {
  timesheetForm: FormGroup;
  isLoading = false;

  constructor(
    private fb: FormBuilder,
    private timesheetService: TimesheetService,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private datePipe: DatePipe,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.timesheetForm = this.fb.group({
      date: ['', [Validators.required, this.dateValidator]],
      shift: ['', Validators.required],
      clockIn: ['', [Validators.required, this.shiftValidator.bind(this)]],
      clockOut: ['', [Validators.required, this.clockOutValidator.bind(this)]]
    });
  }

  onSubmit() {
    if (this.timesheetForm.valid) {
      this.confirmationService.confirm({
        message: 'Are you sure you want to submit the timesheet?',
        accept: () => {
          this.isLoading = true;
          this.confirmSubmit();
        }
      });
    }
  }

  confirmSubmit() {
    const formValues = this.timesheetForm.value;
    const overTimeHours = this.calculateOverTimeHours(formValues.clockIn, formValues.clockOut);
    const empId = Number(sessionStorage.getItem('empId')); // Convert empId to number
    if (isNaN(empId)) {
      console.error('Invalid empId');
      this.isLoading = false;
      return;
    }
    const timesheet = {
      empId,
      date: formValues.date,
      shift: formValues.shift,
      clockIn: this.formatTime(formValues.clockIn),
      clockOut: this.formatTime(formValues.clockOut),
      overTimeHours
    };
    console.log(timesheet);
    this.timesheetService.addTimesheet(timesheet).subscribe(response => {
      this.isLoading = false;
      this.messageService.add({severity: 'success', summary: 'Success', detail: 'Timesheet submitted successfully'});
      this.timesheetForm.reset();
    }, error => error => {
      console.error('Error submitting weekly timesheet:', error);
      const errorMessage = error?.error?.message || 'Error submitting weekly timesheet';
      this.messageService.add({severity: 'error', summary: 'Error', detail: errorMessage});
    });
  }

  formatTime(time: string): string {
    return `${time}:00`; // Append seconds to the time string
  }

  calculateOverTimeHours(clockIn: string, clockOut: string): number {
    const clockInTime = new Date(`1970-01-01T${clockIn}:00`);
    const clockOutTime = new Date(`1970-01-01T${clockOut}:00`);
    const diff = (clockOutTime.getTime() - clockInTime.getTime()) / (1000 * 60 * 60);
    return diff > 10 ? diff - 10 : 0;
  }

  dateValidator(control: AbstractControl): { [key: string]: boolean } | null {
    const today = new Date();
    const selectedDate = new Date(control.value);
    if (selectedDate > today) {
      return { invalidDate: true };
    }
    return null;
  }

  shiftValidator(control: AbstractControl): { [key: string]: boolean } | null {
    const shift = this.timesheetForm?.get('shift')?.value;
    const clockIn = control.value;
    if (shift === 'day' && clockIn < '08:00') {
      return { invalidClockIn: true };
    }
    if (shift === 'night' && clockIn < '20:00') {
      return { invalidClockIn: true };
    }
    return null;
  }

  clockOutValidator(control: AbstractControl): { [key: string]: boolean } | null {
    const shift = this.timesheetForm?.get('shift')?.value;
    const clockOut = control.value;
    if (shift === 'day' && clockOut < '18:00') {
      return { invalidClockOut: true };
    }
    if (shift === 'night' && clockOut < '06:00') {
      return { invalidClockOut: true };
    }
    return null;
  }
  navigateToUpdate() {
    this.router.navigate(['/employee/update-timesheet']);
  }
  isWeekend(): boolean {
    const today = new Date();
    const day = today.getDay();
    return day === 0 || day === 6 ; // 0 = Sunday, 6 = Saturday
  }

  submitWeeklyTimesheet() {
    const empId = Number(sessionStorage.getItem('empId')); // Convert empId to number
    if (isNaN(empId)) {
      console.error('Invalid empId');
      this.messageService.add({severity: 'error', summary: 'Error', detail: 'Invalid employee ID'});
      return;
    }
    // const currentDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    const currentDate = '2024-07-09'
    if (!currentDate) {
      console.error('Invalid current date');
      this.messageService.add({severity: 'error', summary: 'Error', detail: 'Invalid current date'});
      return;
    }

    this.timesheetService.submitWeeklyTimesheet(empId, currentDate).subscribe((response: WeeklyTimeSheet) => {
      console.log('Weekly timesheet response:', response);
      this.messageService.add({severity: 'success', summary: 'Success', detail: 'Weekly timesheet submitted successfully'});
    }, error => {
      console.error('Error submitting weekly timesheet:', error);
      const errorMessage = error?.error?.message || 'Error submitting weekly timesheet';
      this.messageService.add({severity: 'error', summary: 'Error', detail: errorMessage});
    });
  }
}
