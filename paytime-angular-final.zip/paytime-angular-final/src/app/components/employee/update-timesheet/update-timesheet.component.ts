import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TimesheetService } from '../../../services/timesheet-service.service';
import { Dtimesheet } from '../../../core/models/dtimesheet';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TimesheetDto } from '../../../core/models/timesheet.dto';
import { SharedDateService } from '../../../services/employee/shared-date.service';
 
@Component({
  selector: 'app-update-timesheet',
  templateUrl: './update-timesheet.component.html',
  styleUrls: ['./update-timesheet.component.css'],
  standalone: false,
})
export class UpdateTimesheetComponent implements OnInit {
  navigateToAddNew() {
    this.router.navigate(['/employee/add-timesheet']);
  }
 
  timesheetData: TimesheetDto[] = [];
  displayDialog: boolean = false;
  selectedRow: Dtimesheet | null = null;
  editForm: FormGroup;
  empId: string;
  fromDate: Date;
  toDate: Date;
 
  constructor(
    private timesheetService: TimesheetService,
    private router: Router,
    private fb: FormBuilder,
    // private sharedDateService: SharedDateService
  ) {
    this.editForm = this.fb.group({
      date: ['', Validators.required],
      clockIn: ['', Validators.required],
      clockOut: ['', Validators.required],
      topUpHours: [{ value: 0, disabled: false }, Validators.required], // Initialize to 0, readonly
    });
  }
 
  ngOnInit() {
    this.empId = sessionStorage.getItem('empId');
    const fromDateString = '2024-07-21';
    this.fromDate = new Date(fromDateString);
    const toDateString = '2024-07-25';
    this.toDate = new Date(toDateString);
    // const fromDate = this.sharedDateService.getWeekStart();
    //   const toDate = this.sharedDateService.getWeekEnd();
 
    if (this.empId !== null) {
      this.timesheetService
        .getTimesheetData(this.empId, this.fromDate, this.toDate)
        .subscribe((res: TimesheetDto[]) => {
          this.timesheetData = res;
          console.log(this.timesheetData);
        });
    }
  }
 
  showDialog(row: Dtimesheet) {
    this.selectedRow = row;
    this.editForm.patchValue({
      date: row.date,
      clockIn: row.clockIn.substring(0, 5),
      clockOut: row.clockOut.substring(0, 5),
      topUpHours: row.topUpHours,
    });
    this.calculateTopUpHours();
    this.displayDialog = true;
  }
 
  submitRow() {
    if (this.editForm.valid && this.selectedRow) {
      const updatedRow = {
        ...this.selectedRow,
        ...this.editForm.value,
      };
      this.timesheetService.updateTimesheetByDate(updatedRow).subscribe(
        (addedTimesheet) => {
          console.log('Timesheet updated:', addedTimesheet);
          // Handle successful addition (e.g., refresh data)
          this.timesheetService
          .getTimesheetData(this.empId, this.fromDate, this.toDate)
          .subscribe((res: TimesheetDto[]) => {
            this.timesheetData = res;
            console.log(this.timesheetData);
          });
        },
        (error) => {
          console.error('Error updating timesheet:', error);
        }
      );
      console.log('Updated Row:', updatedRow);
      this.displayDialog = false;
 
     
 
    }
  }
 
  cancelEdit() {
    this.displayDialog = false;
    this.editForm.reset();
  }
 
  calculateTopUpHours() {
    const clockIn = this.editForm.get('clockIn')?.value;
    const clockOut = this.editForm.get('clockOut')?.value;
 
    if (clockIn && clockOut) {
      const clockInTime = this.timeStringToMinutes(clockIn);
      const clockOutTime = this.timeStringToMinutes(clockOut);
      let diff = clockOutTime - clockInTime;
      if (diff < 0) {
        diff += 24 * 60;
      }
      const diffHours = diff / 60;
      const topUp = diffHours > 10 ? diffHours : 0;
      this.editForm.patchValue({ topUpHours: topUp });
    } else {
      this.editForm.patchValue({ topUpHours: 0 });
    }
  }
 
  timeStringToMinutes(time: string): number {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  }
}