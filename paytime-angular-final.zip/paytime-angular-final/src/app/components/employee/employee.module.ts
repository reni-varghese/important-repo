import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeDashboardComponent } from './employee-dashboard/employee-dashboard.component';
import { AddTimesheetComponent } from './add-timesheet/add-timesheet.component';
import { TimesheetSumEmpComponent } from './timesheet-sum-emp/timesheet-sum-emp.component';
import { AddCashClaimsComponent } from './add-cash-claims/add-cash-claims.component';
import { SalaryOverviewComponent } from './salary-overview/salary-overview.component';
import { AddQueryComponent } from './add-query/add-query.component';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { TabViewModule } from 'primeng/tabview';
import { CardModule } from 'primeng/card';
import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { DropdownModule } from 'primeng/dropdown';
import { MultiSelectModule } from 'primeng/multiselect';
import { IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { ButtonModule } from 'primeng/button';
import { SelectModule } from 'primeng/select';
import { DatePickerModule } from 'primeng/datepicker';


import { DialogModule } from 'primeng/dialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { CalendarModule } from 'primeng/calendar';
import { ConfirmationService } from 'primeng/api';
import { HttpClientModule } from '@angular/common/http';
import { IftaLabelModule } from 'primeng/iftalabel';
import { LeaveOverviewComponent } from './leave-overview/leave-overview.component';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { UpdateTimesheetComponent } from './update-timesheet/update-timesheet.component';
import { TagModule } from 'primeng/tag';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TimesheetRebsubmissionComponent } from './timesheet-rebsubmission/timesheet-rebsubmission.component';
// import { TimesheetResubmissionComponent } from './timesheet-resubmission/timesheet-resubmission.component';

const employeeRoutes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' }, // Default route
  { path: 'dashboard', component: EmployeeDashboardComponent },
  { path: 'add-timesheet', component: AddTimesheetComponent },
  { path: 'update-timesheet', component: UpdateTimesheetComponent },
  { path: 'cash-claims', component: AddCashClaimsComponent },
  { path: 'timesheet-summary-emp', component: TimesheetSumEmpComponent },
  { path: 'add-query', component: AddQueryComponent },
  { path: 'salary-overview', component: SalaryOverviewComponent },
  {path:'timesheet-rebsubmission',component:TimesheetRebsubmissionComponent}
];

@NgModule({
  declarations: [
    EmployeeDashboardComponent,
    AddTimesheetComponent,
    TimesheetSumEmpComponent,
    AddCashClaimsComponent,
    SalaryOverviewComponent,
    AddQueryComponent,
    EmployeeComponent,
    LeaveOverviewComponent,
    UpdateTimesheetComponent,
    TimesheetRebsubmissionComponent,
    // TimesheetResubmissionComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    HttpClientModule,
    ReactiveFormsModule,
    TabViewModule,
    CardModule,
    TableModule,
    PaginatorModule,
    DropdownModule,
    MultiSelectModule,
    InputIconModule,
    IconFieldModule,
    ButtonModule,
    SelectModule,
    DatePickerModule,
    DialogModule,
    IftaLabelModule,
    CalendarModule,
    DialogModule,
    ConfirmDialogModule,
    CalendarModule,
    ToastModule,
    TagModule,
    ProgressSpinnerModule,
    RouterModule.forChild(employeeRoutes)
  ],
  providers: [
    ConfirmationService,
    MessageService
  ]
})
export class EmployeeModule { }