import { Component } from '@angular/core';

@Component({
  selector: 'app-leave-overview',
  standalone: false,
  templateUrl: './leave-overview.component.html',
  styleUrl: './leave-overview.component.css'
})
export class LeaveOverviewComponent {

}
