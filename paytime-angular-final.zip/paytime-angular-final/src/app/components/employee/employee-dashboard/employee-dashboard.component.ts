import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { EmployeeDashboardService } from '../../../services/employee/employee-dashboard.service';

import { UpdateBankDetails } from '../../../services/employee/update-bank-details';
import { UpdateUserDetails } from '../../../services/employee/update-user-details';
import { EmployeeDetails } from '../../../services/employee/employee-details';

@Component({
  selector: 'app-employee-dashboard',
  standalone: false,
  templateUrl: './employee-dashboard.component.html',
  styleUrl: './employee-dashboard.component.css',
})
export class EmployeeDashboardComponent implements OnInit {
  employee: EmployeeDetails;
  updateUserDetails: any;
  userDetailsForm: FormGroup;
  bankDetailsForm: FormGroup;
  activeTab: number = 0;
  isDarkTheme: boolean = false;
  isEditMode: boolean = false;
  isUserDialogVisible: boolean = false;
  isBankDialogVisible: boolean = false; // For dialog visibility
  genderOptions = [
    { label: 'Male', value: 'Male' },
    { label: 'Female', value: 'Female' },
    { label: 'Other', value: 'Other' },
  ];
  bloodGroupOptions = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(group => ({label: group, value: group})); // Example Blood Groups
  maritalStatusOptions = ['Single', 'Married', 'Divorced', 'Widowed'].map(status => ({label: status, value: status}));

  constructor(
    private fb: FormBuilder,
    private employeeService: EmployeeDashboardService,
  ) {}

  ngOnInit(): void {
    this.userDetailsForm = this.fb.group({
      empName: ['', Validators.required],
      empGender: ['', Validators.required],
      empDob: ['', Validators.required],
      empPhoneNo: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
      empEmail: ['', [Validators.required, Validators.email]],
      empNationalId: ['', [Validators.required]],
      empBloodGroup: ['', [Validators.required]],
      empMaritalStatus: ['', [Validators.required]],
    });

    this.bankDetailsForm = this.fb.group({
      bankName: ['', Validators.required],
      accountHolderName: ['', Validators.required],
      accountNumber: ['', Validators.required],
      ifscCode: ['', Validators.required],
      branch: ['', Validators.required],
    });

    this.employeeService.getEmployeeDetails().subscribe((data) => {
      this.employee = data;
      
    });
  }

  onUserEdit(): void {
    // this.isEditMode = true; // You can keep this if you use it elsewhere
    this.isUserDialogVisible = true; // Show the dialog
    
    this.userDetailsForm.patchValue({
      empName: this.employee.empName,
      empGender: this.employee.empGender,
      empDob: new Date(this.employee.empDob), // Ensure date is in correct format
      empPhoneNo: this.employee.empPhoneNo,
      empEmail: this.employee.empEmail,
      empNationalId: this.employee.empNationalId,
      empBloodGroup: this.employee.empBloodGroup,
      empMaritalStatus: this.employee.empMaritalStatus,
    });
  }

  onBankEdit(): void {
    // this.isEditMode = true; // You can keep this if you use it elsewhere
    this.isBankDialogVisible = true; // Show the dialog
    
    this.bankDetailsForm.patchValue({
      bankName: this.employee.bankName,
      accountHolderName: this.employee.accountHolderName,
      accountNumber: this.employee.accountNumber, // Ensure date is in correct format
      ifscCode: this.employee.ifscCode,
      branch: this.employee.branch,
    });
  }

  onDialogHide(): void {
    this.isUserDialogVisible = false; // Hide the dialog
    this.isBankDialogVisible = false;
  }

  onUserSubmit(): void {
    if (this.userDetailsForm.valid) {
      const updatedUserDetails: UpdateUserDetails = {
        empName: this.userDetailsForm.value.empName,
        empEmail: this.userDetailsForm.value.empEmail,
        empDob: this.userDetailsForm.value.empDob.toISOString().split('T')[0], // Format date as YYYY-MM-DD
        empBloodGroup: this.userDetailsForm.value.empBloodGroup,
        empGender: this.userDetailsForm.value.empGender,
        empMaritalStatus: this.userDetailsForm.value.empMaritalStatus,
        empNationalId: this.userDetailsForm.value.empNationalId,
        empPhoneNo: this.userDetailsForm.value.empPhoneNo,
      };
      console.log("Details: ", updatedUserDetails);

      this.employeeService.updateEmployeeDetails(updatedUserDetails).subscribe(response => {
        console.log('Employee details updated successfully', response);
        this.isUserDialogVisible = false; // Hide dialog on success
        // Optionally refresh employee data here to reflect changes
        this.employeeService.getEmployeeDetails().subscribe((data) => {
          this.employee = data;
          // Re-patch form if needed or just update displayed employee object
        });
      }, error => {
        console.error('Error updating employee details', error);
        // Handle error display to user (e.g., using a toast or message service)
      });
    }
  }

  onBankSubmit(): void {
    if (this.bankDetailsForm.valid) {
      const updatedBankDetails: UpdateBankDetails = {
        bankName: this.bankDetailsForm.value.bankName,
        accountHolderName: this.bankDetailsForm.value.accountHolderName,
        accountNumber: this.bankDetailsForm.value.accountNumber, // Format date as YYYY-MM-DD
        ifscCode: this.bankDetailsForm.value.ifscCode,
        branch: this.bankDetailsForm.value.branch,
      };
      console.log("Details: ", updatedBankDetails);

      this.employeeService.updateBankDetails(updatedBankDetails).subscribe(response => {
        console.log('Bank details updated successfully', response);
        this.isBankDialogVisible = false; // Hide dialog on success
        this.isEditMode = false; // Reset edit mode
        // Optionally refresh employee data here to reflect changes
        this.employeeService.getEmployeeDetails().subscribe((data) => {
          this.employee = data;
          // Re-patch form if needed or just update displayed employee object
        });
      }, error => {
        console.error('Error updating Bank details', error);
        // Handle error display to user (e.g., using a toast or message service)
      });
    }
  }

  onTabChange(event: any) {
    this.activeTab = event.index;
  }
}