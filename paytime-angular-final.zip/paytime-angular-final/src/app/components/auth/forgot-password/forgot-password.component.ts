import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ForgotPasswordService } from '../forgot-password.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css'],
  standalone: false
})
export class ForgotPasswordComponent {
  empEmail: string = '';
  otp: string = '';
  newPassword: string = '';
  confirmPassword: string = '';
  step: number = 1; // 1: Enter email, 2: Enter OTP and new password
  loading: boolean = false;
  displayModal: boolean = false;
  modalMessage: string = '';

  constructor(private router: Router, private forgotPasswordService: ForgotPasswordService) {}

  async sendOtp() {
    this.loading = true;
    try {
      const response = await this.forgotPasswordService.sendOtp(this.empEmail);
      this.loading = false;
      
      if (response.statusCode === 200) {
        this.step = 2;
        this.showModal('OTP sent successfully');
      } else {
        this.showModal('Error in sending OTP');
      }
    } catch (error) {
      this.loading = false;
      this.showModal('Error in sending OTP');
    }
  }

  async verifyAndChangePassword() {
    if (this.newPassword === this.confirmPassword) {
      this.loading = true;
      try {
        const response = await this.forgotPasswordService.verifyAndChangePassword(this.empEmail, this.otp, this.newPassword);
        this.loading = false;
        
        if (response.statusCode === 200) {
          this.showModal('Password changed successfully');
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 2000);
        } else {
          this.showModal('Error in verifying OTP or changing password');
        }
      } catch (error) {
        this.loading = false;
        this.showModal('Error in verifying OTP or changing password');
      }
    } else {
      this.showModal('Passwords do not match');
    }
  }

  showModal(message: string) {
    this.modalMessage = message;
    this.displayModal = true;
  }
}