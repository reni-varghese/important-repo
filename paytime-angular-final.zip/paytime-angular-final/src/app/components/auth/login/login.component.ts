import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { Store } from '@ngrx/store';
import { loginSuccess } from '../../../shared/store/auth.actions';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone: false
})
export class LoginComponent implements OnInit {
  email: string = '';
  password: string = '';
  loading: boolean = false;
  submitted: boolean = false;
  displayErrorModal: boolean = false;
  displaySuccessModal: boolean = false;
  
  constructor(private router: Router, private authService: AuthService, private store: Store) {}

  ngOnInit() {
    
    
    // const hasReloaded = localStorage.getItem('hasReloaded');
    // if (!hasReloaded) {
    //   localStorage.setItem('hasReloaded', 'true');
    //   window.location.reload();
    // }
    
    this.router.navigate([this.router.url]);
  }

  async login() {
    this.submitted = true;
    if (!this.email || !this.password) {
      this.loading = false;
      return;
    }

    this.loading = true;
    try {
      const response = await this.authService.login(this.email, this.password);
      this.loading = false;
      console.log(response);
      sessionStorage.setItem('token', response.token);
      sessionStorage.setItem('empId', response.empId.toString());

      // Dispatch the loginSuccess action
      this.store.dispatch(loginSuccess({ empAccess: response.empAccess }));

      this.displaySuccessModal = true;
      setTimeout(() => {
        this.displaySuccessModal = false;
        this.navigateBasedOnRole(response.empAccess);
      }, 2000);
    } catch (error) {
      this.loading = false;
      this.displayErrorModal = true;
    }
  }

  navigateBasedOnRole(role: string) {
    switch (role) {
      case 'admin':
        this.router.navigate(['/admin']);
        break;
      case 'payroll':
        this.router.navigate(['/payroll']);
        break;
      case 'user':
        this.router.navigate(['/employee']);
        break;
      default:
        this.router.navigate(['/login']);
        break;
    }
  }

  closeModal() {
    this.displayErrorModal = false;
  }
}