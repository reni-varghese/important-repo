import { Injectable } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class DialogService {
  constructor(private confirmationService: ConfirmationService, private router: Router) {}

  showUnauthorizedDialog() {
    this.confirmationService.confirm({
      message: 'Oops! You are not authorized to access this page 😐<br>So you are redirected to login page',
      header: 'Unauthorized',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.router.navigate(['/auth/login']);
      },
      rejectVisible: false, 
      acceptLabel: 'OK', 
      closable: false 
    });
  }
}