import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ForgotPasswordService {
  private apiUrl = 'http://localhost:8081/api/auth';

  constructor(private http: HttpClient) {}

  async sendOtp(email: string): Promise<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const body = JSON.stringify({ email });

    try {
      const response = await this.http.post<any>(`${this.apiUrl}/send-otp`, body, { headers }).toPromise();
      return response;
    } catch (error) {
      console.error('Error:', error);
      throw error;
    }
  }

  async verifyAndChangePassword(empEmail: string, otp: string, newPassword: string): Promise<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const body = JSON.stringify({ empEmail, otp, newPassword });
  
    // Print the body to the console
    console.log('Request Body:', body);
  
    try {
      const response = await this.http.post<any>(`${this.apiUrl}/verify-otp`, body, { headers }).toPromise();
      return response;
    } catch (error) {
      console.error('Error:', error);
      throw error;
    }
  }
}
