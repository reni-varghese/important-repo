import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthRoutingModule } from './auth-routing.module';
import { LoginComponent } from './login/login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { DialogModule } from 'primeng/dialog';
import { FloatLabelModule } from 'primeng/floatlabel';
import { InputOtpModule } from 'primeng/inputotp';
import { PasswordModule } from 'primeng/password';


import { DividerModule } from 'primeng/divider';

@NgModule({
  declarations: [LoginComponent, ForgotPasswordComponent],
  imports: [
    CommonModule,
    FormsModule,
    AuthRoutingModule,
    InputTextModule,
    ButtonModule,
    ProgressSpinnerModule,
    DialogModule,
    FloatLabelModule ,
    InputOtpModule,
    PasswordModule,
    DividerModule
  ]
})
export class AuthModule {}