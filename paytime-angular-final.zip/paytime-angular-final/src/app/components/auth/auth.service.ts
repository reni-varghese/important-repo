import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs';
import { selectEmpAccess } from '../../shared/store/auth.selectors';
import { logout } from '../../shared/store/auth.actions';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = 'http://localhost:8081/api/auth/login';
  private logoutEndpoint = 'http://localhost:8081/api/auth/logout'; // Replace with your actual logout endpoint

  empAccess$: Observable<string | null>;

  constructor(private http: HttpClient, private router: Router, private store: Store) {
    this.empAccess$ = this.store.pipe(select(selectEmpAccess));
  }

  async login(email: string, password: string): Promise<any> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const body = JSON.stringify({ email, password });

    try {
      const response = await this.http.post<any>(`${this.apiUrl}`, body, { headers }).toPromise();
      // Log empAccess after login
      this.empAccess$.subscribe(empAccess => {
        console.log('empAccess:', empAccess);
      });
      return response;
    } catch (error) {
      console.error('Login failed', error);
      throw error;
    }
  }

  isLoggedIn(): boolean {
    return !!sessionStorage.getItem('token');
  }

  getUserRole(): Observable<string | null> {
    
    return this.empAccess$;
    
  }

  async logout(): Promise<void> {
    try {
      await this.http.post(this.logoutEndpoint, {}).toPromise();
      sessionStorage.removeItem('token');
      sessionStorage.removeItem('empId');
      // Dispatch the logout action
      this.store.dispatch(logout());
      await this.router.navigate(['/auth/login']);
    } catch (error) {
      console.error('Logout failed', error);
    }
  }
}