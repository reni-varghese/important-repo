import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RoleOverviewComponent } from './role-overview/role-overview.component';
import { AssignComponent } from './assign/assign.component';
import { PromoteComponent } from './promote/promote.component';
import { DemoteComponent } from './demote/demote.component';

const routes: Routes = [
  { path: '', redirectTo: 'role-overview', pathMatch: 'full' },
  { path: 'role-overview', component: RoleOverviewComponent },
  { path: 'assign', component: AssignComponent},
  { path: 'promote', component: PromoteComponent},
  { path: 'demote', component: DemoteComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RoleAssignRoutingModule { }
