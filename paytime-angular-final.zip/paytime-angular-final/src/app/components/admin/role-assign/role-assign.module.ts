import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoleAssignRoutingModule } from './role-assign-routing.module';
import { PromoteComponent } from './promote/promote.component';
import { DemoteComponent } from './demote/demote.component';
import { AssignComponent } from './assign/assign.component';
import { RoleOverviewComponent } from './role-overview/role-overview.component';
import {  IconFieldModule } from 'primeng/iconfield';
import { InputIconModule } from 'primeng/inputicon';
import { TableModule } from 'primeng/table';
import { InputTextModule } from 'primeng/inputtext';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import {  DropdownModule } from 'primeng/dropdown';
import { DialogModule } from 'primeng/dialog';


@NgModule({
  declarations: [
    PromoteComponent,
    DemoteComponent,
    AssignComponent,
    RoleOverviewComponent
  ],
  imports: [
    CommonModule,
    RoleAssignRoutingModule,
    TableModule,
    InputTextModule,
    IconFieldModule,
    InputIconModule,
    ConfirmDialogModule,
    DropdownModule,
    DialogModule
  ]
})
export class RoleAssignModule { }
