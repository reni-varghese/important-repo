import { Component } from '@angular/core';
import { Employee, EmployeeService } from '../../../../core/models/employee.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-demote',
  standalone: false,
  templateUrl: './demote.component.html',
  styleUrl: './demote.component.css'
})
export class DemoteComponent {
  payrollManagers: Employee[] = []; // Corrected type
  payrollManagerUnfrozenCols = [
    { field: 'empName', header: 'Name' },
    { field: 'empEmail', header: 'Email' },
    
  ];

  constructor(
    private employeeService: EmployeeService,
    private confirmationService: ConfirmationService
  ) {}

  ngOnInit(): void {
    this.getPayrollManagers();
  }

  getPayrollManagers() {
    this.employeeService.getAllPayrollManagers().subscribe( // Corrected method call
      (employees) => {

        this.payrollManagers = employees;
        console.log(this.payrollManagers);
      },
      (error) => {
        console.error('Error fetching payroll managers:', error);
        this.payrollManagers = [];
      }
    );
  }

  demotePayrollManager(empId: number) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to demote this payroll manager?',
      header: 'Confirm Demotion',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.employeeService.demotePayrollManager(empId).subscribe(
          () => {
            console.log(`Payroll manager with ID ${empId} demoted successfully.`);
            this.getPayrollManagers(); // Refresh the list
          },
          (error) => {
            console.error(`Error demoting payroll manager with ID ${empId}:`, error);
          }
        );
      },
      reject: () => {
        // User rejected, do nothing or show a message
      },
    });
  }
}
