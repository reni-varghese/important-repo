import { Component } from '@angular/core';
import { Employee, EmployeeService } from '../../../../core/models/employee.service';
import { forkJoin } from 'rxjs';

interface EnhancedEmployee extends Employee {
  payrollManagerName?: string; // Add payrollManagerName to the interface
}

@Component({
  selector: 'app-role-overview',
  standalone: false,
  templateUrl: './role-overview.component.html',
  styleUrl: './role-overview.component.css'
})
export class RoleOverviewComponent {
  employeeData: EnhancedEmployee[] = [];

  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void {
    this.getEmployees();
  }

  getEmployees(): void {
    this.employeeService.getAllEmployees().subscribe(
      (employees) => {
        this.employeeData = employees;
        this.fetchPayrollManagerNames();
      },
      (error) => {
        console.error('Error fetching employees:', error);
      }
    );
  }

  fetchPayrollManagerNames(): void {
    const managerFetchObservables = this.employeeData.map((employee) => {
      if (employee.empPayrollManager) {
        return this.employeeService.getEmployeeById(employee.empPayrollManager);
      } else {
        return null;
      }
    });

    forkJoin(managerFetchObservables).subscribe(
      (managers) => {
        managers.forEach((manager, index) => {
          if (manager) {
            //this.employeeData[index].payrollManagerName = manager.empName;
          } else {
            this.employeeData[index].payrollManagerName = 'N/A';
          }
        });
      },
      (error) => {
        console.error('Error fetching payroll manager names:', error);
        this.employeeData.forEach((employee) => {
          employee.payrollManagerName = 'N/A';
        });
      }
    );
  }
  }


