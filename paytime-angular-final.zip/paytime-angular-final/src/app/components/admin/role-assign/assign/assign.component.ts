import { Component } from '@angular/core';
import { Employee, EmployeeService } from '../../../../core/models/employee.service';
import { ConfirmationService } from 'primeng/api';
import { catchError, forkJoin, of } from 'rxjs';

interface EnhancedEmployee extends Employee {
  payrollManagerName?: string;
}
interface PayrollManager {
  payrollManagerId: string;
  payrollManagerName: string;
}

@Component({
  selector: 'app-assign',
  standalone: false,
  templateUrl: './assign.component.html',
  styleUrl: './assign.component.css'
})
export class AssignComponent {
  employeeData: EnhancedEmployee[] = [];
  displayAssignModal = false;
  employeeToAssign: any;
  availablePayrollManagers: Employee[] = []; // Use Employee interface
  payrollManagerOptions: any[] = [];

  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void {
    this.getEmployees();
    this.getAvailablePayrollManagers();
  }

  getEmployees(): void {
    this.employeeService.getAllEmployees().subscribe(
      (employees) => {
        this.employeeData = employees;
        this.fetchPayrollManagerNames(); // Call payroll manager name fetch here
      },
      (error) => {
        console.error('Error fetching employees:', error);
      }
    );
  }

  fetchPayrollManagerNames(): void {
    this.employeeData.forEach(employee => {
      if (employee.empPayrollManager) {
        const payrollManager = this.employeeData.find(emp => emp.empId === employee.empPayrollManager);
        if (payrollManager) {
          employee.payrollManagerName = payrollManager.empName;
        } else {
          employee.payrollManagerName = ''; // Or handle the case where manager is not found in employeeData
        }
      } else {
        employee.payrollManagerName = ''; // Set to N/A if no payroll manager assigned
      }
    });
  }


  openAssignModal(employee: any) {
    this.employeeToAssign = employee;
    this.displayAssignModal = true;
    this.payrollManagerOptions = [
      { label: 'No Payroll Manager', value: null },
      ...this.availablePayrollManagers.map(manager => ({ label: manager.empName, value: manager.empId }))
    ];
  }

  assignPayrollManager(employee: any, payrollManagerId: number | null) { // Allow null for unassigning
    this.employeeService.assignPayrollManager(employee.empId, payrollManagerId).subscribe({
      next: () => {
        console.log(`Assigned ${payrollManagerId} to employee ${employee.empId}`);
        this.displayAssignModal = false;
        this.getEmployees(); // Refresh employee data to update the list
      },
      error: (error) => {
        console.error('Error assigning payroll manager:', error);
      },
    });
    this.employeeToAssign = null;
  }

  getAvailablePayrollManagers(): void {
    this.employeeService.getAllPayrollManagers().subscribe({
      next: (managers) => {
        this.availablePayrollManagers = managers;
        this.payrollManagerOptions = [
          { label: 'No Payroll Manager', value: null },
          ...this.availablePayrollManagers.map(manager => ({ label: manager.empName, value: manager.empId }))
        ];
      },
      error: (error) => {
        console.error('Error fetching payroll managers:', error);
      },
    });
  }
}