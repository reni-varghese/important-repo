import { Component } from '@angular/core';
import { Employee, EmployeeService } from '../../../../core/models/employee.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-promote',
  standalone: false,
  templateUrl: './promote.component.html',
  styleUrl: './promote.component.css'
})
export class PromoteComponent {
  eligibleEmployees: Employee[] = [];
  eligibleEmployeesUnfrozenCols = [
    { field: 'empName', header: 'Name' },
    { field: 'empEmail', header: 'Email' },
   
  ];

  constructor(
    private employeeService: EmployeeService,
    private confirmationService: ConfirmationService
  ) {}

  ngOnInit(): void {
    this.getEligibleEmployees();
  }

  getEligibleEmployees() {
    this.employeeService.getEligibleForPayrollPromotion().subscribe(
      (employees) => {
        this.eligibleEmployees = employees;
      },
      (error) => {
        console.error('Error fetching eligible employees:', error);
        this.eligibleEmployees = [];
      }
    );
  }

  promoteToPayrollManager(empId: number) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to promote this employee to payroll manager?',
      header: 'Confirm Promotion',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.employeeService.promoteToPayrollManager(empId).subscribe(
          () => {
            console.log(`Employee with ID ${empId} promoted successfully.`);
            this.getEligibleEmployees(); // Refresh the list
          },
          (error) => {
            console.error(`Error promoting employee with ID ${empId}:`, error);
          }
        );
      },
      reject: () => {
        // User rejected, do nothing or show a message
      },
    });
  }
}
