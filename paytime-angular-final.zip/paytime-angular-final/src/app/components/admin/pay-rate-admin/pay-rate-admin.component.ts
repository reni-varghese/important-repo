import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ConfirmationService, MessageService } from 'primeng/api';
import { PayrateService } from '../../../services/employee/payrates.service';
import { PayRate } from '../../../core/models/dpayrates';

@Component({
  selector: 'app-pay-rate-admin',
  templateUrl: './pay-rate-admin.component.html',
  standalone: false,
  styleUrls: ['./pay-rate-admin.component.css'],
  providers: [MessageService, ConfirmationService]
})
export class PayRateAdminComponent implements OnInit {
  payRatesForm!: FormGroup; 
  newRoleForm!: FormGroup;
  showModal: boolean = false;
  roles: string[] = [];
  isEditMode: boolean = false;

constructor(private fb: FormBuilder, private payRateService: PayrateService, private messageService: MessageService, private confirmationService: ConfirmationService) {}

  ngOnInit(): void {
    this.payRatesForm = this.fb.group({
      pay_rateid: [{ value: '', disabled: true }, Validators.required],
      role: ['', Validators.required],
      basicPay: [{ value: '', disabled: true }, [Validators.required, Validators.min(0)]],
      overtimePay: [{ value: '', disabled: true }, [Validators.required, Validators.min(0)]],
      pf: [{ value: '', disabled: true }, [Validators.required, Validators.min(0)]],
      hra: [{ value: '', disabled: true }, [Validators.required, Validators.min(0)]],
      // lta: [{ value: '', disabled: true }, [Validators.required, Validators.min(0)]],
      mobileReimbursement: [{ value: '', disabled: true }, [Validators.required, Validators.min(0)]],
      foodReimbursement: [{ value: '', disabled: true }, [Validators.required, Validators.min(0)]],
      specialAllowance: [{ value: '', disabled: true }, [Validators.required, Validators.min(0)]],
      cashAllowance: [{ value: '', disabled: true }, [Validators.required, Validators.min(0)]]
    });

    this.newRoleForm = this.fb.group({
      pay_rateid: [0, [Validators.required, Validators.min(0)]],
      empRole: ['', Validators.required],
      basicPay: [0, [Validators.required, Validators.min(0)]],
      overtimePay: [0, [Validators.required, Validators.min(0)]],
      pf: [0, [Validators.required, Validators.min(0)]],
      hra: [0, [Validators.required, Validators.min(0)]],
      // lta: [0, [Validators.required, Validators.min(0)]],
      mobileReimbursement: [0, [Validators.required, Validators.min(0)]],
      foodReimbursement: [0, [Validators.required, Validators.min(0)]],
      specialAllowance: [0, [Validators.required, Validators.min(0)]],
      cashAllowance: [0, [Validators.required, Validators.min(0)]]
    });

    this.payRatesForm.get('role')!.valueChanges.subscribe(role => {
      this.fetchRoleData(role);
    });

    this.loadPayRates();
  }

  loadPayRates() {
    this.payRateService.getPayRates().subscribe(data => {
      console.log(data);
      this.roles = data.map(role => role.empRole);
    });
  }

  onSubmit() {
    console.log("Entering update");
    console.log(this.payRatesForm.controls);
    console.log("Form Validity:", this.payRatesForm.valid);
    if (this.payRatesForm.valid) {
      const role = this.payRatesForm.value.role;
      const payRate: PayRate = {
        pay_rateid: this.payRatesForm.get('pay_rateid')!.value,
        empRole: role,
        basicPay: this.payRatesForm.get('basicPay')!.value,
        overtimePay: this.payRatesForm.get('overtimePay')!.value,
        pf: this.payRatesForm.get('pf')!.value,
        hra: this.payRatesForm.get('hra')!.value,
        // lta: this.payRatesForm.get('lta')!.value,
        mobileReimbursement: this.payRatesForm.get('mobileReimbursement')!.value,
        foodReimbursement: this.payRatesForm.get('foodReimbursement')!.value,
        specialAllowance: this.payRatesForm.get('specialAllowance')!.value,
        cashAllowance: this.payRatesForm.get('cashAllowance')!.value
      };
      console.log("Payload being sent to backend:", payRate);
      this.payRateService.updatePayRate(payRate).subscribe(response => {
        console.log('Pay rate updated:', response);
        this.isEditMode = false;
        this.lockFormFields();
      }, error => {
        console.error('Error updating pay rate:', error);
      });
    } else {
      console.log("Form is invalid");
    }
  }

  onEdit(): void {
    this.isEditMode = true;
    Object.keys(this.payRatesForm.controls).forEach(control => {
      if (control !== 'role') {
        this.payRatesForm.get(control)!.enable();
      }
    });
  }

  onAddRole() {
    this.newRoleForm.reset({
      pay_rateid: 0,
      empRole: '',
      basicPay: 0,
      overtimePay: 0,
      pf: 0,
      hra: 0,
      mobileReimbursement: 0,
      foodReimbursement: 0,
      specialAllowance: 0,
      cashAllowance: 0
    });
    this.showModal = true;
  }

  closeModal() {
    this.showModal = false;
  }

  onSubmitNewRole() {
    if (this.newRoleForm.valid) {
      this.confirmationService.confirm({
        message: 'Are you sure you want to add this role?',
        header: 'Confirmation',
        icon: 'pi pi-exclamation-triangle',
        accept: () => {
          this.confirmAddRole();
        }
      });
    }  
  }

  confirmAddRole() {
    if (this.newRoleForm.valid) {
      const newPayRate: PayRate = {
        pay_rateid: this.newRoleForm.value.pay_rateid, 
        empRole: this.newRoleForm.value.empRole,
        basicPay: this.newRoleForm.value.basicPay,
        overtimePay: this.newRoleForm.value.overtimePay,
        pf: this.newRoleForm.value.pf,
        hra: this.newRoleForm.value.hra,
        mobileReimbursement: this.newRoleForm.value.mobileReimbursement,
        foodReimbursement: this.newRoleForm.value.foodReimbursement,
        specialAllowance: this.newRoleForm.value.specialAllowance,
        cashAllowance: this.newRoleForm.value.cashAllowance
      };
      this.messageService.add({severity:'success', summary:'Success', detail:'New Role Added Successfully'});
      this.payRateService.addPayRate(newPayRate).subscribe(response => {
        this.roles.push(newPayRate.empRole);

        setTimeout(()=>{
          this.closeModal();
        },2000);

      }, error => {
        console.error('Error adding new role:', error);
      });
    }
  }

  fetchRoleData(role: string): void {
    this.payRateService.getPayRates().subscribe(data => {
      const selectedRole = data.find(r => r.empRole === role);
      if (selectedRole) {
        this.payRatesForm.patchValue({
          pay_rateid: selectedRole.pay_rateid,
          basicPay: selectedRole.basicPay,
          overtimePay: selectedRole.overtimePay,
          pf: selectedRole.pf,
          hra: selectedRole.hra,
          // lta: selectedRole.lta,
          mobileReimbursement: selectedRole.mobileReimbursement,
          foodReimbursement: selectedRole.foodReimbursement,
          specialAllowance: selectedRole.specialAllowance,
          cashAllowance: selectedRole.cashAllowance
        });
        this.lockFormFields();
      }
    }, error => {
      console.error('Error fetching role data:', error);
    });
  }

  lockFormFields(): void {
    Object.keys(this.payRatesForm.controls).forEach(control => {
      if (control !== 'role') {
        this.payRatesForm.get(control)!.disable();
      }
    });
  }
}
 