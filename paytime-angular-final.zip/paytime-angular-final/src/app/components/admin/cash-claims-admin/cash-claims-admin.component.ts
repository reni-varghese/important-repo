import { Component,OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {CashclaimsServiceService} from '../../../services/cashclaims-service.service';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-cash-claims-admin',
  standalone: false,
  templateUrl: './cash-claims-admin.component.html',
  styleUrl: './cash-claims-admin.component.css'
})
export class CashClaimsAdminComponent{
  empId: string;
  fromDate: string;
  toDate: string;
  claims: any[] = [];
  p: number = 1; // Current page number

  constructor(private claimsService: CashclaimsServiceService, private messageService: MessageService) {}

  unfrozenCols = [
    { field: 'empName', header: 'Name' },
    { field: 'empId', header: 'Approver ID' },
    { field: 'dateOfClaim', header: 'Date' },
    { field: 'amount', header: 'Amount' },
    { field: 'description', header: 'Description' },
    { field: 'remark', header: 'Remark' }
  ];

  validate(): boolean {
    if (!this.empId || !this.fromDate || !this.toDate) {
      return false;
    }
    if (new Date(this.fromDate) >= new Date(this.toDate)) {
      return false;
    }
    return true;
  }

  viewClaims() {
    if (new Date(this.fromDate) > new Date(this.toDate)) {
      this.messageService.add({ severity: 'error', summary: 'Error', detail: 'From Date must be less than To Date' });
      return;
    }
    if (!this.validate()) {
      console.error('Validation failed');
      return;
    }

    this.claimsService.getClaims(this.empId, this.fromDate, this.toDate).subscribe(
      data => {
        this.claims = data;
        if (data.length === 0) {
          this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Sorry, no data to display for this employee ID' });
        }
      },
      error => {
        if (error.status === 404) {
          this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No data found for the given employee ID and date range' });
        } else {
          console.error('Error fetching data:', error);
          this.messageService.add({ severity: 'error', summary: 'Error', detail: 'An error occurred while fetching data' });
        }
      }
    );
  }

  onPageChange(page: number) {
    this.p = page;
  }
}
