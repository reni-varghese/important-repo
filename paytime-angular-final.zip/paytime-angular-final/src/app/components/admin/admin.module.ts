import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from "../../shared/shared.module";
import { AdminComponent } from './admin/admin.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { RoleAssignComponent } from './role-assign/role-assign.component';
import { TimesheetAdminComponent } from './timesheet-admin/timesheet-admin.component';
import { CashClaimsAdminComponent } from './cash-claims-admin/cash-claims-admin.component';
import { PayRateAdminComponent } from './pay-rate-admin/pay-rate-admin.component';
import { HTTP_INTERCEPTORS, provideHttpClient } from '@angular/common/http';
import { FloatLabelModule } from "primeng/floatlabel";
import { InputTextModule } from 'primeng/inputtext';
import { InputNumberModule } from 'primeng/inputnumber';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { InputMaskModule } from 'primeng/inputmask';
import { IftaLabelModule } from 'primeng/iftalabel';
import { SelectModule } from 'primeng/select';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { FieldsetModule } from 'primeng/fieldset';
import { CardModule } from 'primeng/card';
import { DatePickerModule } from 'primeng/datepicker';
import { StepperModule } from 'primeng/stepper';
import { InputIcon, InputIconModule } from 'primeng/inputicon';
import { IconField } from 'primeng/iconfield';
import { JwtInterceptor } from '../../core/interceptor/jwt.service';
import { CreateEmployeeModule } from './create-employee/create-employee.module';
import { ChartModule } from 'primeng/chart';
import { ToastModule } from 'primeng/toast';
import {  ConfirmDialogModule } from 'primeng/confirmdialog';





const adminRoutes: Routes = [
    { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
    { path: 'dashboard', component: AdminDashboardComponent },
    { path: 'create-employee', loadChildren: () => import('./create-employee/create-employee.module').then(m => m.CreateEmployeeModule) },
    { path: 'cash-claims', component: CashClaimsAdminComponent },
    { path: 'payrate', component: PayRateAdminComponent },
    { path: 'role-assign', loadChildren: () => import('./role-assign/role-assign.module').then(m => m.RoleAssignModule) },
    { path: 'timesheet', component: TimesheetAdminComponent },
];

@NgModule({
    declarations: [
        AdminDashboardComponent,
        RoleAssignComponent,
        TimesheetAdminComponent,
        CashClaimsAdminComponent,
        PayRateAdminComponent,
        AdminComponent,

    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule.forChild(adminRoutes), // Add forChild with adminRoutes
        SharedModule,
        ButtonModule,
        TableModule,
        FloatLabelModule,
        SelectModule,
        InputTextModule,
        InputNumberModule,
        StepperModule,
        CalendarModule,
        DropdownModule,
        InputMaskModule,
        IconField,
        InputIcon,
        DatePickerModule,
        ButtonModule,
        FieldsetModule,
        CardModule,
        IftaLabelModule,
        FormsModule, 
        InputTextModule, 
        InputIconModule,
        ChartModule,
        ToastModule,
        ConfirmDialogModule
        
        
    ],
    providers: [provideHttpClient()]
})
export class AdminModule { }