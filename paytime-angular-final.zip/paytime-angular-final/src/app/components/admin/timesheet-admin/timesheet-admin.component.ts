import { Component, OnInit } from '@angular/core';
import { TimesheetService } from '../../../services/timesheet-service.service';
import { Dtimesheet } from '../../../core/models/dtimesheet';
import { MessageService } from 'primeng/api';
import { TimesheetDto } from '../../../core/models/timesheet.dto';

@Component({
  selector: 'app-timesheet-admin',
  templateUrl: './timesheet-admin.component.html',
  styleUrls: ['./timesheet-admin.component.css'],
  standalone: false
})
export class TimesheetAdminComponent implements OnInit {

  empId: string;
  fromDate: string;
  toDate: string;
  timesheetData: Dtimesheet[] = [];

  unfrozenCols = [
    { field: 'date', header: 'Date' },
    { field: 'clockIn', header: 'Clock In' },
    { field: 'clockOut', header: 'Clock Out' },
    { field: 'topUpHours', header: 'Over Time' }
  ];

  constructor(private timesheetService: TimesheetService, private messageService: MessageService) { }

  ngOnInit(): void { }

  validate(): boolean {
    if (!this.empId || !this.fromDate || !this.toDate) {
      return false;
    }
    return new Date(this.fromDate) < new Date(this.toDate);
  }

  viewTimesheet(): void {
    if (new Date(this.fromDate) > new Date(this.toDate)) {
      this.messageService.add({ severity: 'error', summary: 'Error', detail: 'From Date must be less than To Date' });
      return;
    }
    if (!this.validate()) {
      console.log('Invalid input');
      return;
    }
    // const fromDate = new Date(this.fromDate);
    // const toDate = new Date(this.toDate);
    this.timesheetService.getTimesheetData1(this.empId, this.fromDate, this.toDate).subscribe(data => {
      console.log(data);
      this.timesheetData = data;
      if (data.length == 0) {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Sorry, no data to display for this employee ID' });
        return;
      }
    }, error => {
      if (error.status === 404) {
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'No data found for the given employee ID and date range' });
      } else {
        console.error('Error fetching data:', error);
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'An error occurred while fetching data' });
      }
    });
  }
}