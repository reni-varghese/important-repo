import { Component } from '@angular/core';
import { Employee, EmployeeService } from '../../../../core/models/employee.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-remove-employee',
  standalone: false,
  templateUrl: './remove-employee.component.html',
  styleUrl: './remove-employee.component.css'
})
export class RemoveEmployeeComponent {
  employeeData: Employee[] = [];
  unfrozenCols = [
    { field: 'empName', header: 'Name' },
    { field: 'empEmail', header: 'Email' },
    { field: 'empGender', header: 'Gender' },
    { field: 'empNationalId', header: 'National ID' },
    { field: 'empRole', header: 'Role' },
    { field: 'empPhoneNo', header: 'Phone' },
  ];

  constructor(
    private employeeService: EmployeeService,
    private confirmationService: ConfirmationService // Inject ConfirmationService
  ) {}

  ngOnInit(): void {
    this.getActiveEmployees();
  }

  getActiveEmployees() {
    this.employeeService.getActiveEmployees().subscribe(
      (employees) => {
        this.employeeData = employees;
      },
      (error) => {
        console.error('Error fetching employee details:', error);
        this.employeeData = [];
      }
    );
  }

  removeEmployee(empId: number) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to remove this employee?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.employeeService.removeEmployee(empId).subscribe(
          () => {
            console.log(`Employee with ID ${empId} removed successfully.`);
            this.getActiveEmployees();
          },
          (error) => {
            console.error(`Error removing employee with ID ${empId}:`, error);
          }
        );
      },
      reject: () => {
        // User rejected, do nothing or show a message
      },
    });
  }
}
