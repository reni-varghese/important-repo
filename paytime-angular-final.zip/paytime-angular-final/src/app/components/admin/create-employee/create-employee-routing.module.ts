import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AllEmployeesComponent } from './all-employee/all-employee.component';
import { RemoveEmployeeComponent } from './remove-employee/remove-employee.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { RestoreEmployeeComponent } from './restore-employee/restore-employee.component';


const routes: Routes = [
    { path: '', redirectTo: 'add-employee', pathMatch: 'full' },
    { path: 'add-employee', component: AddEmployeeComponent },
    { path: 'remove-employee', component: RemoveEmployeeComponent},
    { path: 'restore-employee', component: RestoreEmployeeComponent},
    { path: 'all-employee', component: AllEmployeesComponent }, // Add the new route
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class CreateEmployeeRoutingModule { }