import { Component, OnInit } from '@angular/core';
import { Employee, EmployeeService } from '../../../../core/models/employee.service';


@Component({
  selector: 'app-all-employees',
  templateUrl: './all-employee.component.html',
  styleUrls: ['./all-employee.component.css'],
  standalone: false
})
export class AllEmployeesComponent implements OnInit {
  employeeData: Employee[] = [];
  unfrozenCols = [
    { field: 'empName', header: 'Name' },
    { field: 'empEmail', header: 'Email' },
    { field: 'empDob', header: 'DOB' },
    { field: 'empBloodGroup', header: 'Blood Group' },
    { field: 'empGender', header: 'Gender' },
    { field: 'empMaritalStatus', header: 'Marital Status' },
    { field: 'empNationalId', header: 'National ID' },
    { field: 'empPhoneNo', header: 'Phone' },
    { field: 'empRole', header: 'Role' },
    { field: 'empActive', header: 'Active' },
    { field: 'empIsPayroll', header: 'Is Payroll' },
    { field: 'empPayrollManager', header: 'Payroll Manager' },
    { field: 'bankName', header: 'Bank' },
    { field: 'accountHolderName', header: 'Account Holder' },
    { field: 'accountNumber', header: 'Account Number' },
    { field: 'ifscCode', header: 'IFSC' },
    { field: 'branch', header: 'Branch' },
  ];

  constructor(private employeeService: EmployeeService) {}

  ngOnInit(): void {
    this.getAllEmployees();
  }

  getAllEmployees() {
    this.employeeService.getAllEmployees().subscribe(
      (employees) => {

        this.employeeData = employees;
        console.log(this.employeeData);
      },
      (error) => {
        console.error('Error fetching employee details:', error);
        this.employeeData = [];
      }
    );
  }
}