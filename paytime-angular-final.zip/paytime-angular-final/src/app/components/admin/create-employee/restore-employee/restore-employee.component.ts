import { ChangeDetectorRef, Component } from '@angular/core';
import { Employee, EmployeeService } from '../../../../core/models/employee.service';
import { ConfirmationService } from 'primeng/api';

@Component({
  selector: 'app-restore-employee',
  standalone: false,
  templateUrl: './restore-employee.component.html',
  styleUrl: './restore-employee.component.css'
})
export class RestoreEmployeeComponent {
  employeeData: Employee[] = [];
  unfrozenCols = [
    { field: 'empName', header: 'Name' },
    { field: 'empEmail', header: 'Email' },
    { field: 'empGender', header: 'Gender' },
    { field: 'empNationalId', header: 'National ID' },
    { field: 'empRole', header: 'Role' },
    { field: 'empPhoneNo', header: 'Phone' },
  ];

  constructor(
    private employeeService: EmployeeService,
    private cdr: ChangeDetectorRef,
    private confirmationService: ConfirmationService// Inject ConfirmationService
  ) {}

  ngOnInit(): void {
    this.getInactiveEmployees();
  }

  getInactiveEmployees() {
    this.employeeService.getInactiveEmployees().subscribe(
      (employees) => {
        this.employeeData = employees;
      },
      (error) => {
        console.error('Error fetching employee details:', error);
        this.employeeData = [];
      }
    );
  }

  restoreEmployee(empId: number) {
    this.confirmationService.confirm({
      message: 'Are you sure you want to restore this employee?',
      header: 'Confirm',
      icon: 'pi pi-exclamation-triangle',
      accept: () => {
        this.employeeService.markEmployeeActive(empId).subscribe(
          () => {
            console.log(`Employee with ID ${empId} restored successfully.`);
            this.getInactiveEmployees();
            this.cdr.detectChanges();
          },
          (error) => {
            console.error(`Error restoring employee with ID ${empId}:`, error);
          }
        );
      },
      reject: () => {
        // User rejected, do nothing or show a message
      },
    });
  }
}
