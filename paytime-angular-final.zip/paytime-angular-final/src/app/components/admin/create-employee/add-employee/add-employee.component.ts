import { animate, style, transition, trigger } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { EmployeeService } from '../../../../core/models/employee.service';

interface EmployeeFormControls {
  empId: number;
  empName: FormControl;
  empEmail: FormControl;
  empDob: FormControl;
  empBloodGroup: FormControl;
  empGender: FormControl;
  empMaritalStatus: FormControl;
  empNationalId: FormControl;
  empPhoneNo: FormControl;
  empRole: FormControl;
  bankName: FormControl;
  accountHolderName: FormControl;
  accountNumber: FormControl;
  ifscCode: FormControl;
  branch: FormControl;
}

@Component({
  selector: 'app-add-employee',
  standalone: false,
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css'],
  animations: [
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('500ms ease-in', style({ opacity: 1 }))
      ])
    ])
  ]
})
export class AddEmployeeComponent implements OnInit {
  
  employeeForm: FormGroup;
  showSuccessDialog: boolean = false;
  successMessage: string = '';
  loading: boolean = false;
  isBasicDetailsCollapsed: boolean = false; // Basic details fieldset starts open
  isBankDetailsCollapsed: boolean = true;  // Bank details fieldset starts collapsed
  showErrorDialog: boolean = false;
  errorMessage: string = '';


  // Options for dropdowns
  bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  genders = ['Male', 'Female', 'Other'];
  maritalStatuses = ['Single', 'Married', 'Divorced', 'Widowed'];
  roles = [
    { label: 'Select Role', value: null },
    { label: 'Programmer Analyst Trainee', value: 'Programmer Analyst Trainee' },
    { label: 'Sr. Developer', value: 'Sr. Developer' }
  ];

  constructor(private fb: FormBuilder, private employeeService: EmployeeService) { }

  ngOnInit(): void {
    this.employeeForm = this.fb.group({
      // Basic Details
      empName: ['', [Validators.required, Validators.pattern(/^[A-Za-z\s]+$/)]],
      empEmail: ['', [Validators.required, Validators.email]],
      empDob: ['', [Validators.required, this.ageValidator(18, 60)]],
      empBloodGroup: [null, Validators.required],
      empGender: [null, Validators.required],
      empMaritalStatus: [null, Validators.required],
      empNationalId: ['', [Validators.required, Validators.pattern(/^\d{12}$/)]],
      empPhoneNo: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      empRole: [null, Validators.required],
      // Bank Details
      bankName: ['', Validators.required],
      accountHolderName: ['', Validators.required],
      accountNumber: ['', [Validators.required, Validators.pattern(/^\d+$/)]],
      ifscCode: ['', Validators.required],
      branch: ['', Validators.required]
    });
  }

  // Custom validator to ensure age is between min and max
  ageValidator(min: number, max: number) {
    return (control: AbstractControl) => {
      const dob = new Date(control.value);
      if (isNaN(dob.getTime())) {
        return { invalidDate: true };
      }
      const today = new Date();
      let age = today.getFullYear() - dob.getFullYear();
      const m = today.getMonth() - dob.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
        age--;
      }
      return age < min || age > max ? { ageOutOfRange: true } : null;
    };
  }

  // Strongly typed getter for easy access to form controls
  get f(): EmployeeFormControls {
    return this.employeeForm.controls as unknown as EmployeeFormControls;
  }

  // Returns an array of validation messages for a given control.
  getValidationMessages(controlName: string): string[] {
    const control = this.employeeForm.get(controlName);
    const messages: string[] = [];
    if (control && control.errors) {
      if (control.errors['required']) {
        messages.push('This field is required.');
      }
      if (control.errors['pattern']) {
        if (controlName === 'empName') {
          messages.push('Only alphabets and spaces are allowed.');
        }
        if (controlName === 'empNationalId') {
          messages.push('Aadhar ID must be 12 digits.');
        }
        if (controlName === 'empPhoneNo') {
          messages.push('Phone number must be 10 digits.');
        }
        if (controlName === 'accountNumber') {
          messages.push('Account number must be numeric.');
        }
      }
      if (control.errors['email']) {
        messages.push('Please enter a valid email address.');
      }
      if (control.errors['ageOutOfRange']) {
        messages.push('Age must be between 18 and 60 years.');
      }
      if (control.errors['invalidDate']) {
        messages.push('Invalid date.');
      }
    }
    return messages;
  }

  onSubmit() {
    if (this.employeeForm.invalid) {
      this.employeeForm.markAllAsTouched();
      return;
    }
    this.loading = true;
    console.log("form submitted");

    // Format the empDob date
    const formattedDob = new Date(this.employeeForm.value.empDob).toISOString().split('T')[0];

    const formData = {
      empId: 0,
      empName: this.employeeForm.value.empName,
      empEmail: this.employeeForm.value.empEmail,
      empDob: formattedDob, // Use the formatted date
      empBloodGroup: this.employeeForm.value.empBloodGroup,
      empGender: this.employeeForm.value.empGender,
      empMaritalStatus: this.employeeForm.value.empMaritalStatus,
      empNationalId: this.employeeForm.value.empNationalId,
      empPhoneNo: this.employeeForm.value.empPhoneNo,
      empRole: this.employeeForm.value.empRole,
      empActive: true,
      empIsPayroll: false,
      empPayrollManager: null,
      bankName: this.employeeForm.value.bankName,
      accountHolderName: this.employeeForm.value.accountHolderName,
      accountNumber: this.employeeForm.value.accountNumber,
      ifscCode: this.employeeForm.value.ifscCode,
      branch: this.employeeForm.value.branch
    };

    console.log("Data to be sent:", formData);

    
    this.employeeService.createEmployee(formData).subscribe({
      next: (res) => {
        this.successMessage = 'Employee added successfully!';
        this.showSuccessDialog = true;
        this.employeeForm.reset();
      },
      error: (err) => {
        console.error('Error while adding employee:', err);
        this.errorMessage = 'Error while adding employee. Please check the details.';
        this.showErrorDialog = true;
      },
      complete: () => {
        this.loading = false;
      }
    });
  }

  
  onDialogHide() {
    this.showSuccessDialog = false;
    this.showErrorDialog = false;
    this.employeeForm.reset();
  }
  onBasicDetailsToggle() {
    this.isBasicDetailsCollapsed = !this.isBasicDetailsCollapsed;
    if(!this.isBasicDetailsCollapsed){
      this.isBankDetailsCollapsed = true;
    }

  }

  onBankDetailsToggle() {
    this.isBankDetailsCollapsed = !this.isBankDetailsCollapsed;
     if(!this.isBankDetailsCollapsed){
      this.isBasicDetailsCollapsed = true;
    }
  }
  onErrorDialogHide() {
    this.showErrorDialog = false;
    
  }
}