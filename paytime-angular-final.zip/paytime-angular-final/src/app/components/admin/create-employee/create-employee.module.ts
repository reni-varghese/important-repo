import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FloatLabelModule } from "primeng/floatlabel"
import { InputTextModule } from 'primeng/inputtext';
import { InputNumberModule } from 'primeng/inputnumber';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { InputMaskModule } from 'primeng/inputmask';
import { IftaLabelModule } from 'primeng/iftalabel';
import { FileUploadModule } from 'primeng/fileupload';
import { Select, SelectModule } from 'primeng/select';
import { ButtonModule } from 'primeng/button';

import { TableModule } from 'primeng/table';;
import { FieldsetModule } from 'primeng/fieldset';
import { CardModule } from 'primeng/card';
import { DatePickerModule } from 'primeng/datepicker';
import { StepperModule } from 'primeng/stepper';
import { InputIcon, InputIconModule } from 'primeng/inputicon';
import { IconField } from 'primeng/iconfield';


import { CreateEmployeeRoutingModule } from './create-employee-routing.module';
import { CreateEmployeeComponent } from './create-employee.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, } from '@angular/router';
import { SharedModule } from '../../../shared/shared.module';
import {  AllEmployeesComponent } from './all-employee/all-employee.component';
import { RemoveEmployeeComponent } from './remove-employee/remove-employee.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { EmployeeService } from '../../../core/models/employee.service';
import { JwtInterceptor } from '../../../core/interceptor/jwt.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { RestoreEmployeeComponent } from './restore-employee/restore-employee.component';
import { ConfirmDialogModule } from 'primeng/confirmdialog'; // Import ConfirmDialogModule
import { ConfirmationService } from 'primeng/api'; // Import ConfirmationService
import { DialogModule } from 'primeng/dialog';
import { TooltipModule } from 'primeng/tooltip';

@NgModule({
  declarations: [ 
    CreateEmployeeComponent,
  
    RemoveEmployeeComponent, 
    AddEmployeeComponent,
    AllEmployeesComponent,
    RestoreEmployeeComponent
  ],
  imports: [
    CommonModule,
    CreateEmployeeRoutingModule,
    ReactiveFormsModule,
     FormsModule,
     ConfirmDialogModule,
     SharedModule,
     ButtonModule,
     TableModule,
    FloatLabelModule,
    SelectModule,
    InputTextModule,
    InputNumberModule,
    StepperModule,
    CalendarModule,
    DropdownModule,
    InputMaskModule,
  IconField,
  InputIcon,
   DatePickerModule,
    ButtonModule,
    FieldsetModule,
    CardModule,
    IftaLabelModule,
    FormsModule, // Add FormsModule
    TableModule, // Add TableModule
    InputTextModule, // Add InputTextModule
    InputIconModule,// Add SortIconModule
    DialogModule,
    TooltipModule
  ],
  providers: [
    EmployeeService, 
    ConfirmationService
   
    
  ]
})
export class CreateEmployeeModule { }
