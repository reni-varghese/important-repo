import { Component } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { EmployeeService } from '../../../services/employee.service';
import { NetsalarysumService } from '../../../services/netsalarysum.service';
import { PayrollchartService } from '../../../services/payrollchart.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Component({
  selector: 'app-admin-dashboard',
  standalone: false,
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent{
  // years: any[] = [
  //   { name: '2023', code: '2023' },
  //   { name: '2024', code: '2024' }
  // ];
  // selectedYear: any = { name: '2024', code: '2024' }; // Default to 2024

  // totalEmployeesAssigned: number = 0;
  // totalEmployees: number;
  // totalPayrollThisMonth: number = 0; // Initialize to 0
  // isHovered1: boolean = false;
  // isHovered2: boolean = false;

  // basicData: any;
  // basicOptions: any;
  // netSalarySum: number = 0; // Initialize netSalarySum
  // totalSalary:number =0;

  // constructor(private employeeService: EmployeeService, private netsalarysumService: NetsalarysumService, private payrollChartService: PayrollchartService,private http:HttpClient) {}

  // ngOnInit(): void {
  //   const payrollId = sessionStorage.getItem("empId");

  //   if (payrollId !== null) {

  //     this.fetchTotalEmployees();
  //     const parsedPayrollId = parseInt(payrollId, 10);
  //     // this.fetchTotalEmployeesAssigned(parsedPayrollId);
  //     this.fetchNetSalarySum(parsedPayrollId);
  //     this.fetchMonthlyPayrollSum(parsedPayrollId, this.selectedYear.code);
  //     this.fetchTotalSalary(); // Fetch data for the default year
  //   }

  //   this.basicOptions = {
  //     responsive: true,
  //     maintainAspectRatio: false
  //   };
  // }
  // fetchTotalEmployees() {
  //   const token = sessionStorage.getItem('token');
  //   const headers = new HttpHeaders({
  //     Authorization: `Bearer ${token}`,
  //   });
  //   this.http.get<any[]>('http://localhost:8081/api/employees',{ headers }).subscribe(
  //     data => {
  //       console.log(data.length);
  //       this.totalEmployees = data.length;
  //     },
  //     error => {
  //       console.error('Error fetching total employees:', error);
  //     }
  //   );
  // }
  // // fetch total salaries
  // fetchTotalSalary(){
  //     this.employeeService.getAllEmployeesSalary().subscribe(
  //       (data)=>{
  //         data.forEach((item)=>this.totalSalary= this.totalSalary + item.netpay);
  //         console.log(this.totalSalary);

  //       },
  //       (error)=>{
  //         console.log("Some error is coming fetching salary");
  //       }
  //     );
  // }

  // fetchTotalEmployeesAssigned(payrollManagerId: number): void {
  //   this.employeeService.getTotalEmployeesAssigned(payrollManagerId).subscribe(
  //     (response: { count: number }) => {
  //       this.totalEmployeesAssigned = response.count;
  //       console.log(response.count);
  //       console.log(payrollManagerId);
  //       console.log(this.totalEmployeesAssigned);
  //     },
  //     (error) => {
  //       console.error('Error fetching total employees assigned:', error);
  //     }
  //   );
  // }

  // fetchNetSalarySum(payrollManagerId: number): void {
  //   this.netsalarysumService.getNetSalarySumForManager(payrollManagerId).subscribe(
  //     (response: NetSalarySumDTO) => {
  //       this.totalPayrollThisMonth = response.netSalarySum; // Update totalPayrollThisMonth with fetched data
  //       console.log("Net Salary Sum: ", this.totalPayrollThisMonth);
  //     },
  //     (error: HttpErrorResponse) => {
  //       console.error('Error fetching net salary sum:', error.message);
  //     }
  //   );
  // }

  // fetchMonthlyPayrollSum(managerId: number, year: string): void {
  //   this.payrollChartService.getMonthlyPayrollSum(managerId, year).subscribe(
  //     (data: Map<number, Map<string, number>>) => {
  //       console.log("Data received from API:", data);
  //       const yearData = data.get(parseInt(year, 10));
  //       console.log("Year data:", yearData);
  //       if (yearData) {
  //         this.updateChartData(yearData);
  //       } else {
  //         console.error("No data found for the selected year.");
  //       }
  //     },
  //     (error: any) => {
  //       console.error('Error fetching monthly payroll sum:', error);
  //     }
  //   );
  // }

  // updateChartData(data: Map<string, number>): void {
  //   console.log("Updating chart data with:", data);
  //   const labels: string[] = [];
  //   const values: number[] = [];
  //   const backgroundColors: string[] = [];
  //   const borderColors: string[] = [];

  //   const colors = [
  //     'rgba(0, 0, 0, 1)',   // Black
  //     'rgba(128, 128, 128, 0.5)' // Grey
  //   ];

  //   const borderColorsArray = [
  //     'rgba(0, 0, 0, 1)',   // Black
  //     'rgba(128, 128, 128, 1)' // Grey
  //   ];

  //   const monthOrder = [
  //     'january', 'february', 'march', 'april', 'may', 'june',
  //     'july', 'august', 'september', 'october', 'november', 'december'
  //   ];

  //   const sortedData: { label: string, value: number, color: string, borderColor: string }[] = [];

  //   data.forEach((value, month) => {
  //     sortedData.push({
  //       label: month,
  //       value: value,
  //       color: colors[monthOrder.indexOf(month.toLocaleLowerCase()) % colors.length],
  //       borderColor: borderColorsArray[monthOrder.indexOf(month.toLocaleLowerCase()) % borderColorsArray.length]
  //     });
  //   });

  //   sortedData.sort((a, b) => {
  //     return monthOrder.indexOf(a.label.toLowerCase()) - monthOrder.indexOf(b.label.toLowerCase());
  //   });

  //   sortedData.forEach(item => {
  //     labels.push(item.label);
  //     values.push(item.value);
  //     backgroundColors.push(item.color);
  //     borderColors.push(item.borderColor);
  //   });

  //   this.basicData = {
  //     labels: labels,
  //     datasets: [
  //       {
  //         label: 'Monthly Payroll Sum',
  //         backgroundColor: backgroundColors,
  //         borderColor: borderColors,
  //         borderWidth: 1,
  //         data: values
  //       }
  //     ]
  //   };
  // }

  // onYearChange(event: any): void {
  //   const payrollId = sessionStorage.getItem("empId");
  //   if (payrollId !== null) {
  //     const parsedPayrollId = parseInt(payrollId, 10);
  //     this.fetchMonthlyPayrollSum(parsedPayrollId, event.value.code);
  //   }
  // }
  years: any[] = [
    { name: '2023', code: '2023' },
    { name: '2024', code: '2024' }
  ];
  selectedYear: any = { name: '2024', code: '2024' }; // Default to 2024

  totalEmployeesAssigned: number = 0;
  totalEmployees: number;
  totalPayrollThisMonth: number = 0; // Initialize to 0
  isHovered1: boolean = false;
  isHovered2: boolean = false;

  basicData: any;
  basicOptions: any;
  netSalarySum: number = 0; // Initialize netSalarySum
  totalSalary: number = 0;

  constructor(
    private employeeService: EmployeeService,
    private netsalarysumService: NetsalarysumService,
    private payrollChartService: PayrollchartService,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.fetchTotalEmployees();
    this.fetchTotalSalary(); // Fetch data for the default year
    this.fetchMonthlyPayrollSum(this.selectedYear.code);

    this.basicOptions = {
      responsive: true,
      maintainAspectRatio: true
    };
  }

  fetchTotalEmployees() {
    const token = sessionStorage.getItem('token');
    const headers = new HttpHeaders({
      Authorization: `Bearer ${token}`
    });
    this.http.get<any[]>('http://localhost:8081/api/employees', { headers }).subscribe(
      data => {
        console.log(data.length);
        this.totalEmployees = data.length;
      },
      error => {
        console.error('Error fetching total employees:', error);
      }
    );
  }

  // fetch total salaries
  fetchTotalSalary() {
    this.employeeService.getAllEmployeesSalary().subscribe(
      data => {
        data.forEach(item => (this.totalSalary = this.totalSalary + item.netpay));
        console.log(this.totalSalary);
      },
      error => {
        console.log('Some error is coming fetching salary');
      }
    );
  }

  // fetchMonthlyPayrollSum(year: string): void {
  //   this.payrollChartService.getMonthlyPayrollSumForAllEmployees(year).subscribe(
  //     (data: Map<number, Map<string, number>>) => {
  //       console.log('Data received from API:', data);
  //       const yearData = data.get(parseInt(year, 10));
  //       console.log('Year data:', yearData);
  //       if (yearData) {
  //         this.updateChartData(yearData);
  //       } else {
  //         console.error('No data found for the selected year.');
  //       }
  //     },
  //     (error: any) => {
  //       console.error('Error fetching monthly payroll sum:', error);
  //     }
  //   );
  // }
  fetchMonthlyPayrollSum(year: string): void {
    this.payrollChartService.getMonthlyPayrollSumForAllEmployees(year).subscribe(
      (data: { [key: string]: number }) => {
        console.log('Data received from API:', data);
        if (data) {
          this.updateChartData(data);
        } else {
          console.error('No data found for the selected year.');
        }
      },
      (error: any) => {
        console.error('Error fetching monthly payroll sum:', error);
      }
    );
  }
  updateChartData(data: { [key: string]: number }): void {
    console.log('Updating chart data with:', data);
    const labels: string[] = [];
    const values: number[] = [];
    const backgroundColors: string[] = [];
    const borderColors: string[] = [];
  
    const colors = [
      'rgba(0, 0, 0, 1)', // Black
      'rgba(128, 128, 128, 0.5)' // Grey
    ];
  
    const borderColorsArray = [
      'rgba(0, 0, 0, 1)', // Black
      'rgba(128, 128, 128, 1)' // Grey
    ];
  
    const monthOrder = [
      'january', 'february', 'march', 'april', 'may', 'june',
      'july', 'august', 'september', 'october', 'november', 'december'
    ];
  
    const sortedData: { label: string; value: number; color: string; borderColor: string }[] = [];
  
    Object.entries(data).forEach(([month, value]) => {
      sortedData.push({
        label: month,
        value: value,
        color: colors[monthOrder.indexOf(month.toLocaleLowerCase()) % colors.length],
        borderColor: borderColorsArray[monthOrder.indexOf(month.toLocaleLowerCase()) % borderColorsArray.length]
      });
    });
  
    sortedData.sort((a, b) => {
      return monthOrder.indexOf(a.label.toLowerCase()) - monthOrder.indexOf(b.label.toLowerCase());
    });
  
    sortedData.forEach(item => {
      labels.push(item.label);
      values.push(item.value);
      backgroundColors.push(item.color);
      borderColors.push(item.borderColor);
    });
  
    this.basicData = {
      labels: labels,
      datasets: [
        {
          label: 'Monthly Payroll Sum',
          backgroundColor: backgroundColors,
          borderColor: borderColors,
          borderWidth: 1,
          data: values
        }
      ]
    };
  }
 

  // updateChartData(data: Map<string, number>): void {
  //   console.log('Updating chart data with:', data);
  //   const labels: string[] = [];
  //   const values: number[] = [];
  //   const backgroundColors: string[] = [];
  //   const borderColors: string[] = [];

  //   const colors = [
  //     'rgba(0, 0, 0, 1)', // Black
  //     'rgba(128, 128, 128, 0.5)' // Grey
  //   ];

  //   const borderColorsArray = [
  //     'rgba(0, 0, 0, 1)', // Black
  //     'rgba(128, 128, 128, 1)' // Grey
  //   ];

  //   const monthOrder = [
  //     'january', 'february', 'march', 'april', 'may', 'june',
  //     'july', 'august', 'september', 'october', 'november', 'december'
  //   ];

  //   const sortedData: { label: string; value: number; color: string; borderColor: string }[] = [];

  //   data.forEach((value, month) => {
  //     sortedData.push({
  //       label: month,
  //       value: value,
  //       color: colors[monthOrder.indexOf(month.toLocaleLowerCase()) % colors.length],
  //       borderColor: borderColorsArray[monthOrder.indexOf(month.toLocaleLowerCase()) % borderColorsArray.length]
  //     });
  //   });

  //   sortedData.sort((a, b) => {
  //     return monthOrder.indexOf(a.label.toLowerCase()) - monthOrder.indexOf(b.label.toLowerCase());
  //   });

  //   sortedData.forEach(item => {
  //     labels.push(item.label);
  //     values.push(item.value);
  //     backgroundColors.push(item.color);
  //     borderColors.push(item.borderColor);
  //   });

  //   this.basicData = {
  //     labels: labels,
  //     datasets: [
  //       {
  //         label: 'Monthly Payroll Sum',
  //         backgroundColor: backgroundColors,
  //         borderColor: borderColors,
  //         borderWidth: 1,
  //         data: values
  //       }
  //     ]
  //   };
  // }

  onYearChange(event: any): void {
    this.fetchMonthlyPayrollSum(event.value.code);
  }

}
