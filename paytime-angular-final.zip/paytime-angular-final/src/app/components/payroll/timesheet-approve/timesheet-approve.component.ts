import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Timesheet } from '../../../core/models/timesheet';
import { ClaimsServiceService } from '../../../core/models/claims-service.service';
 
@Component({
  selector: 'app-timesheet-approve',
  standalone: false,
  templateUrl: './timesheet-approve.component.html',
  styleUrls: ['./timesheet-approve.component.css']
})
export class TimesheetApproveComponent implements OnInit {
  timesheets: Timesheet[] = [];
  historyTimesheets: Timesheet[] = [];
  today: string = new Date().toISOString().split('T')[0];
  currentTimesheet: Timesheet | null = null;
  timesheetForm: FormGroup;
  showHistory: boolean = false;
  visible: boolean = false;
  action: string = '';
 
  @ViewChild('dt1') dt1: any;
  @ViewChild('dt2') dt2: any;
 
  constructor(private claimsService: ClaimsServiceService, private fb: FormBuilder) {
    this.timesheetForm = this.fb.group({
      feedback: ['', Validators.required]
    });
  }
 
  ngOnInit(): void {
    this.fetchTimesheets();
  }
 
  fetchTimesheets(): void {
    this.claimsService.getTimesheets().subscribe((data: Timesheet[]) => {
      this.timesheets = data.filter(timesheet => timesheet.status === 'Pending');
      this.historyTimesheets = data.filter(timesheet => timesheet.status !== 'Pending');
      console.log(this.timesheets);
      console.log(this.historyTimesheets);
    });
  }
 
  isFormValid(): boolean {
    return this.timesheetForm.valid;
  }
 
  updateTimesheet(action: string): void {
    if (this.isFormValid() && this.currentTimesheet) {
      const updatedFeedback = this.timesheetForm.get('feedback')!.value;
      const updates = {
        feedback: updatedFeedback,
        actionDate: this.today,
        status: action === 'Accepted' ? 'Approved' : 'Rejected'
      };
      console.log(`Updating timesheet with ID: ${this.currentTimesheet!.weeklyTimesheetId}`);
      this.claimsService.updateTimesheet(this.currentTimesheet!.weeklyTimesheetId, updates).subscribe(() => {
        this.timesheetForm.reset(); // Reset the form after updating
        this.fetchTimesheets(); // Refetch timesheets to update the tables
 
        this.currentTimesheet = null;
        this.visible = false; // Hide dialog after updating timesheet
      });
    } else {
      alert('Please enter feedback.');
    }
  }
 
  toggleHistory(): void {
    this.showHistory = !this.showHistory;
    this.clearGlobalSearch();
    this.timesheetForm.reset(); // Reset the form when toggling
  }
 
  clearGlobalSearch(): void {
    if (this.dt1) {
      this.dt1.clear();
    }
    if (this.dt2) {
      this.dt2.clear();
    }
  }
 
  get feedbackControl(): FormControl {
    return this.timesheetForm.get('feedback') as FormControl;
  }
 
  getSeverity(status: string): string {
    switch (status) {
      case 'Approved':
        return 'success';
      case 'Rejected':
        return 'danger';
      default:
        return 'info';
    }
  }
 
  openDialog(timesheet: Timesheet, action: string): void {
    this.currentTimesheet = timesheet;
    this.action = action;
    this.visible = true;
  }
}