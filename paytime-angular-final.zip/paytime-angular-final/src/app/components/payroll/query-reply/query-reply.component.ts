import { Component, OnInit } from '@angular/core';
import { QueryService } from '../../../core/models/query.service';
import { Query } from '../../../core/models/query';

@Component({
  selector: 'app-query-reply',
  standalone: false,
  templateUrl: './query-reply.component.html',
  styleUrls: ['./query-reply.component.css']
})
export class QueryReplyComponent implements OnInit {
  searchText: string = '';
  selectedRecord: Query | null = null;
  payrollData: Query[] = [];
  showDetails: boolean = false;

  constructor(private queryService: QueryService) {}

  ngOnInit() {
    this.loadPayrollData();
  }
  formatDate(dateString: string): string {
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
  }

  loadPayrollData() {
    // this.queryService.getAllSalaryEmployeeDetails().subscribe(data => {
    //   this.payrollData = data;
    //   console.log(this.payrollData);
    // });
    this.queryService.getAllSalaryEmployeeDetails().subscribe((res) => {
      this.payrollData = res.map(item => ({
          ...item,
          dateOfClosed: this.formatDate(item.dateOfClosed),
          dateOfCreated: this.formatDate(item.dateOfCreated)
      }));
      console.log(this.payrollData);
  });

  }

  filteredPayrollData() {
    return this.payrollData.filter(record => 
      record.queryId.toString().includes(this.searchText) ||
      record.category.toLowerCase().includes(this.searchText.toLowerCase()) ||
      record.dateOfCreated.toString().includes(this.searchText) ||
      record.dateOfClosed.toString().includes(this.searchText) ||
      record.description.toLowerCase().includes(this.searchText.toLowerCase()) ||
      record.empId.toString().includes(this.searchText) ||
      record.feedback.toLowerCase().includes(this.searchText.toLowerCase()) ||
      record.status.toLowerCase().includes(this.searchText.toLowerCase()) ||
      record.empName.toLowerCase().includes(this.searchText.toLowerCase())
    );
  }

  viewDetails(record: Query) {
    this.selectedRecord = record;
    this.showDetails = true;
  }

  closeDialog() {
    this.showDetails = false;
  }

  submitFeedback() {
    if (this.selectedRecord) {
      this.queryService.updateFeedback(this.selectedRecord.queryId, this.selectedRecord.feedback!).subscribe(() => {
        this.selectedRecord!.status = 'Resolved';
        alert('Query Resolved Successfully');
        this.closeDialog();
        this.loadPayrollData(); // Reload data to update the table
      });
    }
  }

  getSeverity(status: string) {
    switch (status) {
      case 'Resolved':
        return 'success';
      case 'Pending':
        return 'warning';
      case 'Rejected':
        return 'danger';
      default:
        return null;
    }
  }
}