import { Component, OnInit, ViewChild } from '@angular/core';
import { PayrollService } from '../../../core/models/history.service';
import { history } from '../../../core/models/history';
import { Table } from 'primeng/table';

interface Column {
  field: string;
  header: string;
  customExportHeader?: string;
}

@Component({
  selector: 'app-payroll-history',
  standalone: false,
  templateUrl: './payroll-history.component.html',
  styleUrls: ['./payroll-history.component.css']
})
export class PayrollHistoryComponent implements OnInit {
  @ViewChild('dt3') dt3: Table | undefined;
  searchText: string = '';
  selectedRecord: history | null = null;
  payrollData: history[] = [];
  showDetails: boolean = false;
  cols: Column[] = [];

  constructor(private payrollService: PayrollService) {}

  ngOnInit() {
    this.loadPayrollData();
    this.clearGlobalSearch();
    this.cols = [
      { field: 'empId', header: 'Employee ID' },
      { field: 'empName', header: 'Employee Name' },
      { field: 'netpay', header: 'Net Pay' },
      { field: 'payrollProcessedDate', header: 'Date of Payroll Release' }
    ];
  }
  clearGlobalSearch(): void {
    if (this.dt3) {
      this.dt3.clear();
    }
    // if (this.dt2) {
    //   this.dt2.clear();
    // }
  }

  loadPayrollData() {
    this.payrollService.getAllSalaryEmployeeDetails().subscribe(data => {
      this.payrollData = data;
      console.log(this.payrollData);
    });
  }

  filteredPayrollData() {
    return this.payrollData.filter(record => record.empId.toString().includes(this.searchText));
  }

  viewDetails(record: history) {
    this.selectedRecord = record;
    this.showDetails = true;
  }

  backToPayrollHistory() {
    this.selectedRecord = null;
    this.showDetails = false;
  }

  exportCSV() {
    this.payrollService.getAllSalaryEmployeeDetails().subscribe(data => {
      this.payrollData = data;
      this.dt3?.exportCSV();
    });
  }
}