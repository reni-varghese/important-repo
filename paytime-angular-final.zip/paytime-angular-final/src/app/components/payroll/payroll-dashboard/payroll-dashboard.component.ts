import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../../services/employee.service';
import { NetsalarysumService } from '../../../services/netsalarysum.service';
import { NetSalarySumDTO } from '../../../core/models/net-salary-sum';
import { HttpErrorResponse } from '@angular/common/http';
import { PayrollchartService } from '../../../services/payrollchart.service';

@Component({
  selector: 'app-payroll-dashboard',
  standalone: false,
  templateUrl: './payroll-dashboard.component.html',
  styleUrls: ['./payroll-dashboard.component.css']
})
export class PayrollDashboardComponent implements OnInit {
  years: any[] = [
    { name: '2023', code: '2023' },
    { name: '2024', code: '2024' }
  ];
  selectedYear: any = { name: '2024', code: '2024' }; // Default to 2024

  totalEmployeesAssigned: number = 0;
  totalPayrollThisMonth: number = 0; // Initialize to 0
  isHovered1: boolean = false;
  isHovered2: boolean = false;

  basicData: any;
  basicOptions: any;
  netSalarySum: number = 0; // Initialize netSalarySum

  constructor(private employeeService: EmployeeService, private netsalarysumService: NetsalarysumService, private payrollChartService: PayrollchartService) {}

  ngOnInit(): void {
    const payrollId = sessionStorage.getItem("empId");
    if (payrollId !== null) {
      const parsedPayrollId = parseInt(payrollId, 10);
      this.fetchTotalEmployeesAssigned(parsedPayrollId);
      this.fetchNetSalarySum(parsedPayrollId);
      this.fetchMonthlyPayrollSum(parsedPayrollId, this.selectedYear.code); // Fetch data for the default year
    }

    this.basicOptions = {
      responsive: true,
    maintainAspectRatio: true, // Set to false to allow height adjustment
    scales: {
      y: {
        beginAtZero: true
      }
    },
    plugins: {
      legend: {
        display: true
      }
    }
  };
  }

  fetchTotalEmployeesAssigned(payrollManagerId: number): void {
    this.employeeService.getTotalEmployeesAssigned(payrollManagerId).subscribe(
      (response: { count: number }) => {
        this.totalEmployeesAssigned = response.count;
        console.log(this.totalEmployeesAssigned);
      },
      (error) => {
        console.error('Error fetching total employees assigned:', error);
      }
    );
  }

  fetchNetSalarySum(payrollManagerId: number): void {
    this.netsalarysumService.getNetSalarySumForManager(payrollManagerId).subscribe(
      (response: NetSalarySumDTO) => {
        this.totalPayrollThisMonth = response.netSalarySum; // Update totalPayrollThisMonth with fetched data
        console.log("Net Salary Sum: ", this.totalPayrollThisMonth);
      },
      (error: HttpErrorResponse) => {
        console.error('Error fetching net salary sum:', error.message);
      }
    );
  }

  fetchMonthlyPayrollSum(managerId: number, year: string): void {
    this.payrollChartService.getMonthlyPayrollSum(managerId, year).subscribe(
      (data: Map<number, Map<string, number>>) => {
        console.log("Data received from API:", data);
        const yearData = data.get(parseInt(year, 10));
        console.log("Year data:", yearData);
        if (yearData) {
          this.updateChartData(yearData);
        } else {
          console.error("No data found for the selected year.");
        }
      },
      (error: any) => {
        console.error('Error fetching monthly payroll sum:', error);
      }
    );
  }

  updateChartData(data: Map<string, number>): void {
    console.log("Updating chart data with:", data);
    const labels: string[] = [];
    const values: number[] = [];
    const backgroundColors: string[] = [];
    const borderColors: string[] = [];

    const colors = [
      'rgba(0, 0, 0, 1)',   // Black
      'rgba(128, 128, 128, 0.5)' // Grey
    ];

    const borderColorsArray = [
      'rgba(0, 0, 0, 1)',   // Black
      'rgba(128, 128, 128, 1)' // Grey
    ];

    const monthOrder = [
      'january', 'february', 'march', 'april', 'may', 'june',
      'july', 'august', 'september', 'october', 'november', 'december'
    ];

    const sortedData: { label: string, value: number, color: string, borderColor: string }[] = [];

    data.forEach((value, month) => {
      sortedData.push({
        label: month,
        value: value,
        color: colors[monthOrder.indexOf(month.toLocaleLowerCase()) % colors.length],
        borderColor: borderColorsArray[monthOrder.indexOf(month.toLocaleLowerCase()) % borderColorsArray.length]
      });
    });

    sortedData.sort((a, b) => {
      return monthOrder.indexOf(a.label.toLowerCase()) - monthOrder.indexOf(b.label.toLowerCase());
    });

    sortedData.forEach(item => {
      labels.push(item.label);
      values.push(item.value);
      backgroundColors.push(item.color);
      borderColors.push(item.borderColor);
    });

    this.basicData = {
      labels: labels,
      datasets: [
        {
          label: 'Monthly Payroll Sum',
          backgroundColor: backgroundColors,
          borderColor: borderColors,
          borderWidth: 1,
          data: values
        }
      ]
    };
  }

  onYearChange(event: any): void {
    const payrollId = sessionStorage.getItem("empId");
    if (payrollId !== null) {
      const parsedPayrollId = parseInt(payrollId, 10);
      this.fetchMonthlyPayrollSum(parsedPayrollId, event.value.code);
    }
  }
}