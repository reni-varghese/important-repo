import { Component, OnInit ,ViewChild} from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Claim } from '../../../core/models/claim';
import { ClaimsServiceService } from '../../../core/models/claims-service.service';

@Component({
  selector: 'app-cash-claims-approve',
  standalone: false,
  templateUrl: './cash-claims-approve.component.html',
  styleUrls: ['./cash-claims-approve.component.css']
})
export class CashClaimsApproveComponent implements OnInit {
  claims: Claim[] = [];
  historyClaims: Claim[] = [];
  today: string = new Date().toISOString().split('T')[0];
  currentClaim: Claim | null = null;
  claimForm: FormGroup;
  showHistory: boolean = false;
  visible: boolean = false;
  action: string = '';
  showPdfModal: boolean = false;
  pdfUrl: string = ''; // Initialize as an empty string

  @ViewChild('dt1') dt1: any;
  @ViewChild('dt2') dt2: any;

  constructor(private claimsService: ClaimsServiceService, private fb: FormBuilder) {
    this.claimForm = this.fb.group({
      remark: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.fetchClaims();
  }

  fetchClaims(): void{
    this.claimsService.getClaims().subscribe((data: Claim[]) => {
      this.claims = data.filter(claim => claim.action === 'Pending');
      this.historyClaims = data.filter(claim => claim.action !== 'Pending');
      console.log(this.claims);
      console.log(this.historyClaims);
    });
  }

  isFormValid(): boolean {
    return this.claimForm.valid;
  }

  async updateClaim(action: string): Promise<void> {
    if (this.isFormValid() && this.currentClaim) {
      const updatedRemark = this.claimForm.get('remark')!.value;
      const updates = {
        remark: updatedRemark,
        dateOfAction: this.today,
        action: action
      };
      console.log(`Updating claim with ID: ${this.currentClaim!.claimId}`);
      await this.claimsService.updateRemark(this.currentClaim!.claimId, updates).toPromise();
 
      this.claimForm.reset(); // Reset the form after updating
      this.fetchClaims(); // Refetch claims to update the tables
 
      this.currentClaim = null;
      this.visible = false;
    } else {
      alert('Please enter a remark.');
    }
  }

  toggleHistory(): void {
    this.showHistory = !this.showHistory;
    this.clearGlobalSearch();
    this.claimForm.reset();
  }
  clearGlobalSearch(): void {
    if (this.dt1) {
      this.dt1.clear();
    }
    if (this.dt2) {
      this.dt2.clear();
    }
  }
  get remarkControl(): FormControl {
    return this.claimForm.get('remark') as FormControl;
  }

  getSeverity(status: string): string {
    switch (status) {
      case 'Accepted':
        return 'success';
      case 'Rejected':
        return 'danger';
      default:
        return 'info';
    }
  }

  displayAttachment(claimId: number): void {
    this.claimsService.getAttachment(claimId).subscribe(blob => {
      const url = window.URL.createObjectURL(blob);
      this.pdfUrl = url;
      this.showPdfModal = true;
    }, error => {
      console.error('Error displaying attachment:', error);
    });
  }

  closePdfModal(): void {
    this.showPdfModal = false;
    if (this.pdfUrl) {
      window.URL.revokeObjectURL(this.pdfUrl);
      this.pdfUrl = ''; // Reset to an empty string
    }
  }
  openDialog(claim: Claim, action: string): void {
    this.currentClaim = claim;
    this.action = action;
    this.visible = true;
  }
}