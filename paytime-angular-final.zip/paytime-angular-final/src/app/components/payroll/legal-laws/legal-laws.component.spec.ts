import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LegalLawsComponent } from './legal-laws.component';

describe('LegalLawsComponent', () => {
  let component: LegalLawsComponent;
  let fixture: ComponentFixture<LegalLawsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LegalLawsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LegalLawsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
