import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-legal-laws',
  standalone: false,
  templateUrl: './legal-laws.component.html',
  styleUrl: './legal-laws.component.css'
})

export class LegalLawsComponent implements OnInit, OnDestroy {
    searchValue: string = '';
    cards: any[] = [
      {
        header: 'Income Tax Act',
        content: [
          { section: 'Section 1: Overview', details: 'The Income Tax Act governs the taxation of income in India. It includes provisions for the levy, administration, and collection of income tax.' },
          { section: 'Section 2: Tax Slabs', details: 'Tax slabs define the rate of income tax applicable to different ranges of income. These slabs are subject to change in each budget.' },
          { section: 'Section 3: Deductions', details: 'Deductions are specific expenses that can be subtracted from gross income to reduce taxable income, such as investments in specified savings schemes.' },
        ],
      },
      {
        header: 'EPF Act',
        content: [
          { section: 'Section 1: Overview', details: 'The Employees\' Provident Fund (EPF) Act provides for the institution of provident funds for employees in factories and other establishments.' },
          { section: 'Section 2: Contributions', details: 'Both the employer and employee contribute a certain percentage of the employee\'s salary to the EPF. The current contribution rate is 12% of the basic salary.' },
          { section: 'Section 3: Withdrawals', details: 'Employees can withdraw from their EPF account under certain conditions such as retirement, unemployment, or specific financial needs.' },
        ],
      },
      {
        header: 'Gratuity Act',
        content: [
          { section: 'Section 1: Overview', details: 'The Payment of Gratuity Act provides for a gratuity payment to employees who have rendered continuous service for at least five years.' },
          { section: 'Section 2: Eligibility', details: 'Employees are eligible for gratuity if they have completed five years of continuous service with the same employer.' },
          { section: 'Section 3: Calculation', details: 'Gratuity is calculated based on the employee\'s last drawn salary and the number of years of service. The formula is: Gratuity = (Last drawn salary × 15 × years of service) / 26.' },
        ],
      },
      {
        header: 'ESI Act',
        content: [
          { section: 'Section 1: Overview', details: 'The Employees\' State Insurance (ESI) Act provides for medical, cash, maternity, disability, and dependent benefits to employees.' },
          { section: 'Section 2: Benefits', details: 'The ESI scheme offers various benefits such as medical care, sickness benefits, maternity benefits, and disability benefits.' },
          { section: 'Section 3: Contributions', details: 'Both the employer and employee contribute to the ESI fund. The current contribution rates are 3.25% of the wages by the employer and 0.75% by the employee.' },
        ],
      },
    ];
   
    regulatoryUpdates: any[] = [
      {
        link: 'https://www.incometaxindia.gov.in/',
        text: 'Income Tax Department',
      },
      { link: 'https://www.epfindia.gov.in/', text: 'EPFO' },
      {
        link: 'https://www.labour.gov.in/',
        text: 'Ministry of Labour & Employment',
      },
    ];
   
    filteredCards: any[] = [];
    sectionDialogVisible: boolean = false;
    selectedSectionContent: string = '';
   
    ngOnInit(): void {
      this.filteredCards = [...this.cards];
    }
   
    onSearchChange(): void {
      if (!this.searchValue) {
        this.filteredCards = [...this.cards];
      } else {
        const lowerSearchValue = this.searchValue.toLowerCase();
        this.filteredCards = this.cards.filter((card) => {
          const headerMatch = card.header.toLowerCase().includes(lowerSearchValue);
          const contentMatch = card.content.some((section) =>
            section.section.toLowerCase().includes(lowerSearchValue)
          );
          return headerMatch || contentMatch;
        });
      }
    }
   
    showSectionDialog(section: any): void {
      this.selectedSectionContent = section.details;
      this.sectionDialogVisible = true;
    }
   
    ngOnDestroy(): void {}
  }

