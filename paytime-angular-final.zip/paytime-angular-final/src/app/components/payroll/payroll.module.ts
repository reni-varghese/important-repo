import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PayrollDashboardComponent } from './payroll-dashboard/payroll-dashboard.component';
import { TimesheetApproveComponent } from './timesheet-approve/timesheet-approve.component';
import { CashClaimsApproveComponent } from './cash-claims-approve/cash-claims-approve.component';
import { QueryReplyComponent } from './query-reply/query-reply.component';
import { PayrollComponent } from './payroll/payroll.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { PayrollHistoryComponent } from './payroll-history/payroll-history.component';
// import { FormsModule } from '@angular/forms';
import { TableModule } from 'primeng/table';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { TagModule } from 'primeng/tag';
import { FieldsetModule } from 'primeng/fieldset'; // Import FieldsetModule
import { AvatarModule } from 'primeng/avatar'; // Import AvatarModule
import { CardModule } from 'primeng/card';
import { ChartModule } from 'primeng/chart';
import { SelectModule } from 'primeng/select';
import { DropdownModule } from 'primeng/dropdown';
import { AccordionModule } from 'primeng/accordion';
 

// Additional imports for query-reply component
import { FormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { ClaimsServiceService } from '../../core/models/claims-service.service';
import { LegalLawsComponent } from './legal-laws/legal-laws.component';
//import { PayrollchartService } from '../../services/payrollchart.service';
// import { HttpClientModule } from '@angular/common/http';

const payrollRoutes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' }, // Default route
  { path: 'dashboard', component: PayrollDashboardComponent },
  { path: 'timesheet-approve', component: TimesheetApproveComponent },
  { path: 'cash-claims-approve', component: CashClaimsApproveComponent },
  { path: 'query-reply', component: QueryReplyComponent },
  { path: 'payroll-history', component: PayrollHistoryComponent },
  { path: 'legal-laws', component: LegalLawsComponent }
];

@NgModule({
  declarations: [
    PayrollDashboardComponent,
    TimesheetApproveComponent,
    CashClaimsApproveComponent,
    QueryReplyComponent,
    PayrollComponent,
    PayrollHistoryComponent,
    LegalLawsComponent,
    
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(payrollRoutes),
    ReactiveFormsModule,
    FormsModule,
    TableModule,
    InputTextModule,
    ButtonModule,
    TagModule,
    DialogModule,
    FieldsetModule, // Add FieldsetModule
    AvatarModule, // Add AvatarModule
    CardModule,
    ChartModule,
    DropdownModule,
    SelectModule,
    AccordionModule
    

  ],
  providers: [
    ClaimsServiceService
  ]
})
export class PayrollModule { }
