import { TestBed } from '@angular/core/testing';

import { PayrateService } from './employee/payrates.service';

describe('PayratesService', () => {
  let service: PayrateService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PayrateService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
