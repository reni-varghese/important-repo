import { TestBed } from '@angular/core/testing';

import { PayrollchartService } from './payrollchart.service';

describe('PayrollchartService', () => {
  let service: PayrollchartService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PayrollchartService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
