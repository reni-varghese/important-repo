import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { NetSalarySumDTO } from '../core/models/net-salary-sum';


@Injectable({
  providedIn: 'root'
})
export class NetsalarysumService {
  
  private apiUrl = 'http://localhost:8081/api/employees/net-salary-sum';
  //private managerApiUrl = 'http://localhost:8081/api/employees/net-salary-sum-for-manager'; // New endpoint for payroll manager
  constructor(private http: HttpClient) { }

  getNetSalarySumForManager(payrollManagerId: number): Observable<NetSalarySumDTO> {
    const url = this.apiUrl +"/"+ payrollManagerId;
    return this.http.get<NetSalarySumDTO>(url);
  }
}
