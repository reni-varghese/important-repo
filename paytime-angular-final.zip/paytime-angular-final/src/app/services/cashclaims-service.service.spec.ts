import { TestBed } from '@angular/core/testing';

import { CashclaimsServiceService } from './cashclaims-service.service';

describe('CashclaimsServiceService', () => {
  let service: CashclaimsServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CashclaimsServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
