import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Timesheet } from '../core/models/timesheet.model';
import { TimesheetDto } from '../core/models/timesheet.dto';
import { WeeklyTimeSheet } from '../core/models/WeeklyTimeSheet.model';
import { Dtimesheet } from '../core/models/dtimesheet';
@Injectable({
  providedIn: 'root',
})
export class TimesheetService {
  private baseUrl = 'http://localhost:8081';
  private apiUrl = 'http://localhost:8081/api/timesheet-summary/id/date';
  private timesheetSummaryUrl = `${this.baseUrl}/api/timesheet-summary`;
  private weeklySummaryUrl = `${this.baseUrl}/weekly-summary`;

  constructor(private http: HttpClient) {}

  getTimesheetData1(empId: string, fromDate: string, toDate: string): Observable<Dtimesheet[]> {
   
    const url = `${this.apiUrl}/${empId}?from=${fromDate}&To=${toDate}`;
    console.log( this.http.get<Dtimesheet[]>(url));
    return this.http.get<Dtimesheet[]>(url);
  }

  
  getTimesheetData(empId: string, fromDate: Date, toDate: Date): Observable<TimesheetDto[]> {
    const formattedFromDate = fromDate.toISOString().split('T')[0];
    const formattedToDate = toDate.toISOString().split('T')[0];
    const url = `${this.timesheetSummaryUrl}/id/date/${empId}?from=${formattedFromDate}&To=${formattedToDate}`;
    //            localhost:8081/api/timesheet-summary/id/date/2374920?from=2024-07-21&To=2024-07-25
    const data =  this.http.get<TimesheetDto[]>(url);
    console.log(data);
    return data;
  }

  addTimesheet(timesheet: Timesheet): Observable<Timesheet> {
    return this.http.post<Timesheet>(this.timesheetSummaryUrl, timesheet);
  }

  updateTimesheet(timesheet: Timesheet): Observable<Timesheet> {
    return this.http.put<Timesheet>(`${this.timesheetSummaryUrl}/${timesheet.empId}`, timesheet);
  }

  getTimesheetByDate(empId: number, date: string): Observable<Timesheet> {
    console.log("from service "+date)
    
    const url = `${this.timesheetSummaryUrl}/id/${empId}/date/${date}`;
    console.log(url)
    return this.http.get<Timesheet>(url);
  }

  getTimesheetDates(empId: number, date: string): Observable<Timesheet[]> {
    const url = `${this.weeklySummaryUrl}/id/${empId}/date/${date}`;
    return this.http.get<Timesheet[]>(url);
  }

  updateTimesheetByDate(timesheet: Timesheet): Observable<TimesheetDto> {
    console.log(timesheet.overTimeHours);
    const url = `${this.weeklySummaryUrl}/timesheet/id/${timesheet.empId}/date/${timesheet.date}`;
    return this.http.patch<TimesheetDto>(url, {
      clockIn: timesheet.clockIn + ":00",
      clockOut: timesheet.clockOut + ":00",
      overTimeHours: timesheet.overTimeHours,
    });
  }
  getTimesheetsByIdAndDate(empId: number, from: string, to: string): Observable<TimesheetDto[]> {
    return this.http.get<TimesheetDto[]>(`${this.baseUrl}/id/date/${empId}?from=${from}&to=${to}`);
  }
  submitWeeklyTimesheet(empId: number, currentDate: string) :Observable<WeeklyTimeSheet> {
    return this.http.post<WeeklyTimeSheet>(`${this.weeklySummaryUrl}/${empId}/${currentDate}`, {});
  }
  updateWeeklyTimesheetByDate(timesheet: Timesheet): Observable<TimesheetDto> {
    console.log(timesheet.overTimeHours);
    const url = `${this.weeklySummaryUrl}/id/${timesheet.empId}/date/${timesheet.date}`;
    return this.http.patch<TimesheetDto>(url, {
      clockIn: timesheet.clockIn + ":00",
      clockOut: timesheet.clockOut + ":00",
      overTimeHours: timesheet.overTimeHours,
    });
  }
}