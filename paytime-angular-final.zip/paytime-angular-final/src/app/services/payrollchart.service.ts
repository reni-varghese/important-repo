import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PayrollchartService {
  private baseUrl = 'http://localhost:8081/api/salary';
  constructor(private http: HttpClient) { }

  getMonthlyPayrollSum(empId: number, year: string): Observable<Map<number, Map<string, number>>> {
    return this.http.get<{ [key: number]: { [key: string]: number } }>(`${this.baseUrl}/monthly-payroll-sum?empId=${empId}`).pipe(
      map(data => {
        const result = new Map<number, Map<string, number>>();
        for (const key in data) {
          if (data.hasOwnProperty(key)) {
            result.set(parseInt(key, 10), new Map(Object.entries(data[key])));
          }
        }
        return result;
      })
    );
  }
  getMonthlyPayrollSumForAllEmployees(year:string) : Observable<{[key: string]: number }>{

    return this.http.get<{[key: string]: number }>(`${this.baseUrl}/monthly-sum?year=${year}`);


  }
}