import { Injectable } from '@angular/core';
import { ConfirmationService } from 'primeng/api';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class SessionTimeoutService {
  private timeoutDuration = 30* 60 * 1000; // 30 minutes in milliseconds
  private timeoutId: any;

  constructor(private confirmationService: ConfirmationService, private router: Router) {}

  startSessionTimer() {
    this.clearSessionTimer();
    this.timeoutId = setTimeout(() => {
      this.showSessionExpiredDialog();
    }, this.timeoutDuration);
  }

  clearSessionTimer() {
    if (this.timeoutId) {
      clearTimeout(this.timeoutId);
    }
  }

  private showSessionExpiredDialog() {
    this.confirmationService.confirm({
      message: 'Your session has expired. Please log in again.',
      acceptLabel: 'OK',
      rejectVisible: false,
      accept: () => {
        sessionStorage.removeItem('empId');
        sessionStorage.removeItem('token');
       
        this.router.navigate(['/auth/login']);
        
      }
    });
  }
}