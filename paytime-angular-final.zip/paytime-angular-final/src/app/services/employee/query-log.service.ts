import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { QueryLog } from './query-log';


@Injectable({
  providedIn: 'root'
})
export class QueryLogService {

  empId: string | null = sessionStorage.getItem("empId");
  private dataUrl = 'http://localhost:8081/api/query/employee/'+this.empId;
  
    constructor(private http: HttpClient) {}
  
    getQueryLog(): Observable<QueryLog[]> {
      return this.http.get<QueryLog[]>(this.dataUrl);
    }
}
