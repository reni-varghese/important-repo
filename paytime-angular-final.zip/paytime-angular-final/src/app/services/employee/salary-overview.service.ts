import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SalaryOverview } from './salary-overview';

@Injectable({
  providedIn: 'root'
})
export class SalaryOverviewService {
  
  empId: string | null = sessionStorage.getItem("empId");
  private dataUrl = 'http://localhost:8081/api/salary/employee/'+this.empId;

  constructor(private http: HttpClient) {}

  getData(): Observable<SalaryOverview[]> {
    console.log(this.http.get<SalaryOverview[]>(this.dataUrl));
    return this.http.get<SalaryOverview[]>(this.dataUrl);
  }
}
