export interface SalaryOverview {
}
