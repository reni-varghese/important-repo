import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedDateService {

  private weekStart: Date | null = null;
  private weekEnd: Date | null = null;

  setWeekDates(start: Date, end: Date): void {
    this.weekStart = start;
    this.weekEnd = end;
  }

  getWeekStart(): Date | null {
    return this.weekStart;
  }

  getWeekEnd(): Date | null {
    return this.weekEnd;
  }
}
