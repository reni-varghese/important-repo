export interface CreateQuery {
}
