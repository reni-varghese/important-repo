export interface UpdateUserDetails {
  empName: string;
  empEmail: string;
  empDob: string; // Use string to match the format expected by the backend
  empBloodGroup: string;
  empGender: string;
  empMaritalStatus: string;
  empNationalId: string;
  empPhoneNo: string;
}
