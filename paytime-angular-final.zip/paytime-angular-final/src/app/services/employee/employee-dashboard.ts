export interface EmployeeDashboard {
}
