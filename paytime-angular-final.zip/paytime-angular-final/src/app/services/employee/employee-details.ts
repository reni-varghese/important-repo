export interface EmployeeDetails {
  empId: string;
  empName: string;
  empEmail: string;
  empDob: string; // Use string to match the format expected by the backend
  empBloodGroup: string;
  empGender: string;
  empMaritalStatus: string;
  empNationalId: string;
  empPhoneNo: string;
  empRole: string;
  bankName: string;
  accountHolderName: string;
  accountNumber: string;
  ifscCode: string;
  branch: string;
}
