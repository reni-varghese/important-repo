import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { EmployeeDetails } from './employee-details';
import { UpdateUserDetails } from './update-user-details';
import { UpdateBankDetails } from './update-bank-details';

@Injectable({
  providedIn: 'root',
})
export class EmployeeDashboardService {
  empId: string | null = sessionStorage.getItem('empId');
  private dataUrl = 'http://localhost:8081/api/employees/' + this.empId;
  private updateUserUrl =
    'http://localhost:8081/api/employees/patch-emp/' + this.empId;
  private updateBankUrl =
    'http://localhost:8081/api/employees/update-bank-details/' + this.empId;

  constructor(private http: HttpClient) {}

  getEmployeeDetails(): Observable<EmployeeDetails> {
    return this.http.get<EmployeeDetails>(this.dataUrl);
  }
  updateEmployeeDetails(userDetails: UpdateUserDetails): Observable<any> {
    return this.http.patch<UpdateUserDetails>(this.updateUserUrl, userDetails);
  }
  updateBankDetails(bankDetails: UpdateBankDetails): Observable<any> {
    return this.http.patch<UpdateBankDetails>(this.updateBankUrl, bankDetails);
  }
}
