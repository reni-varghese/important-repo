import { Injectable } from '@angular/core';
import { PayRate } from '../../core/models/dpayrates';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
 
@Injectable({
  providedIn: 'root'
})
export class PayrateService {
 
 
  private apiUrl = 'http://localhost:8081/api/payrate'; // Replace with your backend API URL
 
  constructor(private http: HttpClient) {}
 
 
  getPayRates(): Observable<PayRate[]> {
    return this.http.get<PayRate[]>(this.apiUrl);
  }
 
  addPayRate(payRate: PayRate): Observable<PayRate> {
    return this.http.post<PayRate>(this.apiUrl, payRate);
  }
 
  updatePayRate(payRate: PayRate): Observable<PayRate> {
    return this.http.patch<PayRate>(`${this.apiUrl}/${payRate.pay_rateid}`, payRate);
  }
 
  deletePayRate(pay_rateid: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${pay_rateid}`);
  }
}