import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CreateQuery } from './create-query';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CreateQueryService {
  empId: string | null = sessionStorage.getItem("empId");
    private apiUrl = 'http://localhost:8081/api/query/employee'; // Replace with your actual backend URL
  
    constructor(private http: HttpClient) {}
  
    addQuery(queryData: CreateQuery): Observable<any> {
      return this.http.post<CreateQuery>(this.apiUrl, queryData);
    }
}
