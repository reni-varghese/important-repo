import { TestBed } from '@angular/core/testing';

import { CreateQueryService } from './create-query.service';

describe('CreateQueryService', () => {
  let service: CreateQueryService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CreateQueryService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
