import { TestBed } from '@angular/core/testing';

import { SalaryOverviewService } from './salary-overview.service';

describe('SalaryOverviewService', () => {
  let service: SalaryOverviewService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SalaryOverviewService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
