export interface QueryLog {
}
