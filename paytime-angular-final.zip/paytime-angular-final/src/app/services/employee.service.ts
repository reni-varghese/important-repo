import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Salaries } from '../core/models/dsalaries';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private apiUrl = 'http://localhost:8081/api/employees';
  private apiUrl2 = 'http://localhost:8081/api/salary/payroll-details'
   // Replace with your backend URL

  constructor(private http: HttpClient) {}


  // getAllSalay:
  getAllEmployeesSalary():Observable<Salaries[]>{
  
    return this.http.get<Salaries[]>(this.apiUrl2);

  }

  getTotalEmployeesAssigned(payrollManagerId: number): Observable<{ count: number }> {
    console.log(payrollManagerId)
    console.log("from service ")
    // const token = localStorage.getItem('eyJhbGciOiJIUzM4NCJ9.eyJzdWIiOiJhamF5QGdtYWlsLmNvbSIsImlhdCI6MTc0MDM3NDE0MCwiZXhwIjoxNzQwMzc3NzQwfQ.HbhYZIxwFuxOB5aQ4dcfB1hGiMgIQXuNDTC6HeE6nw8kJonQJjTgF8MvXk1h34_O'); // Replace with your token retrieval logic
    // const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    console.log(this.apiUrl+"   "+payrollManagerId);
    return this.http.get<{ count: number }>(`${this.apiUrl}/count-assigned/${payrollManagerId}`);
  }

  // getEmployeeIdsByManager(payrollManagerId: number): Observable<number[]> {
  //   return this.http.get<number[]>(`${this.apiUrl}/${payrollManagerId}`);
  // }
}