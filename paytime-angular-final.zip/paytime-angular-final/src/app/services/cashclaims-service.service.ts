import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Dcashclaims } from '../core/models/dcashclaims';

@Injectable({
  providedIn: 'root'
})

export class CashclaimsServiceService {

  private apiUrl = 'http://localhost:8081/api/claims/employee';

  constructor(private http: HttpClient) {}

  getClaims(empId: string, fromDate: string, toDate: string): Observable<Dcashclaims[]> {
    
    const url = `${this.apiUrl}/${empId}/date-range?startDate=${fromDate}&endDate=${toDate}`;
    return this.http.get<Dcashclaims[]>(url);

  }
  
}
