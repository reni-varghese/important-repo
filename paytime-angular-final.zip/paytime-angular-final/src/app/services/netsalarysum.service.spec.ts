import { TestBed } from '@angular/core/testing';

import { NetsalarysumService } from './netsalarysum.service';

describe('NetsalarysumService', () => {
  let service: NetsalarysumService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NetsalarysumService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
