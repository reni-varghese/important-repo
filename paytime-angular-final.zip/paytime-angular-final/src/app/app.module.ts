import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import { AdminModule } from './components/admin/admin.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { EmployeeModule } from './components/employee/employee.module';
import { PayrollModule } from './components/payroll/payroll.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgxPaginationModule } from 'ngx-pagination';
import { StoreModule, MetaReducer } from '@ngrx/store';
import './shared/store/auth.reducer';
import { JwtInterceptor } from './core/interceptor/jwt.service';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { providePrimeNG } from 'primeng/config';
import Material from '@primeng/themes/material';
import { ConfirmationService } from 'primeng/api';
import { localStorageMetaReducer } from './shared/store/local-storage.reducer';
import { authReducer } from './shared/store/auth.reducer';



// Import PrimeNG modules
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { DialogModule } from 'primeng/dialog';

// Import the new component and service

import { TimesheetService } from './services/timesheet-service.service';


export const metaReducers: MetaReducer<any>[] = [localStorageMetaReducer];

@NgModule({
  declarations: [
    AppComponent,
    
   
   
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    CoreModule,
    SharedModule,
    AdminModule,
    EmployeeModule,
    PayrollModule,
    NgxPaginationModule,
    HttpClientModule,
    BrowserAnimationsModule,
    
    StoreModule.forRoot({ auth: authReducer }, { metaReducers }), // Register meta-reducers here
    CalendarModule, // PrimeNG modules
    DropdownModule,
    InputTextModule,
    ButtonModule,
    DialogModule
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    provideAnimationsAsync(),
    providePrimeNG({
      theme: {
        preset: Material,
        options: {
          darkModeSelector: '.darkmode',
        },
      },
    }),
    ConfirmationService,
    TimesheetService // Add the new service here
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }